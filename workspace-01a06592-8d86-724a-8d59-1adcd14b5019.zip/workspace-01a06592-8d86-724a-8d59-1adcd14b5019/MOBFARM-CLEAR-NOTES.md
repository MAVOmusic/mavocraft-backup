# MobFarm wipe / undo (floating brick wall leftover)

The floating dark-brick strip in the middle is leftover from the **2.0 first build** (or old 1.0). Texture packs cannot remove blocks — wipe with air.

## Fastest (with 2.0.1 jar)

1. Upload `jars/MAVOMobFarm-2.0.1.jar`, remove `2.0.0` / `1.0.0`, restart (or reload carefully).
2. Stand on the hub pad (chest / glowstone corners) looking at the floating wall:
   ```
   /mobfarm clearhere 90
   ```
   That fills a 90-block cube around you with **air** (enough for hub + all 5 bays + junk).
3. Or if center is still saved correctly:
   ```
   /mobfarm clear
   ```
   (wipes full hub+bay bounding box from saved center)
4. Rebuild clean:
   ```
   /mobfarm setcenter
   /mobfarm build
   ```

## Without new jar yet (WorldEdit / vanilla)

WorldEdit (if installed):
```
//pos1
//pos2   (other corner covering the floating wall + rooms)
//set air
```
Or wand a box around `-3600 198 -1666` large enough (e.g. 100×40×100).

Vanilla fill (from console, adjust coords to cover the strip):
```
/execute in minecraft:world run fill -3700 180 -1750 -3500 220 -1600 air
```
(Tune the box to your farm — F3 coords in the shot are ~`-3600, 198, -1666`.)

## Then rebuild
Stand where hub should be (same farm site is fine, **not plaza**):
```
/mobfarm setcenter
/mobfarm build
```

Jar: `/home/user/jars/MAVOMobFarm-2.0.1.jar`
