# MAVOMobFarm 2.2.4 — flowing water + hopper→chest + ladder path

**Jar:** `/home/user/jars/MAVOMobFarm-2.2.4.jar`

## Your 3 bugs

| Bug | Cause | Fix |
|---|---|---|
| Water still / no current | Sources placed every 2 blocks along canal | **Only 2 sources at north end**; ice floor; mid-canal sources stripped each tick |
| Loot stuck in hopper | Hopper chain broken / brick between / wrong facing | Continuous path kill→east→south→**east into double chest**; wall punched for tunnel |
| Jump to ladder | Hatch with no walkway | Solid balcony walkway + **2×2 hatch** + double ladder shaft |

## Deploy
```
# upload 2.2.4, remove older jars, restart
/mobfarm purge 150
/mobfarm clearhere 120
/mobfarm setcenter
/mobfarm build
/mobfarm enter
```

Check:
1. Canal water should **move** south (current animation)
2. Drop flesh on kill carpet → appears in double chest
3. Walk east on balcony → ladder hatch → climb down, no jump
