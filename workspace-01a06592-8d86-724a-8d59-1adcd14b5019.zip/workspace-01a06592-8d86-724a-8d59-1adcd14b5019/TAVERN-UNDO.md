# Tavern build20 undo + centered rebuild

## What went wrong
Old `/tavern build20` placed a **20×20 box with corner at your feet** (grew +X/+Z only), so it sat against the plaza wall instead of around you.

## New jar: MAVOTavern-1.2.0
- `/tavern undo` — removes last build20 (or recovers from bed coords if 1.1.0 build)
- `/tavern undo here` — clears 20×20 centered on you (emergency)
- `/tavern build20` — **centered on you**, door faces where you look

## Steps NOW
1. Upload `jars/MAVOTavern-1.2.0.jar` → plugins/
2. Delete `MAVOTavern-1.1.0.jar`
3. Restart (or stop/start)
4. Stand **inside the bad inn** (or anywhere) and run:
```
/tavern undo
```
   If it says no bounds: stand in the **middle** of the wooden room:
```
/tavern undo here
```
5. **Plaza wall:** undo only airs the inn box. Any stone the inn **replaced** is gone from that volume.
   - Prefer CoreProtect (you have it):
```
/co rollback u:MAVOmusicYT t:2h r:30 #block
```
     or look at the damaged wall and:
```
/co restore r:15
```
     (adjust radius/time; do this **before** rebuilding the inn if possible)
   - Or hand-repair the wall strip.

6. Stand where the **center** of the tavern should be (clear of the wall by ~10 blocks each way), face the entrance direction you want, then:
```
/tavern build20
```

7. Test bed at night; right-click Innkeeper for bar.

## Day still 108?
If you have Hud 2.2.0:
```
/hud setday 1
/tab reload
```
