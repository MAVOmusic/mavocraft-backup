# MAVOMobFarm 2.2.1 — water / loot / chest fix

**Jar:** `/home/user/jars/MAVOMobFarm-2.2.1.jar`

## Priority fixes

### 1. Water flowing
- Spawner moved **EAST of trench** (was in the middle blocking flow)
- 2-wide canal `x=-1..0` with **glass sides** + packed ice edges
- Water sources with **physics=true** at north end → flow south into drop
- Drop is **2×2** so adult zombies fit (babies/jockeys stripped)

### 2. Stairs / ladder / no void
- Enclosed loot room: **solid deepslate floor** under everything
- **Ladder** on solid wall from balcony into loot
- Hopper chain never over air

### 3. Double chests
- Place with **physics=true** + LEFT/RIGHT force + size verify/swap
- Console logs `Double chest … size=54` when linked

### Also
- Stack holos: wipe all old STACK/COMMUNITY displays in cell on refresh
- Hallway + balcony + loot **sea lanterns**
- Chicken jockeys blocked; babies forced adult

## Deploy
1. Replace jar, **delete `plugins/MAVOMobFarm/`** (old holos/data)
2. Restart
3. At farm:
   ```
   /mobfarm clearhere 120
   /mobfarm setcenter
   /mobfarm build
   ```
4. Check console for `Double chest … size=54`
5. `/mobfarm enter` → stand at hole → water should push mobs into drop → kill down → ladder east to double chest

If water still looks still for a second, walk away 1 chunk and back (client); sources are real.
