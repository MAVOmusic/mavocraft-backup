# MAVOTavern 1.4.0 — all 4 beds locked + per-bed holos

## Bug
`extraBeds` was never loaded in `reloadLocal()`, so only bed #1 was a "tavern bed". The other 3 acted as normal respawn beds (free sleep / homes).

## Fix
- Load `beds:` absolute list (and legacy `extra-beds` offsets)
- Small holo above **each** bed: `TAVERN BED` + price
- Block free vanilla enter unless paid flow
- `/tavern beds` — scan nearby beds and register all as paid tavern beds

## Install
1. Upload `MAVOTavern-1.4.0.jar`, remove older Tavern jars
2. Restart
3. Stand **inside** the inn and run:
```
/tavern beds
```
You should see: `Registered 4 tavern beds + holos...`

4. Optional door holo:
```
/tavern setholo
```

5. Test: right-click each bed — all should demand 100 coins (or show lock-until-noon if already rested). None should set free respawn without paying.

## Rebuild (optional, clean layout)
```
/tavern undo
/tavern build20
```
(then `/tavern beds` if needed — build20 already registers all 4)

## Console check
On enable / beds: `Tavern beds loaded: primary … + 3 extra(s)` and `Spawned 4 bed holos.`
