# Day 1 level.dat notes

## GitHub uploads (`level.dat_backup`, `level.dat_old`)
Size ~490 bytes. These are **partial** NBT (same data as the SNBT export), NOT a full Paper world `level.dat`.

Patched copies in this folder:
- `level.dat` — Time=0, DayTime=1000 (from level.dat_backup)
- `level.dat_old.DAY1` — same patch from level.dat_old

**Only replace live `world/level.dat` with this if your live file is also ~500 bytes.**
Otherwise run `patch-level-dat-day1.py` on the **real** large `world/level.dat` on the server host.

## Real world file
```
cp world/level.dat world/level.dat.BEFORE-DAY1
python3 patch-level-dat-day1.py world/level.dat
```
