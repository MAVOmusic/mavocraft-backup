# MAVOTavern 1.3.0

## Fixes
1. **Holo above tavern** — auto-placed at door (high). Fine-tune: stand on doorstep → `/tavern setholo`
2. **4 beds, multiplayer sleep** — pay 100 once → enter **that** bed via vanilla sleep. Sunrise needs everyone sleeping (MC rule). 4 beds so 4 people / backup if one fails. Each player locks until **noon** after their rest.
3. **Innkeeper faces entrance** (door). **Bar at back wall.** **Beds on left/right sides** (not behind counter).

## Install
1. Upload `jars/MAVOTavern-1.3.0.jar`, remove older Tavern jars
2. Restart
3. Rebuild inn (recommended for layout):
```
/tavern undo
```
(stand inside old inn if needed: `/tavern undo here`)
Then stand at center, face door direction:
```
/tavern build20
```
4. Stand on the doorstep (outside looking at door or in doorway):
```
/tavern setholo
```
Adjust height in `plugins/MAVOTavern/config.yml` → `holo.y-offset` (default 7.5) then `/tavern reload` or setholo again.

## Sleep behaviour
- Right-click any of the 4 tavern beds at night
- Pays 100 (unless creative)
- Forces you into bed; if alone, can still force morning; if others online, they must sleep too
- After you rest, **you** can't rent again until noon; others still can

## Commands
```
/tavern build20
/tavern undo | undo here
/tavern setholo
/tavern bar
/tavern info
```
