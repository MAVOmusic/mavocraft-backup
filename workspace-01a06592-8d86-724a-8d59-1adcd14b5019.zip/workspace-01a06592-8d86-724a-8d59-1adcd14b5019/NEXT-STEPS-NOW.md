# MAVOcraft — what to do NEXT (server still STOPPED)

You already did:
- [x] Stopped server
- [x] Copied 8 new jars into `plugins/`
- [x] Deleted old configs for professions / achievements / goals / casino / tavern

Do the rest **in this order** before starting.

---

## STEP A — Confirm jars (still stopped)

In `plugins/` you should have **exactly one** of each (remove older versions):

```
MAVOProfessions-3.14.0.jar
MAVOAchievements-1.6.0.jar
MAVOHud-2.1.0.jar
MAVOCommunityGoals-1.2.0.jar
MAVOCasino-1.2.0.jar
MAVOTavern-1.1.0.jar
MAVOMobFarm-1.0.0.jar
MAVOGuide-2.6.0.jar
```

Also keep if not already live:
```
MAVOVault-1.7.1.jar
MAVOPortalRoom-1.1.0.jar
```

Delete any older same-plugin jars (`3.13`, `1.5`, `2.0`, `1.1.0` casino, `1.0.1` tavern, etc.).

---

## STEP B — Day counter → Day 1  ⚠️ important

### About the GitHub `level.dat_backup` / `level.dat_old`
Those files are only **~500 bytes**. A real Paper `world/level.dat` is usually **much larger** and has WorldGen / gamerules / border / etc.

They match the **partial SNBT export** (Time + spawn + packs), **not** a full world file.

**Do NOT replace your live `world/level.dat` with the GitHub fragment** or you can break the world.

### Correct way (pick one)

#### B1 — Best: patch the REAL file on the host (server stopped)

On the machine that has the actual world folder:

```bash
# backup first
cp world/level.dat world/level.dat.BEFORE-DAY1

pip install nbtlib
python3 patch-level-dat-day1.py world/level.dat
```

Or any NBT editor: open **your real** `world/level.dat` and set:

| Tag | Value |
|-----|--------|
| `Data.Time` | `0` |
| `Data.DayTime` | `1000` (morning, optional) |

Your old Time was `2614913` → about day 109. After `0`, HUD shows **Day 1**.

#### B2 — If you cannot edit NBT offline

Start the server later (after wipe steps), then from **console** once:

Use a one-shot if you have any scripting plugin, **or** install a tiny temp plugin / use:

Paper does **not** ship `/time` that resets the **day number** — `/time set 0` only sets time-of-day.

So offline NBT edit is the reliable path. If your host panel has “NBT editor” or “world edit level.dat”, use that on `world/level.dat`.

#### B3 — Workspace deliverable
`level-dat-DAY1/level.dat` = patched **fragment** only (Time=0).  
Use it only if your host file is **also** that same small fragment (unlikely). Prefer B1 on the real world file.

Also keep `world/level.dat_old` as-is or patch separately; Paper mainly reads `level.dat`.

---

## STEP C — Progress wipe (server still STOPPED)

UUID: `53322438-a7a2-4eb2-bb2b-1c648a43dccf` (MAVOmusicYT)

### C1 — Essentials money/homes
```
plugins/Essentials/userdata/53322438-a7a2-4eb2-bb2b-1c648a43dccf.yml
```
Delete that file only (not the whole userdata folder).

### C2 — Vanilla player
In the overworld folder (usually `world/`):
```
world/playerdata/53322438-a7a2-4eb2-bb2b-1c648a43dccf.dat
world/playerdata/53322438-a7a2-4eb2-bb2b-1c648a43dccf.dat_old
world/advancements/53322438-a7a2-4eb2-bb2b-1c648a43dccf.json
world/stats/53322438-a7a2-4eb2-bb2b-1c648a43dccf.json
```

### C3 — MAVO plugin DATA (not config — configs already deleted for 5 plugins)
Delete these **data.yml** files if they exist:
```
plugins/MAVOProfessions/data.yml
plugins/MAVOAchievements/data.yml
plugins/MAVOQuests/data.yml
plugins/MAVOCurator/data.yml
plugins/MAVOStreaks/data.yml
plugins/MAVOPets/data.yml
plugins/MAVOLuckyCoins/data.yml
plugins/MAVOCasino/data.yml
plugins/MAVOHomes/data.yml
plugins/MAVODeathChest/data.yml
plugins/MAVOVault/data.yml
plugins/MAVOPortalRoom/data.yml
plugins/MAVOChunkPrices/data.yml
plugins/MAVOMobFarm/data.yml
plugins/MAVOTavern/data.yml
plugins/MAVOCommunityGoals/data.yml
plugins/MAVOGuide/data.yml
plugins/MAVOHud/data.yml
```

### C4 — Also delete configs you may have missed (fresh defaults)
You already did professions/achievements/goals/casino/tavern. Also delete if present:
```
plugins/MAVOMobFarm/config.yml
plugins/MAVOHud/config.yml
plugins/MAVOGuide/config.yml
```
(First boot recreates them from the jar.)

### C5 — Claims (optional full wipe)
```
plugins/ClaimChunk/data/claimedChunks.json
```
(or clear ClaimChunk data folder contents)

---

## STEP D — START the server

Start Paper. Watch console for:
- MAVOProfessions 3.14 / Achievements 1.6 / Hud 2.1 / Goals 1.2 / Casino 1.2 / Tavern 1.1 / MobFarm 1.0 / Guide 2.6
- No red errors about missing Vault / PlaceholderAPI

---

## STEP E — Console commands (right after start)

```
lp user MAVOmusicYT clear
lp user MAVOmusicYT parent set default
lp user MAVOmusicYT permission set mavocraft.owner true
```
(Adjust owner node if you use a different permission.)

```
vaultroom wipeplayer MAVOmusicYT
```

If day still wrong and you couldn't edit level.dat offline, fix Time now with an NBT tool while briefly stopped, or accept day until next maintenance.

---

## STEP F — In-game setup (you, as op once)

### F1 — TAB scoreboard
In TAB config, set sidebar lines roughly to:
```
&6&lMAVOcraft
&8---------------
%mavohud_tab_name%
%mavohud_level_line%
&8---------------
%mavohud_coords%
&fDay &e%mavohud_day%  &c☠ %mavohud_deaths%
%mavohud_time%
```
Then: `/tab reload` (or restart).

Confirm Day shows **1** (if level.dat patched).

### F2 — Tavern 20×20
Stand where the inn should be:
```
/tavern build20
```
Test bed at night; right-click **Innkeeper** for food/drink (1/day, soulbound).

### F3 — Mob farm (~500 from vault plaza)
```
/mobfarm setcenter
/mobfarm build
/mobfarm info
```
Test later: `/mobfarm enter` (5000 coins).

### F4 — Guide
```
/guide
```
Should be guide version 12 content (mobfarm, player level, slower grind).  
If it doesn’t auto-open: delete `plugins/MAVOGuide/data.yml` and rejoin once.

### F5 — Sanity checks
```
/prof
/achievements   (or your achievements command)
/goal
/casino
/hud
```
Mine a few blocks — XP should feel **much slower** than before.

### F6 — De-op yourself for survival play
When setup is done:
```
deop MAVOmusicYT
```
Keep console access for admin.

---

## STEP G — Optional polish
- `/shopnpc resholo` if holos need refresh (**not** `/holoreset` until verified)
- EconomyShopGUI: dirt/cobble/treasury shop % bonuses are **not auto-wired** yet — ignore until we hook ESGUI
- Upload new `MAVOcraft-backup.zip` to GitHub when stable

---

## Quick checklist

| # | Task | Status |
|---|------|--------|
| 1 | Stop server | done |
| 2 | New jars in plugins | done |
| 3 | Delete 5 progression configs | done |
| 4 | Confirm jar versions / remove old jars | **you** |
| 5 | Patch **real** `world/level.dat` Time→0 | **you** |
| 6 | Wipe Essentials + playerdata + MAVO data.yml | **you** |
| 7 | Delete MobFarm/Hud/Guide config if leftover | **you** |
| 8 | Start server | **you** |
| 9 | LP clear + vault wipeplayer | **you** |
| 10 | TAB placeholders | **you** |
| 11 | `/tavern build20` + `/mobfarm setcenter` + `build` | **you** |
| 12 | Test grind speed / day 1 / guide | **you** |
| 13 | deop when ready to play | **you** |

