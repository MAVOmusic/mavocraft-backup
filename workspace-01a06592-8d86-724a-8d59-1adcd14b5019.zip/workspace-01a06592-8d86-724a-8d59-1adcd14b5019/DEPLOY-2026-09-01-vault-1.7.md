# Deploy — Vault 1.7.0 (rebuild + expand fix + ender pairs)

## Upload
plugins/MAVOVault-1.7.0.jar

## CRITICAL — rebuild wiped rooms + ender chests
In-game as OP:
```
/vaultroom rebuild
```
This replays the original vault_build datapack with **ender chests** (pairs of
two enders per slot). Ownership in data.yml is kept.

Then:
```
/vaultroom signs
/vaultroom chestsigns
```

If you already paid for L2S8 but no ladder appeared:
```
/vaultroom fixladder
```
(or expand again after rebuild if data has ladder-to)

## Expand buy bug fixed
Root cause: click handler only accepted slot 11, so Expand (slot 13) never ran.
Now 11 = toggle door, 13 = purchase expand, 15 = close.

## Door
"Open / Close door" **toggles** — no longer stuck open. Vanilla door click
still opens the menu (by design) so you use the button to toggle.

## Ender chest pairs
Each unlocked slot = 2 ender chest blocks (look) but opens a **private 54-slot
virtual inventory** (double-chest size). NOT the player ender chest.
Stored in data.yml rooms.<id>.pair.<unit>.*

## Ladder
Placed in free aisle gap between centre chest rows, shaft through ceiling.

## Datapack
Updated MAVOcraft-builder-datapack.zip also has ender chests if you prefer:
```
/function mavocraft:vault_build
```
(same result as /vaultroom rebuild)
