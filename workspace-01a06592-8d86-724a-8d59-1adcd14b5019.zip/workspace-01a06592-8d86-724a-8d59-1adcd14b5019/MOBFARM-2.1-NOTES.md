# MAVOMobFarm 2.1.0 — solid complex (fixes your screenshots)

**Jar:** `/home/user/jars/MAVOMobFarm-2.1.0.jar`  
Remove `2.0.x` and `1.0.0` from plugins.

## Why pick GUI was empty
Log said: `mobs=0`. Host still had **old 1.0 config.yml** with no `mobs:` section.  
2.1 **auto-replaces** empty mob catalog (jar defaults + hardcoded fallback). Startup should show `mobs=10`.

## What 2.1 fixes vs your shots

| Issue | Fix |
|---|---|
| Empty Pick Farm Mob | Built-in 10 mobs always; icons = drops (flesh/bone/…) not heads |
| Floating platforms / weird paths | **One continuous floor** hub → hallway → 5 bays |
| Ladder into void / blocked | Ladder on solid wall + lit **loot room under balcony** |
| Mobs in dark zone, player unsafe | **Waist-high hit slit** + glass above; arrows/fireballs blocked |
| No water / no flow | Water sources + ice channel → drop trench |
| Chests not double | Proper LEFT/RIGHT chest block data |
| Loot falls into void | Magma pad → hopper chain → double chest under bay |
| Enderman/skeleton danger | No enderman in default list; skeleton/blaze behind slit wall |
| Community holo OK | Kept (you already saw it working) |

## Host install (do exactly)

1. Stop server or unload plugin.
2. **Delete** `plugins/MAVOMobFarm-2.0.1.jar` (and older).
3. **Delete folder** `plugins/MAVOMobFarm/` (old config + broken layout data) — important.
4. Copy `MAVOMobFarm-2.1.0.jar` → `plugins/`.
5. Start server. Confirm log: `MAVOMobFarm 2.1.0 enabled. Rooms=5 mobs=10`.
6. Stand at farm site (NOT plaza). Wipe leftovers:
   ```
   /mobfarm clearhere 120
   ```
7. Rebuild:
   ```
   /mobfarm setcenter
   /mobfarm build
   ```
8. Test:
   ```
   /mobfarm enter
   /mobfarm pick     # should show 10 icons
   ```
   Stand on balcony, hit through the **slit**. Loot → ladder east side → bay chest.  
   `/mobfarm hub` for community chest.

## Layout (each bay)

```
[dark cage + spawners + water] → [drop trench + magma] → [slit wall] → [lit balcony]
                                      ↓ hoppers
                               [loot room + double chest]
```
5 bays on one hallway north of hub (20 blocks apart).

## Admin cmds
`/mobfarm setcenter|build|rebuild|clear|clearhere [r]|reload|resholo|info`
