# MAVOMobFarm 2.2.3 — mobs actually go into the drop

**Jar:** `/home/user/jars/MAVOMobFarm-2.2.3.jar`

## What was wrong (your shots)
Mobs spawned on the **dry east pad** next to the STACK spawner, so they stood in a pile and **never entered the water canal**. The canal looked empty while the glass cage was full.

## Fix
1. **Spawn inside the water trench** (not on the spawner pad)
2. **AI off** + continuous **south velocity** toward the 2×2 drop
3. If a mob ends up on the dry pad → **teleport into canal**
4. Water sources every 2 blocks on packed-ice trench floor
5. Kill-pit centering under the hit hole

## Deploy
1. Upload 2.2.3, remove older jars
2. Restart
3. At farm:
   ```
   /mobfarm purge 150
   /mobfarm clearhere 120
   /mobfarm setcenter
   /mobfarm build
   ```
4. `/mobfarm enter` → pick zombie
5. You should see water in the canal **and** zombies streaming south into the hole under the iron bars

Hit **down** the hole to kill; loot via east ladder.
