say [MAVO builder] Building 26 jump-portal frames (13 biomes N / 13 danger S)...
forceload add -2460 -1710 -2340 -1660
fill -2446 200 -1699 -2442 204 -1699 minecraft:smooth_sandstone
fill -2445 200 -1699 -2443 203 -1699 minecraft:black_concrete
fill -2445 199 -1698 -2443 199 -1697 minecraft:smooth_sandstone
setblock -2444 199 -1698 minecraft:glowstone
fill -2439 200 -1699 -2435 204 -1699 minecraft:acacia_planks
fill -2438 200 -1699 -2436 203 -1699 minecraft:black_concrete
fill -2438 199 -1698 -2436 199 -1697 minecraft:acacia_planks
setblock -2437 199 -1698 minecraft:glowstone
fill -2432 200 -1699 -2428 204 -1699 minecraft:green_terracotta
fill -2431 200 -1699 -2429 203 -1699 minecraft:black_concrete
fill -2431 199 -1698 -2429 199 -1697 minecraft:green_terracotta
setblock -2430 199 -1698 minecraft:glowstone
fill -2425 200 -1699 -2421 204 -1699 minecraft:dark_oak_planks
fill -2424 200 -1699 -2422 203 -1699 minecraft:black_concrete
fill -2424 199 -1698 -2422 199 -1697 minecraft:dark_oak_planks
setblock -2423 199 -1698 minecraft:glowstone
fill -2418 200 -1699 -2414 204 -1699 minecraft:spruce_planks
fill -2417 200 -1699 -2415 203 -1699 minecraft:black_concrete
fill -2417 199 -1698 -2415 199 -1697 minecraft:spruce_planks
setblock -2416 199 -1698 minecraft:glowstone
fill -2411 200 -1699 -2407 204 -1699 minecraft:lime_concrete
fill -2410 200 -1699 -2408 203 -1699 minecraft:black_concrete
fill -2410 199 -1698 -2408 199 -1697 minecraft:lime_concrete
setblock -2409 199 -1698 minecraft:glowstone
fill -2404 200 -1699 -2400 204 -1699 minecraft:snow_block
fill -2403 200 -1699 -2401 203 -1699 minecraft:black_concrete
fill -2403 199 -1698 -2401 199 -1697 minecraft:snow_block
setblock -2402 199 -1698 minecraft:glowstone
fill -2397 200 -1699 -2393 204 -1699 minecraft:green_concrete
fill -2396 200 -1699 -2394 203 -1699 minecraft:black_concrete
fill -2396 199 -1698 -2394 199 -1697 minecraft:green_concrete
setblock -2395 199 -1698 minecraft:glowstone
fill -2390 200 -1699 -2386 204 -1699 minecraft:bamboo_planks
fill -2389 200 -1699 -2387 203 -1699 minecraft:black_concrete
fill -2389 199 -1698 -2387 199 -1697 minecraft:bamboo_planks
setblock -2388 199 -1698 minecraft:glowstone
fill -2383 200 -1699 -2379 204 -1699 minecraft:packed_ice
fill -2382 200 -1699 -2380 203 -1699 minecraft:black_concrete
fill -2382 199 -1698 -2380 199 -1697 minecraft:packed_ice
setblock -2381 199 -1698 minecraft:glowstone
fill -2376 200 -1699 -2372 204 -1699 minecraft:cherry_planks
fill -2375 200 -1699 -2373 203 -1699 minecraft:black_concrete
fill -2375 199 -1698 -2373 199 -1697 minecraft:cherry_planks
setblock -2374 199 -1698 minecraft:glowstone
fill -2369 200 -1699 -2365 204 -1699 minecraft:red_terracotta
fill -2368 200 -1699 -2366 203 -1699 minecraft:black_concrete
fill -2368 199 -1698 -2366 199 -1697 minecraft:red_terracotta
setblock -2367 199 -1698 minecraft:glowstone
fill -2362 200 -1699 -2358 204 -1699 minecraft:red_mushroom_block
fill -2361 200 -1699 -2359 203 -1699 minecraft:black_concrete
fill -2361 199 -1698 -2359 199 -1697 minecraft:red_mushroom_block
setblock -2360 199 -1698 minecraft:glowstone
fill -2446 200 -1671 -2442 204 -1671 minecraft:blue_terracotta
fill -2445 200 -1671 -2443 203 -1671 minecraft:black_concrete
fill -2445 199 -1673 -2443 199 -1672 minecraft:blue_terracotta
setblock -2444 199 -1672 minecraft:glowstone
fill -2439 200 -1671 -2435 204 -1671 minecraft:oak_planks
fill -2438 200 -1671 -2436 203 -1671 minecraft:black_concrete
fill -2438 199 -1673 -2436 199 -1672 minecraft:oak_planks
setblock -2437 199 -1672 minecraft:glowstone
fill -2432 200 -1671 -2428 204 -1671 minecraft:dripstone_block
fill -2431 200 -1671 -2429 203 -1671 minecraft:black_concrete
fill -2431 199 -1673 -2429 199 -1672 minecraft:dripstone_block
setblock -2430 199 -1672 minecraft:glowstone
fill -2425 200 -1671 -2421 204 -1671 minecraft:moss_block
fill -2424 200 -1671 -2422 203 -1671 minecraft:black_concrete
fill -2424 199 -1673 -2422 199 -1672 minecraft:moss_block
setblock -2423 199 -1672 minecraft:glowstone
fill -2418 200 -1671 -2414 204 -1671 minecraft:chiseled_sandstone
fill -2417 200 -1671 -2415 203 -1671 minecraft:black_concrete
fill -2417 199 -1673 -2415 199 -1672 minecraft:chiseled_sandstone
setblock -2416 199 -1672 minecraft:glowstone
fill -2411 200 -1671 -2407 204 -1671 minecraft:mossy_cobblestone
fill -2410 200 -1671 -2408 203 -1671 minecraft:black_concrete
fill -2410 199 -1673 -2408 199 -1672 minecraft:mossy_cobblestone
setblock -2409 199 -1672 minecraft:glowstone
fill -2404 200 -1671 -2400 204 -1671 minecraft:mossy_stone_bricks
fill -2403 200 -1671 -2401 203 -1671 minecraft:black_concrete
fill -2403 199 -1673 -2401 199 -1672 minecraft:mossy_stone_bricks
setblock -2402 199 -1672 minecraft:glowstone
fill -2397 200 -1671 -2393 204 -1671 minecraft:cobbled_deepslate
fill -2396 200 -1671 -2394 203 -1671 minecraft:black_concrete
fill -2396 199 -1673 -2394 199 -1672 minecraft:cobbled_deepslate
setblock -2395 199 -1672 minecraft:glowstone
fill -2390 200 -1671 -2386 204 -1671 minecraft:dark_oak_log
fill -2389 200 -1671 -2387 203 -1671 minecraft:black_concrete
fill -2389 199 -1673 -2387 199 -1672 minecraft:dark_oak_log
setblock -2388 199 -1672 minecraft:glowstone
fill -2383 200 -1671 -2379 204 -1671 minecraft:prismarine_bricks
fill -2382 200 -1671 -2380 203 -1671 minecraft:black_concrete
fill -2382 199 -1673 -2380 199 -1672 minecraft:prismarine_bricks
setblock -2381 199 -1672 minecraft:glowstone
fill -2376 200 -1671 -2372 204 -1671 minecraft:stone_bricks
fill -2375 200 -1671 -2373 203 -1671 minecraft:black_concrete
fill -2375 199 -1673 -2373 199 -1672 minecraft:stone_bricks
setblock -2374 199 -1672 minecraft:glowstone
fill -2369 200 -1671 -2365 204 -1671 minecraft:waxed_copper_block
fill -2368 200 -1671 -2366 203 -1671 minecraft:black_concrete
fill -2368 199 -1673 -2366 199 -1672 minecraft:waxed_copper_block
setblock -2367 199 -1672 minecraft:glowstone
fill -2362 200 -1671 -2358 204 -1671 minecraft:sculk
fill -2361 200 -1671 -2359 203 -1671 minecraft:black_concrete
fill -2361 199 -1673 -2359 199 -1672 minecraft:sculk
setblock -2360 199 -1672 minecraft:glowstone
forceload remove -2460 -1710 -2340 -1660
say [MAVO builder] PORTAL FRAMES DONE. Drop in MAVOPortalRoom jar for FX/holos/jumps.
