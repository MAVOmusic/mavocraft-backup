say [MAVO builder] Portal Room: clearing interior...
fill -2449 199 -1699 -2351 209 -1671 minecraft:air
fill -2449 210 -1699 -2351 220 -1671 minecraft:air
fill -2449 221 -1699 -2351 227 -1671 minecraft:air
say [MAVO builder] Portal Room: bedrock shell...
fill -2450 198 -1700 -2350 198 -1670 minecraft:bedrock
fill -2450 228 -1700 -2350 228 -1670 minecraft:bedrock
fill -2450 199 -1700 -2350 227 -1700 minecraft:bedrock
fill -2450 199 -1670 -2350 227 -1670 minecraft:bedrock
fill -2450 199 -1699 -2450 227 -1671 minecraft:bedrock
fill -2350 199 -1699 -2350 227 -1671 minecraft:bedrock
say [MAVO builder] Portal Room: lining...
fill -2449 199 -1699 -2351 199 -1671 minecraft:polished_deepslate
fill -2449 227 -1699 -2351 227 -1671 minecraft:polished_deepslate
fill -2449 200 -1699 -2351 226 -1699 minecraft:deepslate_tiles
fill -2449 200 -1671 -2351 226 -1671 minecraft:deepslate_tiles
fill -2449 200 -1698 -2449 226 -1672 minecraft:deepslate_tiles
fill -2351 200 -1698 -2351 226 -1672 minecraft:deepslate_tiles
say [MAVO builder] Portal Room: accents...
fill -2444 200 -1699 -2444 226 -1699 minecraft:red_nether_bricks
fill -2444 200 -1671 -2444 226 -1671 minecraft:red_nether_bricks
fill -2432 200 -1699 -2432 226 -1699 minecraft:red_nether_bricks
fill -2432 200 -1671 -2432 226 -1671 minecraft:red_nether_bricks
fill -2420 200 -1699 -2420 226 -1699 minecraft:red_nether_bricks
fill -2420 200 -1671 -2420 226 -1671 minecraft:red_nether_bricks
fill -2408 200 -1699 -2408 226 -1699 minecraft:red_nether_bricks
fill -2408 200 -1671 -2408 226 -1671 minecraft:red_nether_bricks
fill -2396 200 -1699 -2396 226 -1699 minecraft:red_nether_bricks
fill -2396 200 -1671 -2396 226 -1671 minecraft:red_nether_bricks
fill -2384 200 -1699 -2384 226 -1699 minecraft:red_nether_bricks
fill -2384 200 -1671 -2384 226 -1671 minecraft:red_nether_bricks
fill -2372 200 -1699 -2372 226 -1699 minecraft:red_nether_bricks
fill -2372 200 -1671 -2372 226 -1671 minecraft:red_nether_bricks
fill -2360 200 -1699 -2360 226 -1699 minecraft:red_nether_bricks
fill -2360 200 -1671 -2360 226 -1671 minecraft:red_nether_bricks
fill -2448 199 -1686 -2352 199 -1684 minecraft:nether_bricks
say [MAVO builder] Portal Room: HEAVY lighting...
fill -2449 199 -1697 -2351 199 -1697 minecraft:ochre_froglight
fill -2449 199 -1691 -2351 199 -1691 minecraft:ochre_froglight
fill -2449 199 -1679 -2351 199 -1679 minecraft:ochre_froglight
fill -2449 199 -1673 -2351 199 -1673 minecraft:ochre_froglight
fill -2446 199 -1699 -2446 199 -1671 minecraft:ochre_froglight
fill -2438 199 -1699 -2438 199 -1671 minecraft:ochre_froglight
fill -2430 199 -1699 -2430 199 -1671 minecraft:ochre_froglight
fill -2422 199 -1699 -2422 199 -1671 minecraft:ochre_froglight
fill -2414 199 -1699 -2414 199 -1671 minecraft:ochre_froglight
fill -2406 199 -1699 -2406 199 -1671 minecraft:ochre_froglight
fill -2398 199 -1699 -2398 199 -1671 minecraft:ochre_froglight
fill -2390 199 -1699 -2390 199 -1671 minecraft:ochre_froglight
fill -2382 199 -1699 -2382 199 -1671 minecraft:ochre_froglight
fill -2374 199 -1699 -2374 199 -1671 minecraft:ochre_froglight
fill -2366 199 -1699 -2366 199 -1671 minecraft:ochre_froglight
fill -2358 199 -1699 -2358 199 -1671 minecraft:ochre_froglight
fill -2449 227 -1693 -2351 227 -1693 minecraft:ochre_froglight
fill -2449 227 -1685 -2351 227 -1685 minecraft:ochre_froglight
fill -2449 227 -1677 -2351 227 -1677 minecraft:ochre_froglight
fill -2449 205 -1699 -2351 205 -1699 minecraft:sea_lantern
fill -2449 205 -1671 -2351 205 -1671 minecraft:sea_lantern
fill -2450 200 -1686 -2449 203 -1684 minecraft:air
say [MAVO builder] PORTAL ROOM DONE.
