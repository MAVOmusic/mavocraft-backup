say [MAVO builder] Forceloading build areas...
forceload add -2810 -1715 -2690 -1655
forceload add -2460 -1710 -2340 -1660
function mavocraft:portal_room
function mavocraft:portal_frames
function mavocraft:vault_shell
function mavocraft:vault_build
function mavocraft:purge_mobs
forceload remove -2810 -1715 -2690 -1655
forceload remove -2460 -1710 -2340 -1660
say [MAVO builder] ALL DONE!
