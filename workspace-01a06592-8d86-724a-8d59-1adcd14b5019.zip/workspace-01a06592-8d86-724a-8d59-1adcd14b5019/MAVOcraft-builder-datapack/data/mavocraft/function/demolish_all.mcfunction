say [MAVO builder] Demolishing both rooms...
forceload add -2810 -1715 -2690 -1655
forceload add -2460 -1710 -2340 -1660
fill -2800 198 -1705 -2700 204 -1665 minecraft:air
fill -2800 205 -1705 -2700 211 -1665 minecraft:air
fill -2800 212 -1705 -2700 218 -1665 minecraft:air
fill -2800 219 -1705 -2700 225 -1665 minecraft:air
fill -2800 226 -1705 -2700 232 -1665 minecraft:air
fill -2800 233 -1705 -2700 238 -1665 minecraft:air
fill -2450 198 -1700 -2350 207 -1670 minecraft:air
fill -2450 208 -1700 -2350 217 -1670 minecraft:air
fill -2450 218 -1700 -2350 227 -1670 minecraft:air
fill -2450 228 -1700 -2350 228 -1670 minecraft:air
forceload remove -2810 -1715 -2690 -1655
forceload remove -2460 -1710 -2340 -1660
say [MAVO builder] Demolished.
