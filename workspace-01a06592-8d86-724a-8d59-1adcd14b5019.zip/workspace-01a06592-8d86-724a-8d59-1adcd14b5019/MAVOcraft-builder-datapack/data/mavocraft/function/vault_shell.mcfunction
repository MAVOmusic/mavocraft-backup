say [MAVO builder] Vault: clearing interior...
fill -2799 199 -1704 -2701 206 -1666 minecraft:air
fill -2799 207 -1704 -2701 214 -1666 minecraft:air
fill -2799 215 -1704 -2701 222 -1666 minecraft:air
fill -2799 223 -1704 -2701 230 -1666 minecraft:air
fill -2799 231 -1704 -2701 237 -1666 minecraft:air
say [MAVO builder] Vault: bedrock shell...
fill -2800 198 -1705 -2700 198 -1665 minecraft:bedrock
fill -2800 238 -1705 -2700 238 -1665 minecraft:bedrock
fill -2800 199 -1705 -2700 237 -1705 minecraft:bedrock
fill -2800 199 -1665 -2700 237 -1665 minecraft:bedrock
fill -2800 199 -1704 -2800 237 -1666 minecraft:bedrock
fill -2700 199 -1704 -2700 237 -1666 minecraft:bedrock
say [MAVO builder] Vault: lining...
fill -2799 199 -1704 -2701 199 -1666 minecraft:polished_deepslate
fill -2799 237 -1704 -2701 237 -1666 minecraft:polished_blackstone
fill -2799 200 -1704 -2701 236 -1704 minecraft:polished_blackstone
fill -2799 200 -1666 -2701 236 -1666 minecraft:polished_blackstone
fill -2799 200 -1703 -2799 236 -1667 minecraft:polished_blackstone
fill -2701 200 -1703 -2701 236 -1667 minecraft:polished_blackstone
fill -2792 200 -1704 -2792 236 -1704 minecraft:gilded_blackstone
fill -2792 200 -1666 -2792 236 -1666 minecraft:gilded_blackstone
fill -2776 200 -1704 -2776 236 -1704 minecraft:gilded_blackstone
fill -2776 200 -1666 -2776 236 -1666 minecraft:gilded_blackstone
fill -2760 200 -1704 -2760 236 -1704 minecraft:gilded_blackstone
fill -2760 200 -1666 -2760 236 -1666 minecraft:gilded_blackstone
fill -2744 200 -1704 -2744 236 -1704 minecraft:gilded_blackstone
fill -2744 200 -1666 -2744 236 -1666 minecraft:gilded_blackstone
fill -2728 200 -1704 -2728 236 -1704 minecraft:gilded_blackstone
fill -2728 200 -1666 -2728 236 -1666 minecraft:gilded_blackstone
fill -2712 200 -1704 -2712 236 -1704 minecraft:gilded_blackstone
fill -2712 200 -1666 -2712 236 -1666 minecraft:gilded_blackstone
say [MAVO builder] Vault: HEAVY lighting...
fill -2796 199 -1704 -2796 199 -1666 minecraft:glowstone
fill -2788 199 -1704 -2788 199 -1666 minecraft:glowstone
fill -2780 199 -1704 -2780 199 -1666 minecraft:glowstone
fill -2772 199 -1704 -2772 199 -1666 minecraft:glowstone
fill -2764 199 -1704 -2764 199 -1666 minecraft:glowstone
fill -2756 199 -1704 -2756 199 -1666 minecraft:glowstone
fill -2748 199 -1704 -2748 199 -1666 minecraft:glowstone
fill -2740 199 -1704 -2740 199 -1666 minecraft:glowstone
fill -2732 199 -1704 -2732 199 -1666 minecraft:glowstone
fill -2724 199 -1704 -2724 199 -1666 minecraft:glowstone
fill -2716 199 -1704 -2716 199 -1666 minecraft:glowstone
fill -2708 199 -1704 -2708 199 -1666 minecraft:glowstone
fill -2799 199 -1701 -2701 199 -1701 minecraft:glowstone
fill -2799 199 -1693 -2701 199 -1693 minecraft:glowstone
fill -2799 199 -1677 -2701 199 -1677 minecraft:glowstone
fill -2799 199 -1669 -2701 199 -1669 minecraft:glowstone
fill -2799 205 -1704 -2701 205 -1704 minecraft:sea_lantern
fill -2799 205 -1666 -2701 205 -1666 minecraft:sea_lantern
fill -2799 237 -1695 -2701 237 -1695 minecraft:glowstone
fill -2799 237 -1685 -2701 237 -1685 minecraft:glowstone
fill -2799 237 -1675 -2701 237 -1675 minecraft:glowstone
fill -2701 200 -1686 -2700 203 -1684 minecraft:air
say [MAVO builder] VAULT SHELL DONE.
