# TAB + stream layout (15-line limit)

## Hard Minecraft limit
The right sidebar can show **at most 15 lines**. Your old config had 26 → professions/coords never appeared. TAB warned on boot.

There is **no left sidebar** in Java Edition. Options:
| Surface | Where | Good for stream? |
|---------|--------|------------------|
| Scoreboard | Right side only | Yes if ≤15 lines and short |
| Header/footer | Only while holding **TAB** | Fine (not always on screen) |
| Bossbar | Top center | Optional day/coins later |
| Action bar | Above hotbar | `/hud` toggle |

## New boards (`config.yml`)
1. **`stream`** (default) — compact under Sub Goal  
   name, level, time, day+deaths, coins, 3 dual-prof lines, coords  
2. **`grind`** — full 9 professions — cycle with **`/sb`**

## Install
1. Upload `config.yml` → `plugins/TAB/config.yml`
2. `/tab reload`
3. **Day 1** (Hud 2.2.0 is loaded — you still show Day 108 until you run this):
```
/hud setday 1
/tab reload
/papi parse me %mavohud_day%
```

## Stream facecam
Spacers are only **2** lines now (Sub Goal clearance) so we stay ≤15.  
If still overlapping facecam, you cannot push content infinitely down — cut lines instead, or move facecam slightly up/left in OBS, or shrink Sub Goal widget.

## If you want almost empty right side while streaming
`/sb` until hidden (if toggle hides), or set `hidden-by-default: true` and only enable when not live.
