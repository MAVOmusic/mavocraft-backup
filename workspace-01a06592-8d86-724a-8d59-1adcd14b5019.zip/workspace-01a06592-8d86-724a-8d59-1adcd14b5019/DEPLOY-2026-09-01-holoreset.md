# Deploy — Holo reset (MAVOWild 1.7.1)

## Upload
- plugins/MAVOWild-1.7.1.jar  (remove 1.7.0 / 1.6.2)
- plugins/MAVOGuide-2.5.4.jar (optional)

## Fix stale 2,000-5,000 Wild Portal text
1. Restart (or replace jar + /reload is NOT enough — restart)
2. Join, go to plaza center
3. Brief OP (or already console-op for admin):

```
/holoreset
```

Default radius **60**. Or `/holoreset 80` / `/wild holoreset 60`.

You should see: removed N floating signs, Wild holo now **2,000–400,000**.

Boot also auto-refreshes portal holos 3s after enable and migrates max-radius
if it was still 5000.
