# MAVOMobFarm 2.0.0 — deploy & rebuild

**Jar:** `/home/user/jars/MAVOMobFarm-2.0.0.jar`  
**Replace:** remove `MAVOMobFarm-1.0.0.jar` from plugins (broken iron-door tower design).

## What changed (fixes your 10 failures)

| Problem (1.0) | 2.0 fix |
|---|---|
| Dark hub → mobs on pad | **Lit hub** (sea lantern checker + glowstone pillars) |
| Lit rooms → no spawns | **Sealed dark cage** per bay (no lights for hostiles) |
| Iron-door / Y-tower spawners through ceiling | **3×3 grid, max 4 layers under solid ceiling** — extras stack same cells |
| Only 1/5 rooms useful | **5 independent bays** (offsets ±70 / ±35 / 0) |
| No mob choice / wrong env | **`/mobfarm pick` GUI** + theme (dark / nether / animal) |
| No kill pad / unsafe | **Balcony + glass + kill pad + magma**; water push + velocity nudge |
| Hoppers under unused spots | **Hopper → double chest under kill pad**; ladder to loot |
| No loot to hub / unlabeled community | **Hub community chest + oak sign + TextDisplay holo**; close inventory = donate value |
| No TP hub | **`/mobfarm hub`** |
| Extras reset / session | Same economy rules: entry 5k, 10s cancel, 30m session, leave keeps timer, extras double cost, cleared on end, community stack goals |

## Install on host

1. Stop server (or at least unload old plugin).
2. Delete `plugins/MAVOMobFarm-1.0.0.jar` and preferably wipe `plugins/MAVOMobFarm/` (old layout data).
3. Copy `MAVOMobFarm-2.0.0.jar` → `plugins/`.
4. Start / `plugman load` (full restart safer).
5. **Undo the old build** at ~`-3540, 198, -1652` (WorldEdit `//undo` chain if you still have it, or manually clear the iron tower / rooms).
6. Bays spawn **40 blocks north** of hub (config offsets). Stand where you want the **new hub** (NOT plaza — far farm site is fine):
   ```
   /mobfarm setcenter
   /mobfarm build
   ```
   If something looks wrong: `/mobfarm rebuild` (clear + rebuild) or `/mobfarm clear`.
7. Test:
   ```
   /mobfarm enter
   /mobfarm pick          # choose zombie etc.
   /mobfarm buy           # extra spawner (same cage stack)
   /mobfarm hub           # community chest
   /mobfarm leave         # timer keeps
   /mobfarm status
   /mobfarm info
   ```

## Player flow

1. `/mobfarm enter` — pay 5k, stand still 10s.
2. Assigned free bay → teleported to **lit balcony**.
3. Pick GUI opens → choose mob (env auto-applies).
4. Stand on balcony; mobs spawn in dark cage, water + push → kill pad; hit through glass / drop edge.
5. Loot falls to hopper → chest under pad (ladder on side).
6. Optional: dump farm loot in **COMMUNITY FARM CHEST** at hub (sign + holo). Counts toward stack goals (1M → base 6, etc.).
7. `/mobfarm leave` parks you; timer continues. Re-`enter` free while session live.
8. Session end: extras wiped, base spawners = community stack, TP return.

## Admin

| Cmd | |
|---|---|
| `/mobfarm setcenter` | Hub origin (your feet) |
| `/mobfarm build` | First build |
| `/mobfarm rebuild` | Wipe volume + rebuild |
| `/mobfarm clear` | Wipe only |
| `/mobfarm resholo` | Refresh community TextDisplay |

## Config knobs (`plugins/MAVOMobFarm/config.yml`)

- `entry-cost`, `entry-cancel-seconds`, `session-minutes`
- `profession-xp-scale: 0.30` (API: `isFarmKill` / `farmXpScale`)
- `base-spawners` / community `stack-start` & `start-target`
- `extra-spawner-base-cost` (doubles each buy)
- `max-spawners: 25`
- `rooms.roomN.offset` — bay spacing
- `mobs.*` — add more types anytime

## Rebuild from this workspace

```bash
export JAVA_HOME=/tmp/jdk
export PATH=/tmp/jdk/bin:/home/user/_Old/apache-maven-3.9.6/bin:$PATH
cd /home/user/_Old/src-mobfarm && mvn -q package -DskipTests
cp target/MAVOMobFarm-2.0.0.jar /home/user/jars/
```

Source: `_Old/src-mobfarm/` (~1050-line `MobFarm.java`).
