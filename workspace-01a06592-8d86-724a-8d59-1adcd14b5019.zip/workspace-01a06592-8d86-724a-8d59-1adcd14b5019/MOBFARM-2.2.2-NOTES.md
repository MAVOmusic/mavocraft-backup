# MAVOMobFarm 2.2.2 — clear actually STOPS the farm

**Jar:** `/home/user/jars/MAVOMobFarm-2.2.2.jar`

## What you saw
`/mobfarm clearhere` only deleted **blocks**. Active sessions kept their **spawn tasks** running, so zombies + STACK holos kept appearing on leftover water/air columns.

## Fix
`clear` / `clearhere` / new `purge` now:
1. **Cancel all spawn tasks** + end every session
2. **Remove farm-tagged mobs** + chicken leftovers in radius
3. **Delete STACK / COMMUNITY holos** (including floating orphans)
4. Then wipe blocks (`clear`/`clearhere`)
5. Mark farm not built

## Right now on host (ghost mobs/holos)

Upload 2.2.2, restart, stand in the mess:
```
/mobfarm purge 150
```
That stops sessions + deletes sky zombies/holos **without** needing a rebuild.

Then if you still want empty space:
```
/mobfarm clearhere 120
```

Then rebuild:
```
/mobfarm setcenter
/mobfarm build
```

## Commands
| Cmd | |
|---|---|
| `/mobfarm purge [r]` | Stop sessions + kill farm mobs/holos only |
| `/mobfarm clearhere [r]` | purge + air cube |
| `/mobfarm clear` | purge + wipe saved complex bounds |
