# MAVOMobFarm 2.4.0 + Achievements 1.7.0 + LuckyCoins 1.5.2 + PersonalVault 1.0.0

## Jars
| Jar | Path | Size |
|-----|------|------|
| MobFarm 2.4.0 | `/home/user/jars/MAVOMobFarm-2.4.0.jar` | ~52 KB |
| Achievements 1.7.0 | `/home/user/jars/MAVOAchievements-1.7.0.jar` | ~20 KB |
| LuckyCoins 1.5.2 | `/home/user/jars/MAVOLuckyCoins-1.5.2.jar` | ~24 KB |
| PersonalVault 1.0.0 | `/home/user/jars/MAVOPersonalVault-1.0.0.jar` | ~12 KB |

## OP teleport (new hub)
```
/tp @s -15000 200 -2000
```
Then:
```
/mobfarm setcenter
/mobfarm build
```

## MobFarm 2.4 highlights
- **Hub default** `-15000 200 -2000` (far west of plaza/vault ~-4000)
- **Hostile wing** west (−X), **animal wing** east (+X) — each mob = unique bay style
- Styles: `pad` `feet` `spider` `enderman` `blaze` `slime` `water` `pen`
- **Protect radius 50** around farm AABB only (break/place/bucket/ignite blocked; chests OK; creative/admin bypass)
- **Blacklist** plaza/vault/portal boxes: no nether/end portal, pearl, chorus dumps (walk + `/spawn` + commands OK)
- **Paid unlock** = P/16 (default **625** coins) via `/mobfarm pick` — **no free spawner**
- Enter shows **red** warning: need ≥ unlock coins for cheapest spawner
- **Extras:** P/8, P/4, P/2, P, then double (1250→2500→5000→10000→20000…)
- `/mobfarm prices` full list
- Session HUD, AI toggle, sun-safe, last-damager credit kept
- Enderman teleport cancelled; creeper prime cancelled in farm; slime size forced 1
- Pick teleports you to that mob’s zone only

## Achievements 1.7.0 (critical fix)
- `onKill` now ticks **`kill_<entity>`** mastery categories (was only `combat`)
- Variants alias: husk/drowned→zombie, stray/wither_skel→skeleton, cave_spider→spider, etc.
- Expanded kill_* list (husk, stray, witch, pillager, …)
- **Replace** old achievements jar; merge config or let new defaults load

## LuckyCoins 1.5.2
- Public API: `countCoins` / `hasCoins` / `takeCoins` / `giveCoins` / `isLuckyCoin`
- LC remain **physical sunflower items** in inventory

## Personal Vault 1.0.0
- Commands: `/pvault` `/pv` `/personal` `/personalvault`
- **First 5 slots:** 25 000 coins
- **Next packs of 5:** 250 LC, 500 LC, 750 LC, 1000 LC, 1250 LC… (+250 each pack)
- Server-side storage → **death-safe** (not inventory shulkers)
- Requires MAVOLuckyCoins 1.5.2+ for LC packs

## Host deploy order
1. Stop / unload plugins
2. Remove old: `MAVOMobFarm-2.3*`, `MAVOAchievements-1.6*`, `MAVOLuckyCoins-1.5.1`
3. Drop all four new jars
4. Optional: delete `plugins/MAVOMobFarm/` data for clean community stack
5. Start server
6. OP:
```
/tp @s -15000 200 -2000
/mobfarm setcenter
/mobfarm purge 200
/mobfarm build
/mobfarm prices
/mobfarm info
```
7. Clear OLD farm at ~-4036 if still standing:
```
/tp @s -4036 200 -2027
/mobfarm clearhere 120
```
8. Test `/pvault` unlock; `/ccollect give 10` for LC tests

## Fine-tune later
Each bay style is a first pass — tweak geometry per mob after playtest without rewriting economy/protect.
