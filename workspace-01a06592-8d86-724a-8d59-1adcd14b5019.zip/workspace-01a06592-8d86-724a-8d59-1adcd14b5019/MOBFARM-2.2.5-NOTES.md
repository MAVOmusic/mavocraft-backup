# MAVOMobFarm 2.2.5 — mobs spawn ON the kill pad (community grind fix)

**Jar:** `/home/user/jars/MAVOMobFarm-2.2.5.jar`

## Problem
Mobs had AI off and spawned in the water canal. With no current/pathfinding they stood still — unusable for survival grinding.

## Fix
- Spawn **directly under the hit hole** (kill-pad carpet)
- Every 5 ticks: any farm mob not on the pad is **teleported onto the pad**
- AI stays off (no climbing out / shooting weirdness)
- Water stream kept cosmetic; movement is plugin-driven to the pad

Ladder + hopper loot path from 2.2.4 unchanged.

## Deploy (community)
1. Put `MAVOMobFarm-2.2.5.jar` in plugins; remove 2.2.4 and older
2. Restart
3. At farm:
   ```
   /mobfarm purge 150
   /mobfarm clearhere 120
   /mobfarm setcenter
   /mobfarm build
   ```
4. Players: `/mobfarm enter` → pick → stand at iron bars → **hit DOWN** — zombies should be right under the hole

Stack still: `/mobfarm buy` → STACK xN on same block.
