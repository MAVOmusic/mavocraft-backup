# After Step 4 — remaining checklist

Server is up. Logs look good except CommunityGoals api-version (fixed jar **1.2.1** below).

## A) Fix CommunityGoals (2 min)
Your log had:
```
Fatal error trying to convert MAVOCommunityGoals ... api-version
```
It still *enabled*, but fix properly:

1. Stop OR just replace jar live then `/reload confirm` is risky — prefer:
   - Upload `jars/MAVOCommunityGoals-1.2.1.jar`
   - Delete `MAVOCommunityGoals-1.2.0.jar`
   - Restart once when convenient  
   OR replace jar and restart now (quick).

## B) TAB — edit `plugins/TAB/config.yml`

Find the **scoreboard** section (right-hand sidebar). Set title + lines to:

```
title: "&6&lMAVOcraft"
lines:
  - "&8---------------"
  - "%mavohud_tab_name%"
  - "%mavohud_level_line%"
  - "&8---------------"
  - "%mavohud_coords%"
  - "&fDay &e%mavohud_day%  &c☠ %mavohud_deaths%"
  - "%mavohud_time%"
```

Then in console or game:
```
/tab reload
```

Check:
- Day shows **1** (if level.dat stuck)
- Level shows **Lv 1** (fresh)
- Deaths **0**
- Coords update when you move

If placeholders show as raw `%mavohud_...%`:
```
/papi list
/papi parse me %mavohud_day%
```
Should print a number. Hud already registered in log.

Full paste file: `TAB-CONFIG-PASTE.yml`

## C) Join the server (you)

1. Confirm spawn / inventory empty-ish / money 0 (Essentials wipe).
2. Open guide if it auto-opens: `/guide`
3. Build structures:

```
/tavern build20
```
(stand where the inn should be — spawn plaza edge)

```
/mobfarm setcenter
/mobfarm build
```
(stand ~500 blocks from vault plaza, or wherever you want the farm)

4. Sanity:
```
/prof
/goal
/casino
/hud
/mobfarm info
/tavern info
```

5. Optional owner tag for TAB:
```
lp user MAVOmusicYT permission set mavocraft.owner true
```
(gives `[OWNER]` via %mavohud_tab_name%)

6. When setup done and you want pure survival:
```
deop MAVOmusicYT
```
(keep console for admin)

## D) Day still not 1?
After boot Paper may have rewritten `world/level.dat`. Check file size in panel.
- If still ~500 B and Time wrong: re-upload patched `level-dat-DAY1/level.dat` while **stopped**.
- If now larger: NBT-edit `Data.Time` → 0 only.

## E) You can skip for later
- ESGUI shop % from community goals (not auto-wired)
- Fine-tuning TAB layout width
- Uploading new backup zip to GitHub

## Done when
- [ ] Goals 1.2.1 jar in plugins
- [ ] TAB lines with mavohud placeholders + `/tab reload`
- [ ] Day 1 on TAB
- [ ] `/tavern build20` done
- [ ] `/mobfarm setcenter` + `build` done
- [ ] Guide seen / `/prof` slow grind felt
- [ ] deop when ready to play for real
