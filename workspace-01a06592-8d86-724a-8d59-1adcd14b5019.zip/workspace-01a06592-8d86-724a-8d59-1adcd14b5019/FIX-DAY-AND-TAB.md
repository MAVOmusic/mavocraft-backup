# Fix Day 107 + stream TAB position + owner tag

## What the screenshot shows (working)
- `[OWNER] MAVOmusicYT` — **already works** on the scoreboard (red tag). LP LuckPerms “prefix in chat” is separate; scoreboard uses `%mavohud_tab_name%`.
- `Lv 1 (0%)` — good
- Professions “not started” — good (fresh)
- Coins 20 — streak bonus

## Day 107 — why
`%mavohud_day%` reads **world fullTime**. Your world age never became day 1 (level.dat patch didn’t stick or Paper rewrote Time).  
107 ≈ still on old world clock.

### Fix A — instant (no restart of world file): MAVOHud 2.2.0
1. Upload `jars/MAVOHud-2.2.0.jar` → `plugins/`
2. Delete `MAVOHud-2.1.0.jar`
3. Restart **or** `/reload` is bad — **restart** once
4. Console or op:
```
/hud setday 1
```
That sets `day-offset` so display day = 1 while world keeps ticking.
5. `/tab reload`

Check: `/hud day` and `/papi parse me %mavohud_day%` → **1**

### Fix B — real world clock (optional later)
Stop server, NBT-edit real `world/level.dat` `Data.Time` = 0, then `/hud setday 1` again (or set day-offset 0 in `plugins/MAVOHud/config.yml`).

---

## TAB lower (under Sub Goal / facecam)

Upload new **`config.yml`** → `plugins/TAB/config.yml`

Changes:
- Scoreboard **title** blank (`&r`) so the big gradient title isn’t stuck at the very top under the stream cam
- **6 blank spacer lines** at the top of the sidebar
- Then **MAVOcraft** brand line, then name / level / day / professions

After upload:
```
/tab reload
```

If still too high or too low: add/remove `&r` spacer lines at the top of `scoreboard1.lines` (each line ≈ one row).

Stream layout target:
```
[ facecam + SUB GOAL ]   ← overlay
     (empty TAB rows)
MAVOcraft
[OWNER] name
Lv 1 ...
Day 1  ☠ 0
...
```

---

## Owner tag notes
- Scoreboard: already `[OWNER]` via `mavocraft.owner` — **you have this**
- Chat / player list name: set LuckPerms prefix if you want it there too:
```
lp user MAVOmusicYT meta setprefix "&c&l[OWNER] &f"
lp user MAVOmusicYT parent set default
```
(or add to owner group)

---

## Order of operations NOW
1. Upload MAVOHud-2.2.0.jar (remove 2.1.0)
2. Upload TAB config.yml
3. Restart server (for Hud jar)
4. `/hud setday 1`
5. `/tab reload`
6. Confirm Day 1 and sidebar sits under Sub Goal
7. Continue: `/tavern build20`, `/mobfarm setcenter` + `build`
