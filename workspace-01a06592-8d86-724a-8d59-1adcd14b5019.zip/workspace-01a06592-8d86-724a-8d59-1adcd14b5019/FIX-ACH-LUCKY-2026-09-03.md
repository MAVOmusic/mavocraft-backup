# Hotfix: Achievements 1.7.1 + LuckyCoins 1.5.3

## Cause
- **`/achievements` AIOOBE:** GUI assumed ≤36 categories in a 5-row chest. With 43 categories (new kill_*), slots went to index 51 → crash.
- **Wishing well:** Toss handler could fail mid-event (particle/API) after removing the coin with no refund; also tight radius. Hardened.

## Fix
- Achievements: **paged GUI** (28 cats/page, prev/next), safe slot map, `MenuHolder.page`
- LuckyCoins: cancel drop, consume hand, wider well radius, safe particles, refund on wish failure

## Deploy
Replace jars:
- `MAVOAchievements-1.7.1.jar` (remove 1.7.0)
- `MAVOLuckyCoins-1.5.3.jar` (remove 1.5.2)

Restart or plugman reload both.

## Test
1. `/achievements` → pages of categories, click works
2. Stand at well, Q toss Lucky Coin → prize + broadcast
3. If broken: `/wish well` as op to re-set well coords
