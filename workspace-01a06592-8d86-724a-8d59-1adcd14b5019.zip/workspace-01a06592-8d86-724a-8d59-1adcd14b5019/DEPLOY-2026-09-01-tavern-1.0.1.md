# Deploy — MAVOTavern 1.0.1 (bed lock fix)

## Bug
After paying to skip night → morning, day-index lock stayed on the SAME MC day,
so the next evening (e.g. 20:42) still said "already rested tonight" until the
*following* noon. One night skip blocked the next night.

## Fix
Lock is now "until next noon" on absolute world fullTime.
Sleep at night → wake morning → unlock at **that day's noon** → free again for
the following night.

Legacy `used.<uuid>` day indexes migrate automatically on load.

## Upload
plugins/MAVOTavern-1.0.1.jar

## Immediate unblock (optional)
```
/tavern unlock
/tavern unlock MAVOmusicYT
```
