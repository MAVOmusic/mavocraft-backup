# MAVOMobFarm 2.2.0 — sealed drop grinder + TRUE spawner stacks

**Jar:** `/home/user/jars/MAVOMobFarm-2.2.0.jar`  
Remove older MAVOMobFarm jars. **Delete `plugins/MAVOMobFarm/`** then restart.

## Why "stacked spawners" need a plugin

Vanilla Minecraft **cannot** put multiple spawners in one block. Servers that show `Stack x12` on one spawner use a plugin that multiplies spawn rate. That is what 2.2 does:

- **One physical spawner block** (display)
- Hologram **STACK xN**
- `/mobfarm buy` increases N on that **same block**
- Plugin spawns ≈ N mobs per pulse (capped), so x10 is ~10× productive

## Layout (classic tutorial style)

```
[sealed dark box + STACK spawner]
        water canal (glass sides)
              ↓ drop shaft
   [kill cell under floor: carpet on hoppers]
              ↑ hit DOWN through 1×2 hole
        [lit balcony — player safe]
              stairs → loot closet (solid floor, real double chest)
```

Skeletons **cannot** shoot you (you hit from above; walls seal LOS).

## Fixes vs 2.1 screenshots

| Issue | 2.2 |
|---|---|
| Water spills / no flow | Glass-sided canal + sources |
| Skeleton shoots player | Top-down kill hole only |
| Chests not double | LEFT/RIGHT chest data + verify swap |
| Ladder into void | Stairs + solid deepslate floor closet |
| Hoppers empty | Full hopper floor under carpet + chain to chest |
| Fake multi-block towers | True same-block stack ×N |

## Host steps

1. Upload jar, delete old jars + `plugins/MAVOMobFarm/`
2. Restart — log: `MAVOMobFarm 2.2.0 enabled. … mobs=10`
3. At farm site:
   ```
   /mobfarm clearhere 120
   /mobfarm setcenter
   /mobfarm build
   ```
4. `/mobfarm enter` → pick → stand at iron-bar hole → hit **down**  
   `/mobfarm buy` → holo shows STACK x6, x7…

## Economy (unchanged)

Entry 5k · 10s cancel · 30m session · leave keeps timer · extras double cost · wipe extras on end · community donations raise base stack.
