# MAVOMobFarm 2.3.0 — AI, HUD, sun-safe, base×2, more mobs, bay community

**Jar:** `/home/user/jars/MAVOMobFarm-2.3.0.jar` (49768 B)  
**Source:** `/home/user/_Old/src-mobfarm/` (pom/plugin **2.3.0**)

## Fixes / features vs 2.2.5

### 1. Mob AI toggle (config + live reload)
- `mob-ai: true` (default) — pathfinding on; gentle pull toward kill pad.
- `mob-ai: false` — frozen pin on pad (2.2.5 behaviour).
- `/mobfarm reload` reloads config and applies AI/HUD to live sessions.

### 2. Sun-safe kill pad (achievement kills)
- `sun-safe-killpad: true` — solid roof over hole/pad + `setFireTicks(0)` each tick.
- Cancels FIRE / FIRE_TICK / LAVA / HOT_FLOOR damage on tagged farm mobs.
- `credit-last-damager: true` — last player hit stored; on death `setKiller` so achievements get combat credit.

### 3. 30-min session BossBar HUD
- `session-hud: true` + title template with `{mm}` `{ss}` `{stack}`.
- Shown only while near farm center (~90 blocks).
- Leave/TP out: bar hides, **timer keeps ticking silently**.
- `/mobfarm enter` while session live: free return, **same stack/extras**, HUD back — **no reset**.
- Session end still clears bought extras (as before).

### 4. Base stack 2 + doubling buy prices
- `base-spawners: 2` + `community.stack-start: 2`.
- First **extra** cost = `normal-spawner-price` × `extra-price-multiplier` (default **10000 × 4 = 40000**).
- Each further buy **doubles** previous (2nd extra 80000, 3rd 160000, …).
- Mapping old “6th→3rd”: base is now 2, so third paid extra = old 6th slot on the doubling curve.

### 5. More mobs + themes
19 mobs: zombie, husk, skeleton, stray, spider, cave_spider, creeper, enderman, blaze, magma_cube, wither_skeleton, drowned, guardian, cow, pig, chicken, sheep, rabbit, slime.  
Themes: `dark` | `nether` | `animal` | `ocean` | `end` (floor/ceil cosmetics).

### 6. Per-cell community chest + holo
- Double chest + sign + TextDisplay at each bay entry (`x-4, y, z+8` local).
- Closing any bay community chest or hub chest donates loot → same community goal.
- Holos refresh on donate / goal / `/mobfarm resholo`.

## Host deploy recipe

1. Stop server or unload plugin.
2. Remove older `MAVOMobFarm-2.2.*` from `plugins/`.
3. Drop `MAVOMobFarm-2.3.0.jar` into `plugins/`.
4. **Delete or edit** `plugins/MAVOMobFarm/config.yml` so new keys apply (or let `ensureDefaults` merge missing keys + mobs on enable).  
   Recommended: replace with jar config, then restore your `center:` coords.
5. Start / reload.
6. In-game (admin):
   ```
   /mobfarm purge 150
   /mobfarm clearhere 120
   /mobfarm setcenter
   /mobfarm build
   /mobfarm reload
   /mobfarm info
   ```
7. Playtest:
   - Enter → BossBar countdown visible.
   - Leave → bar gone, timer continues; re-enter free, stack kept.
   - Hit mobs → combat achievement ticks (no sun death).
   - Toggle `mob-ai: false` in config → `/mobfarm reload` → frozen pad.
   - `/mobfarm buy` prices: 40k → 80k → 160k…
   - Donate into **bay** chest → community progress + holo update.

## Config keys (new)

| Key | Default | Meaning |
|-----|---------|---------|
| `mob-ai` | true | Pathfinding |
| `sun-safe-killpad` | true | Roof + no burn |
| `credit-last-damager` | true | Achievement killer |
| `session-hud` | true | BossBar |
| `session-hud-title` | … | Template |
| `base-spawners` | 2 | Floor stack |
| `normal-spawner-price` | 10000 | “One spawner” list |
| `extra-price-multiplier` | 4 | First extra = 4× |
| `community.stack-start` | 2 | Community base |

## Soft deps (unchanged)
- Achievements: `onKill` → `getKiller()` (now set via last-hit when needed).
- Professions: `isFarmKill` + `farmXpScale` (0.30).
