package mavo.pvault;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.*;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.command.*;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.inventory.*;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * Personal vault: unlock packs of 5 slots.
 * Pack 0 = first-pack-coins (default 25000).
 * Pack n>=1 = lc-base + (n-1)*lc-increment Lucky Coins (250,500,750…).
 * Contents stored server-side — survive death (unlike shulkers in inventory).
 */
public final class PersonalVault extends JavaPlugin implements Listener, TabCompleter {

    private Economy econ;
    private File dataFile;
    private YamlConfiguration data;
    private Object luckyPlugin; // MAVOLuckyCoins soft
    private Method luckyCount, luckyTake, luckyHas;

    /** uuid -> open page (0-based) while GUI open */
    private final Map<UUID, Integer> openPage = new HashMap<>();
    private final Set<UUID> saving = new HashSet<>();

    @Override public void onEnable() {
        saveDefaultConfig();
        dataFile = new File(getDataFolder(), "vaults.yml");
        data = YamlConfiguration.loadConfiguration(dataFile);
        RegisteredServiceProvider<Economy> rsp = getServer().getServicesManager().getRegistration(Economy.class);
        if (rsp != null) econ = rsp.getProvider();
        hookLucky();
        getServer().getPluginManager().registerEvents(this, this);
        if (getCommand("pvault") != null) getCommand("pvault").setTabCompleter(this);
        getLogger().info("MAVOPersonalVault 1.0.0 — packs of "
                + getConfig().getInt("slots-per-pack", 5) + " slots. LC hooked=" + (luckyPlugin != null));
    }

    @Override public void onDisable() {
        // force-save any open? inventories close on disable
        saveData();
    }

    private void hookLucky() {
        try {
            org.bukkit.plugin.Plugin pl = Bukkit.getPluginManager().getPlugin("MAVOLuckyCoins");
            if (pl == null) return;
            luckyPlugin = pl;
            luckyCount = pl.getClass().getMethod("countCoins", Player.class);
            luckyTake = pl.getClass().getMethod("takeCoins", Player.class, int.class);
            luckyHas = pl.getClass().getMethod("hasCoins", Player.class, int.class);
        } catch (Throwable t) {
            getLogger().warning("LuckyCoins hook failed: " + t.getMessage());
            luckyPlugin = null;
        }
    }

    private int countLC(Player p) {
        if (luckyPlugin == null || luckyCount == null) return 0;
        try { return (Integer) luckyCount.invoke(luckyPlugin, p); } catch (Throwable t) { return 0; }
    }
    private boolean hasLC(Player p, int n) {
        if (luckyPlugin == null) return false;
        try { return (Boolean) luckyHas.invoke(luckyPlugin, p, n); } catch (Throwable t) { return countLC(p) >= n; }
    }
    private boolean takeLC(Player p, int n) {
        if (luckyPlugin == null) return false;
        try { return (Boolean) luckyTake.invoke(luckyPlugin, p, n); } catch (Throwable t) { return false; }
    }

    private void saveData() {
        try { data.save(dataFile); } catch (IOException ignored) {}
    }

    private static String color(String s) {
        return ChatColor.translateAlternateColorCodes('&', s == null ? "" : s);
    }

    private int slotsPerPack() { return Math.max(1, getConfig().getInt("slots-per-pack", 5)); }
    private int pageSize() { return Math.max(9, Math.min(45, getConfig().getInt("page-size", 45))); }
    private int packsUnlocked(UUID u) { return Math.max(0, data.getInt(u + ".packs", 0)); }
    private int slotsUnlocked(UUID u) { return packsUnlocked(u) * slotsPerPack(); }

    /** Cost for unlocking the NEXT pack (pack index = current packs, 0-based). */
    private long nextPackCoinCost(int packsOwned) {
        if (packsOwned == 0) return getConfig().getLong("first-pack-coins", 25_000L);
        return 0; // LC packs
    }
    private int nextPackLcCost(int packsOwned) {
        if (packsOwned == 0) return 0;
        int base = getConfig().getInt("lc-base", 250);
        int inc = getConfig().getInt("lc-increment", 250);
        // packsOwned=1 → first LC pack → 250; packsOwned=2 → 500…
        return base + (packsOwned - 1) * inc;
    }

    private String path(UUID u, int globalSlot) {
        return u + ".s." + globalSlot;
    }

    private ItemStack loadSlot(UUID u, int globalSlot) {
        if (!data.contains(path(u, globalSlot))) return null;
        try { return data.getItemStack(path(u, globalSlot)); }
        catch (Throwable t) { return null; }
    }

    private void saveSlot(UUID u, int globalSlot, ItemStack it) {
        if (it == null || it.getType().isAir()) data.set(path(u, globalSlot), null);
        else data.set(path(u, globalSlot), it);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player p)) { sender.sendMessage("Players only."); return true; }
        if (!p.hasPermission("mavopvault.use")) { p.sendMessage(ChatColor.RED + "No permission."); return true; }
        if (args.length >= 1 && args[0].equalsIgnoreCase("admin") && p.hasPermission("mavopvault.admin")) {
            if (args.length >= 3 && args[1].equalsIgnoreCase("setpacks")) {
                try {
                    int n = Integer.parseInt(args[2]);
                    data.set(p.getUniqueId() + ".packs", Math.max(0, n));
                    saveData();
                    p.sendMessage(ChatColor.GREEN + "Packs set to " + n + " (" + slotsUnlocked(p.getUniqueId()) + " slots)");
                } catch (Exception ex) { p.sendMessage("/pvault admin setpacks <n>"); }
                return true;
            }
        }
        int page = 0;
        if (args.length >= 1) {
            try { page = Math.max(0, Integer.parseInt(args[0]) - 1); } catch (Exception ignored) {}
        }
        openVault(p, page);
        return true;
    }

    private void openVault(Player p, int page) {
        UUID u = p.getUniqueId();
        int unlocked = slotsUnlocked(u);
        int psz = pageSize();
        int maxPage = Math.max(0, unlocked == 0 ? 0 : (unlocked - 1) / psz);
        if (page > maxPage) page = maxPage;
        openPage.put(u, page);

        String title;
        if (unlocked == 0) title = color(getConfig().getString("title-locked", "&8Personal Vault &7— &cLOCKED"));
        else title = color(getConfig().getString("title-open", "&8Personal Vault &7p{page} &8| &e{slots} slots")
                .replace("{page}", String.valueOf(page + 1))
                .replace("{slots}", String.valueOf(unlocked)));

        Inventory inv = Bukkit.createInventory(null, 54, title);
        // storage rows 0-44
        int base = page * psz;
        for (int i = 0; i < psz; i++) {
            int global = base + i;
            if (global < unlocked) {
                ItemStack stored = loadSlot(u, global);
                if (stored != null) inv.setItem(i, stored.clone());
            } else {
                inv.setItem(i, lockedPane(global));
            }
        }
        // control bar 45-53
        inv.setItem(45, btn(Material.ARROW, ChatColor.YELLOW + "Previous page", List.of(ChatColor.GRAY + "Page " + (page + 1))));
        inv.setItem(46, btn(Material.PAPER, ChatColor.AQUA + "Info",
                List.of(ChatColor.GRAY + "Unlocked slots: " + ChatColor.WHITE + unlocked,
                        ChatColor.GRAY + "Packs: " + ChatColor.WHITE + packsUnlocked(u),
                        ChatColor.DARK_GRAY + "Death-safe server storage",
                        ChatColor.DARK_GRAY + "Not a shulker — cannot lose on death")));
        inv.setItem(49, unlockButton(u));
        inv.setItem(52, btn(Material.LIME_DYE, ChatColor.GREEN + "Refresh / Save", List.of(ChatColor.GRAY + "Click to save")));
        inv.setItem(53, btn(Material.ARROW, ChatColor.YELLOW + "Next page", List.of(ChatColor.GRAY + "Page " + (page + 1))));

        // filler
        ItemStack glass = btn(Material.GRAY_STAINED_GLASS_PANE, " ", List.of());
        for (int i = 47; i <= 48; i++) inv.setItem(i, glass);
        for (int i = 50; i <= 51; i++) inv.setItem(i, glass);

        p.openInventory(inv);
        p.playSound(p.getLocation(), Sound.BLOCK_CHEST_OPEN, 0.5f, 1.2f);
    }

    private ItemStack lockedPane(int globalSlot) {
        return btn(Material.RED_STAINED_GLASS_PANE, ChatColor.RED + "Locked slot #" + (globalSlot + 1),
                List.of(ChatColor.GRAY + "Unlock more packs below"));
    }

    private ItemStack unlockButton(UUID u) {
        int packs = packsUnlocked(u);
        int max = getConfig().getInt("max-packs", 200);
        if (packs >= max) {
            return btn(Material.BARRIER, ChatColor.RED + "Max packs", List.of());
        }
        if (packs == 0) {
            long cost = nextPackCoinCost(0);
            return btn(Material.GOLD_INGOT, ChatColor.GOLD + "Unlock first 5 slots",
                    List.of(ChatColor.YELLOW + "Cost: " + cost + " coins",
                            ChatColor.GRAY + "Slots 1–5",
                            ChatColor.GREEN + "Click to purchase"));
        }
        int lc = nextPackLcCost(packs);
        int from = packs * slotsPerPack() + 1;
        int to = (packs + 1) * slotsPerPack();
        return btn(Material.SUNFLOWER, ChatColor.YELLOW + "Unlock slots " + from + "–" + to,
                List.of(ChatColor.GOLD + "Cost: " + lc + " Lucky Coins",
                        ChatColor.GRAY + "Have LC in inventory (sunflowers)",
                        ChatColor.GREEN + "Click to purchase"));
    }

    private ItemStack btn(Material mat, String name, List<String> lore) {
        ItemStack it = new ItemStack(mat);
        ItemMeta m = it.getItemMeta();
        m.setDisplayName(name);
        if (lore != null && !lore.isEmpty()) m.setLore(lore);
        it.setItemMeta(m);
        return it;
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;
        String title = e.getView().getTitle();
        if (title == null || !ChatColor.stripColor(title).toLowerCase(Locale.ROOT).contains("personal vault")) return;

        int raw = e.getRawSlot();
        // top inventory only special handling for controls / locked
        if (raw < 0) return;

        UUID u = p.getUniqueId();
        int page = openPage.getOrDefault(u, 0);
        int psz = pageSize();
        int unlocked = slotsUnlocked(u);

        // control bar
        if (raw >= 45 && raw < 54) {
            e.setCancelled(true);
            if (raw == 45) { // prev
                saveOpenInventory(p, e.getInventory());
                openVault(p, Math.max(0, page - 1));
                return;
            }
            if (raw == 53) { // next
                saveOpenInventory(p, e.getInventory());
                int maxPage = Math.max(0, unlocked == 0 ? 0 : (unlocked - 1) / psz);
                openVault(p, Math.min(maxPage, page + 1));
                return;
            }
            if (raw == 49) {
                saveOpenInventory(p, e.getInventory());
                tryUnlock(p);
                return;
            }
            if (raw == 52) {
                saveOpenInventory(p, e.getInventory());
                p.sendMessage(ChatColor.GREEN + "Vault saved.");
                openVault(p, page);
                return;
            }
            return;
        }

        // storage area
        if (raw < psz) {
            int global = page * psz + raw;
            if (global >= unlocked) {
                e.setCancelled(true);
                p.sendMessage(ChatColor.RED + "Slot locked. Buy more packs.");
                return;
            }
            // allow normal take/put
            return;
        }

        // shift-click from player inv into locked etc. — allow if empty unlocked slots
        if (e.getClickedInventory() != null && e.getClickedInventory().equals(e.getView().getBottomInventory())) {
            // ok
            return;
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;
        String title = e.getView().getTitle();
        if (title == null || !ChatColor.stripColor(title).toLowerCase(Locale.ROOT).contains("personal vault")) return;
        int psz = pageSize();
        int unlocked = slotsUnlocked(p.getUniqueId());
        int page = openPage.getOrDefault(p.getUniqueId(), 0);
        for (int raw : e.getRawSlots()) {
            if (raw >= 45 && raw < 54) { e.setCancelled(true); return; }
            if (raw < psz) {
                int global = page * psz + raw;
                if (global >= unlocked) { e.setCancelled(true); return; }
            }
        }
    }

    @EventHandler
    public void onClose(InventoryCloseEvent e) {
        if (!(e.getPlayer() instanceof Player p)) return;
        String title = e.getView().getTitle();
        if (title == null || !ChatColor.stripColor(title).toLowerCase(Locale.ROOT).contains("personal vault")) return;
        saveOpenInventory(p, e.getInventory());
        openPage.remove(p.getUniqueId());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        openPage.remove(e.getPlayer().getUniqueId());
    }

    private void saveOpenInventory(Player p, Inventory inv) {
        if (saving.contains(p.getUniqueId())) return;
        saving.add(p.getUniqueId());
        try {
            UUID u = p.getUniqueId();
            int page = openPage.getOrDefault(u, 0);
            int psz = pageSize();
            int unlocked = slotsUnlocked(u);
            for (int i = 0; i < psz; i++) {
                int global = page * psz + i;
                if (global >= unlocked) continue;
                ItemStack it = inv.getItem(i);
                // don't save control items
                if (it != null && isControlItem(it)) continue;
                saveSlot(u, global, it);
            }
            saveData();
        } finally {
            saving.remove(p.getUniqueId());
        }
    }

    private boolean isControlItem(ItemStack it) {
        if (it == null || !it.hasItemMeta() || !it.getItemMeta().hasDisplayName()) return false;
        String n = ChatColor.stripColor(it.getItemMeta().getDisplayName());
        return n.contains("Previous") || n.contains("Next") || n.contains("Unlock")
                || n.contains("Info") || n.contains("Refresh") || n.contains("Locked slot")
                || n.equals(" ");
    }

    private void tryUnlock(Player p) {
        UUID u = p.getUniqueId();
        int packs = packsUnlocked(u);
        int max = getConfig().getInt("max-packs", 200);
        if (packs >= max) { p.sendMessage(ChatColor.RED + "Max packs reached."); return; }

        if (packs == 0) {
            long cost = nextPackCoinCost(0);
            if (econ == null || !econ.has(p, cost)) {
                p.sendMessage(ChatColor.RED + "Need " + cost + " coins for first 5 slots.");
                return;
            }
            econ.withdrawPlayer(p, cost);
            data.set(u + ".packs", 1);
            saveData();
            p.sendMessage(ChatColor.GREEN + "Unlocked slots 1–5 for " + cost + " coins!");
            p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.8f, 1.2f);
            openVault(p, 0);
            return;
        }

        int lc = nextPackLcCost(packs);
        if (luckyPlugin == null) {
            p.sendMessage(ChatColor.RED + "MAVOLuckyCoins not loaded — cannot buy LC packs.");
            return;
        }
        if (!hasLC(p, lc)) {
            p.sendMessage(ChatColor.RED + "Need " + lc + " Lucky Coins in inventory (have " + countLC(p) + ").");
            return;
        }
        if (!takeLC(p, lc)) {
            p.sendMessage(ChatColor.RED + "Could not take Lucky Coins.");
            return;
        }
        data.set(u + ".packs", packs + 1);
        saveData();
        int from = packs * slotsPerPack() + 1;
        int to = (packs + 1) * slotsPerPack();
        p.sendMessage(ChatColor.GREEN + "Unlocked slots " + from + "–" + to + " for " + lc + " LC!");
        p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.8f, 1.4f);
        openVault(p, openPage.getOrDefault(u, 0));
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) return List.of("1", "2", "3", "admin");
        return List.of();
    }
}
