package mavo.trades;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.entity.Villager;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityTransformEvent;
import org.bukkit.event.entity.VillagerAcquireTradeEvent;
import org.bukkit.event.entity.VillagerCareerChangeEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.MerchantRecipe;
import org.bukkit.inventory.meta.EnchantmentStorageMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

public final class Trades extends JavaPlugin implements Listener {

    private NamespacedKey tagKey;

    @Override
    public void onEnable() {
        tagKey = new NamespacedKey(this, "mastertrader");
        getServer().getPluginManager().registerEvents(this, this);
        getLogger().info("MAVOTrades enabled - the masters await.");
    }

    private boolean isMaster(org.bukkit.entity.Entity e) {
        return e != null && e.getPersistentDataContainer().has(tagKey, PersistentDataType.STRING);
    }

    // ---------------- trade builders ----------------
    private MerchantRecipe trade(ItemStack result, ItemStack... cost) {
        MerchantRecipe r = new MerchantRecipe(result, 0, 999999, false);
        r.setIngredients(Arrays.asList(cost));
        r.setPriceMultiplier(0f);
        return r;
    }

    private ItemStack em(int n) { return new ItemStack(Material.EMERALD, n); }

    private ItemStack book(Enchantment ench, int lvl) {
        ItemStack it = new ItemStack(Material.ENCHANTED_BOOK);
        EnchantmentStorageMeta m = (EnchantmentStorageMeta) it.getItemMeta();
        m.addStoredEnchant(ench, lvl, true);
        it.setItemMeta(m);
        return it;
    }

    private ItemStack gear(Material mat, Object... enchLvls) {
        ItemStack it = new ItemStack(mat);
        for (int i = 0; i + 1 < enchLvls.length; i += 2)
            it.addUnsafeEnchantment((Enchantment) enchLvls[i], (Integer) enchLvls[i + 1]);
        return it;
    }

    private List<MerchantRecipe> tradesFor(String type) {
        List<MerchantRecipe> t = new ArrayList<>();
        switch (type) {
            case "librarian" -> {
                t.add(trade(book(Enchantment.MENDING, 1), em(48), new ItemStack(Material.BOOK)));
                t.add(trade(book(Enchantment.EFFICIENCY, 5), em(40), new ItemStack(Material.BOOK)));
                t.add(trade(book(Enchantment.FORTUNE, 3), em(36), new ItemStack(Material.BOOK)));
                t.add(trade(book(Enchantment.SILK_TOUCH, 1), em(30), new ItemStack(Material.BOOK)));
                t.add(trade(book(Enchantment.UNBREAKING, 3), em(24), new ItemStack(Material.BOOK)));
                t.add(trade(book(Enchantment.LOOTING, 3), em(32), new ItemStack(Material.BOOK)));
                t.add(trade(book(Enchantment.PROTECTION, 4), em(36), new ItemStack(Material.BOOK)));
                t.add(trade(book(Enchantment.SHARPNESS, 5), em(40), new ItemStack(Material.BOOK)));
                t.add(trade(book(Enchantment.FEATHER_FALLING, 4), em(24), new ItemStack(Material.BOOK)));
                t.add(trade(book(Enchantment.INFINITY, 1), em(40), new ItemStack(Material.BOOK)));
                t.add(trade(book(Enchantment.POWER, 5), em(36), new ItemStack(Material.BOOK)));
                t.add(trade(book(Enchantment.DEPTH_STRIDER, 3), em(28), new ItemStack(Material.BOOK)));
                t.add(trade(book(Enchantment.RESPIRATION, 3), em(20), new ItemStack(Material.BOOK)));
                t.add(trade(book(Enchantment.FIRE_ASPECT, 2), em(26), new ItemStack(Material.BOOK)));
            }
            case "smith" -> {
                t.add(trade(new ItemStack(Material.ANVIL), em(10)));
                t.add(trade(new ItemStack(Material.NETHERITE_UPGRADE_SMITHING_TEMPLATE), em(48), new ItemStack(Material.DIAMOND, 2)));
                t.add(trade(gear(Material.DIAMOND_PICKAXE, Enchantment.EFFICIENCY, 4, Enchantment.UNBREAKING, 3), em(36)));
                t.add(trade(gear(Material.DIAMOND_SWORD, Enchantment.SHARPNESS, 4, Enchantment.LOOTING, 2), em(36)));
                t.add(trade(gear(Material.DIAMOND_AXE, Enchantment.EFFICIENCY, 4, Enchantment.UNBREAKING, 3), em(34)));
                t.add(trade(gear(Material.DIAMOND_SHOVEL, Enchantment.EFFICIENCY, 4, Enchantment.UNBREAKING, 3), em(24)));
                t.add(trade(gear(Material.SHIELD, Enchantment.UNBREAKING, 3), em(12)));
                t.add(trade(em(8), new ItemStack(Material.NETHERITE_SCRAP)));
                t.add(trade(new ItemStack(Material.GRINDSTONE), em(4)));
            }
            case "farmer" -> {
                t.add(trade(em(3), new ItemStack(Material.WHEAT, 64)));
                t.add(trade(em(3), new ItemStack(Material.CARROT, 64)));
                t.add(trade(em(3), new ItemStack(Material.POTATO, 64)));
                t.add(trade(em(3), new ItemStack(Material.BEETROOT, 64)));
                t.add(trade(em(4), new ItemStack(Material.PUMPKIN, 48)));
                t.add(trade(em(4), new ItemStack(Material.MELON, 48)));
                t.add(trade(em(4), new ItemStack(Material.SUGAR_CANE, 64)));
                t.add(trade(new ItemStack(Material.GOLDEN_CARROT, 4), em(3)));
                t.add(trade(new ItemStack(Material.CAKE), em(4)));
                t.add(trade(new ItemStack(Material.BONE_MEAL, 16), em(2)));
                t.add(trade(new ItemStack(Material.HONEY_BOTTLE, 2), em(3)));
            }
            case "collector" -> {
                t.add(trade(em(24), new ItemStack(Material.HEART_OF_THE_SEA)));
                t.add(trade(em(32), new ItemStack(Material.WITHER_SKELETON_SKULL)));
                t.add(trade(em(16), new ItemStack(Material.SHULKER_SHELL)));
                t.add(trade(em(64), new ItemStack(Material.NETHER_STAR)));
                t.add(trade(em(12), new ItemStack(Material.ECHO_SHARD)));
                t.add(trade(em(10), new ItemStack(Material.SPONGE, 2)));
                t.add(trade(em(8), new ItemStack(Material.GHAST_TEAR)));
                t.add(trade(new ItemStack(Material.NAME_TAG), em(12)));
                t.add(trade(new ItemStack(Material.SADDLE), em(10)));
                t.add(trade(new ItemStack(Material.EXPERIENCE_BOTTLE, 8), em(6)));
            }
        }
        return t;
    }

    private Villager.Profession professionFor(String type) {
        return switch (type) {
            case "librarian" -> Villager.Profession.LIBRARIAN;
            case "smith" -> Villager.Profession.WEAPONSMITH;
            case "farmer" -> Villager.Profession.FARMER;
            default -> Villager.Profession.CARTOGRAPHER;
        };
    }

    private String displayFor(String type) {
        return switch (type) {
            case "librarian" -> ChatColor.RED + "" + ChatColor.BOLD + "Master Librarian";
            case "smith" -> ChatColor.RED + "" + ChatColor.BOLD + "Master Smith";
            case "farmer" -> ChatColor.RED + "" + ChatColor.BOLD + "Master Farmer";
            default -> ChatColor.BLUE + "" + ChatColor.BOLD + "The Collector";
        };
    }

    // ---------------- command ----------------
    @Override
    public boolean onCommand(CommandSender s, Command c, String l, String[] a) {
        if (!(s instanceof Player p)) { s.sendMessage("Players only."); return true; }
        if (!p.hasPermission("mavotrades.admin")) { p.sendMessage(ChatColor.RED + "No permission."); return true; }
        if (a.length == 0) {
            p.sendMessage(ChatColor.RED + "/mtrade spawn <librarian|smith|farmer|collector>" + ChatColor.GRAY + " | " + ChatColor.RED + "/mtrade remove" + ChatColor.GRAY + " | " + ChatColor.RED + "/mtrade list");
            return true;
        }
        switch (a[0].toLowerCase(Locale.ROOT)) {
            case "spawn" -> {
                if (a.length < 2) { p.sendMessage(ChatColor.RED + "Types: librarian, smith, farmer, collector"); return true; }
                String type = a[1].toLowerCase(Locale.ROOT);
                List<MerchantRecipe> tr = tradesFor(type);
                if (tr.isEmpty()) { p.sendMessage(ChatColor.RED + "Unknown type. Types: librarian, smith, farmer, collector"); return true; }
                Villager v = p.getWorld().spawn(p.getLocation(), Villager.class, vil -> {
                    vil.setProfession(professionFor(type));
                    vil.setVillagerLevel(5);
                    vil.setVillagerExperience(250);
                    vil.setCustomName(displayFor(type));
                    vil.setCustomNameVisible(true);
                    vil.setInvulnerable(true);
                    vil.setPersistent(true);
                    vil.setRemoveWhenFarAway(false);
                    vil.setAI(false);
                    vil.setSilent(false);
                    vil.getPersistentDataContainer().set(tagKey, PersistentDataType.STRING, type);
                });
                v.setRecipes(tr);
                p.sendMessage(ChatColor.GREEN + "Spawned " + displayFor(type) + ChatColor.GREEN + " with " + tr.size() + " trades.");
            }
            case "remove" -> {
                Villager nearest = null; double best = 36;
                for (Villager v : p.getWorld().getNearbyEntitiesByType(Villager.class, p.getLocation(), 6)) {
                    if (!isMaster(v)) continue;
                    double d = v.getLocation().distanceSquared(p.getLocation());
                    if (d < best) { best = d; nearest = v; }
                }
                if (nearest == null) { p.sendMessage(ChatColor.RED + "No master trader within 6 blocks."); return true; }
                String n = nearest.getCustomName();
                nearest.remove();
                p.sendMessage(ChatColor.GREEN + "Removed " + n + ChatColor.GREEN + ".");
            }
            case "list" -> {
                int n = 0;
                for (World w : Bukkit.getWorlds())
                    for (Villager v : w.getEntitiesByClass(Villager.class))
                        if (isMaster(v)) {
                            n++;
                            p.sendMessage(ChatColor.GRAY + "- " + v.getCustomName() + ChatColor.GRAY + " @ " + w.getName() + " "
                                    + v.getLocation().getBlockX() + "," + v.getLocation().getBlockY() + "," + v.getLocation().getBlockZ());
                        }
                if (n == 0) p.sendMessage(ChatColor.GRAY + "No master traders in loaded chunks.");
            }
            default -> p.sendMessage(ChatColor.RED + "/mtrade spawn <type> | remove | list");
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String l, String[] a) {
        if (a.length == 1) return Arrays.asList("spawn", "remove", "list");
        if (a.length == 2 && a[0].equalsIgnoreCase("spawn")) return Arrays.asList("librarian", "smith", "farmer", "collector");
        return List.of();
    }

    // ---------------- protection ----------------
    @EventHandler public void onDamage(EntityDamageEvent e) { if (isMaster(e.getEntity())) e.setCancelled(true); }
    @EventHandler public void onTransform(EntityTransformEvent e) { if (isMaster(e.getEntity())) e.setCancelled(true); }
    @EventHandler public void onCareer(VillagerCareerChangeEvent e) { if (isMaster(e.getEntity())) e.setCancelled(true); }
    @EventHandler public void onAcquire(VillagerAcquireTradeEvent e) { if (isMaster(e.getEntity())) e.setCancelled(true); }
}
