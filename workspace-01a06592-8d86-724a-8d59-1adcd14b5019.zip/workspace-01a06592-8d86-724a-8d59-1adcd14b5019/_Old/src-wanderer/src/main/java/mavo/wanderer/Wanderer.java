package mavo.wanderer;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import org.bukkit.Material;
import org.bukkit.entity.WanderingTrader;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.MerchantRecipe;
import org.bukkit.plugin.java.JavaPlugin;

public final class Wanderer extends JavaPlugin implements Listener {

    private final Random rng = new Random();

    // entry: material, amount, emerald cost (scaled by usefulness/rarity)
    private record Offer(Material mat, int amount, int emeralds) {}

    private final List<Offer> pool = new ArrayList<>();

    @Override
    public void onEnable() {
        buildPool();
        getServer().getPluginManager().registerEvents(this, this);
        getLogger().info("MAVOWanderer enabled - traders now sell " + pool.size() + " useful offers, zero junk.");
    }

    private void add(Material m, int amount, int emeralds) {
        if (m != null) pool.add(new Offer(m, amount, emeralds));
    }

    private void buildPool() {
        // --- utility & redstone (the good stuff) ---
        add(Material.WATER_BUCKET, 1, 3);
        add(Material.LAVA_BUCKET, 1, 6);
        add(Material.MILK_BUCKET, 1, 4);
        add(Material.HOPPER, 1, 10);
        add(Material.HOPPER, 4, 36);
        add(Material.OBSERVER, 2, 8);
        add(Material.PISTON, 4, 10);
        add(Material.STICKY_PISTON, 2, 10);
        add(Material.REDSTONE_BLOCK, 4, 8);
        add(Material.RAIL, 32, 10);
        add(Material.POWERED_RAIL, 8, 12);
        add(Material.CHEST_MINECART, 1, 5);
        add(Material.SHULKER_SHELL, 1, 24);
        add(Material.ENDER_CHEST, 1, 16);
        add(Material.ANVIL, 1, 14);
        add(Material.SCAFFOLDING, 32, 6);
        add(Material.LEAD, 2, 4);
        add(Material.NAME_TAG, 1, 8);
        add(Material.SADDLE, 1, 10);
        add(Material.CAMPFIRE, 2, 4);
        add(Material.LANTERN, 8, 6);
        add(Material.SOUL_LANTERN, 8, 8);
        add(Material.BELL, 1, 12);
        // --- building blocks (bulk, useful) ---
        add(Material.GLASS, 32, 6);
        add(Material.QUARTZ_BLOCK, 16, 12);
        add(Material.PRISMARINE, 16, 10);
        add(Material.DARK_PRISMARINE, 16, 12);
        add(Material.SEA_LANTERN, 8, 12);
        add(Material.GLOWSTONE, 16, 10);
        add(Material.OBSIDIAN, 8, 10);
        add(Material.CRYING_OBSIDIAN, 4, 10);
        add(Material.TERRACOTTA, 32, 8);
        add(Material.SMOOTH_STONE, 32, 6);
        add(Material.DEEPSLATE_BRICKS, 32, 8);
        add(Material.MUD_BRICKS, 32, 6);
        add(Material.SANDSTONE, 32, 5);
        add(Material.RED_SANDSTONE, 32, 6);
        add(Material.BONE_BLOCK, 16, 10);
        add(Material.COPPER_BLOCK, 8, 8);
        add(Material.MOSS_BLOCK, 16, 6);
        add(Material.CALCITE, 16, 6);
        add(Material.TUFF, 32, 4);
        add(Material.AMETHYST_BLOCK, 8, 10);
        // --- nature & farming ---
        add(Material.SPORE_BLOSSOM, 1, 8);
        add(Material.BIG_DRIPLEAF, 4, 4);
        add(Material.GLOW_BERRIES, 8, 4);
        add(Material.SWEET_BERRIES, 16, 3);
        add(Material.HONEY_BOTTLE, 4, 5);
        add(Material.HONEYCOMB, 8, 6);
        add(Material.MYCELIUM, 8, 8);
        add(Material.PODZOL, 16, 6);
        add(Material.MANGROVE_PROPAGULE, 4, 4);
        add(Material.CHERRY_SAPLING, 2, 6);
        add(Material.BAMBOO, 16, 3);
        add(Material.CACTUS, 8, 3);
        add(Material.SUGAR_CANE, 16, 4);
        add(Material.PUMPKIN_SEEDS, 8, 3);
        add(Material.MELON_SEEDS, 8, 3);
        add(Material.KELP, 16, 3);
        add(Material.SEAGRASS, 16, 3);
        add(Material.LILY_PAD, 8, 4);
        // --- brewing & misc useful ---
        add(Material.BLAZE_ROD, 2, 12);
        add(Material.NETHER_WART, 8, 10);
        add(Material.GHAST_TEAR, 1, 12);
        add(Material.MAGMA_CREAM, 4, 8);
        add(Material.SLIME_BALL, 4, 8);
        add(Material.INK_SAC, 8, 4);
        add(Material.GLOW_INK_SAC, 4, 6);
        add(Material.TURTLE_SCUTE, 1, 14);
        add(Material.ARMADILLO_SCUTE, 2, 10);
        add(Material.ECHO_SHARD, 1, 20);
        add(Material.HEART_OF_THE_SEA, 1, 32);
        add(Material.NAUTILUS_SHELL, 1, 12);
        add(Material.SPONGE, 2, 14);
        add(Material.BOOKSHELF, 8, 10);
        add(Material.BOOK, 16, 8);
        add(Material.EXPERIENCE_BOTTLE, 8, 14);
        add(Material.END_ROD, 8, 8);
        add(Material.CHORUS_FRUIT, 8, 8);
        add(Material.SHROOMLIGHT, 8, 8);
        add(Material.OCHRE_FROGLIGHT, 8, 10);
        add(Material.VERDANT_FROGLIGHT, 8, 10);
        add(Material.PEARLESCENT_FROGLIGHT, 8, 10);
    }

    @EventHandler(ignoreCancelled = true)
    public void onSpawn(CreatureSpawnEvent e) {
        if (!(e.getEntity() instanceof WanderingTrader wt)) return;
        List<Offer> picks = new ArrayList<>(pool);
        java.util.Collections.shuffle(picks, rng);
        List<MerchantRecipe> recipes = new ArrayList<>();
        int offers = 7 + rng.nextInt(3); // 7-9 offers per trader
        for (int i = 0; i < Math.min(offers, picks.size()); i++) {
            Offer o = picks.get(i);
            MerchantRecipe r = new MerchantRecipe(new ItemStack(o.mat(), o.amount()), 0, 3 + rng.nextInt(4), false);
            r.addIngredient(new ItemStack(Material.EMERALD, Math.min(64, o.emeralds())));
            recipes.add(r);
        }
        wt.setRecipes(recipes);
    }
}
