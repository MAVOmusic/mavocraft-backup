package mavo.events;

import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Monster;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.player.PlayerFishEvent;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;

public final class Events extends JavaPlugin implements Listener {

    private Economy econ;
    private final Random rng = new Random();
    private String active = null;
    private int taskId = -1, rainTaskId = -1;
    private long endsAt = 0;
    private double savedLuckyChance = -1;
    private NamespacedKey placedKey; // MAVOLuckyCoins' player-placed guard

    private static final String[] EVENTS = {"luckyhour", "coinrain", "mobhunt", "fishingfrenzy", "minersrush"};

    @Override
    public void onEnable() {
        getConfig().addDefault("auto-events", true);
        getConfig().addDefault("min-minutes-between", 45);
        getConfig().addDefault("max-minutes-between", 90);
        getConfig().addDefault("event-minutes", 15);
        getConfig().options().copyDefaults(true);
        saveConfig();
        RegisteredServiceProvider<Economy> rsp = getServer().getServicesManager().getRegistration(Economy.class);
        if (rsp != null) econ = rsp.getProvider();
        try { placedKey = new NamespacedKey("mavoluckycoins", "lcplaced"); } catch (Exception ignored) {}
        getServer().getPluginManager().registerEvents(this, this);
        scheduleNext();
        getLogger().info("MAVOEvents enabled - chaos scheduled.");
    }

    @Override
    public void onDisable() { stopEvent(false); }

    // ---------------- scheduling ----------------
    private void scheduleNext() {
        if (!getConfig().getBoolean("auto-events", true)) return;
        int min = getConfig().getInt("min-minutes-between", 45);
        int max = Math.max(min + 1, getConfig().getInt("max-minutes-between", 90));
        long delayTicks = (min + rng.nextInt(max - min)) * 60L * 20L;
        Bukkit.getScheduler().runTaskLater(this, () -> {
            if (active == null && Bukkit.getOnlinePlayers().size() >= 1)
                startEvent(EVENTS[rng.nextInt(EVENTS.length)]);
            scheduleNext();
        }, delayTicks);
    }

    private void pay(Player p, double amt) {
        if (p.getGameMode() != org.bukkit.GameMode.SURVIVAL) return; // creative never earns
        if (econ != null) econ.depositPlayer(p, amt);
    }

    private boolean playerPlaced(org.bukkit.block.Block b) {
        if (placedKey == null) return false;
        long k = (((long) (b.getY() + 512)) << 8) | ((b.getX() & 15) << 4) | (b.getZ() & 15);
        long[] arr = b.getChunk().getPersistentDataContainer().get(placedKey, PersistentDataType.LONG_ARRAY);
        if (arr != null) for (long v : arr) if (v == k) return true;
        return false;
    }

    private String pretty(String ev) {
        return switch (ev) {
            case "luckyhour" -> ChatColor.GOLD + "" + ChatColor.BOLD + "\u26C0 LUCKY HOUR";
            case "coinrain" -> ChatColor.YELLOW + "" + ChatColor.BOLD + "\u26C3 COIN RAIN";
            case "mobhunt" -> ChatColor.RED + "" + ChatColor.BOLD + "\u2694 MOB HUNT";
            case "fishingfrenzy" -> ChatColor.BLUE + "" + ChatColor.BOLD + "\uD83C\uDFA3 FISHING FRENZY";
            case "minersrush" -> ChatColor.AQUA + "" + ChatColor.BOLD + "\u26CF MINER'S RUSH";
            default -> ev;
        };
    }

    private String describe(String ev) {
        return switch (ev) {
            case "luckyhour" -> "Lucky Coin drop chance is 5x for the next %d minutes!";
            case "coinrain" -> "Free coins rain on random online players for %d minutes!";
            case "mobhunt" -> "Hostile mob kills pay bonus coins for %d minutes!";
            case "fishingfrenzy" -> "Every catch pays bonus coins for %d minutes!";
            case "minersrush" -> "Mining ores pays bonus coins for %d minutes!";
            default -> "Event running for %d minutes!";
        };
    }

    private void startEvent(String ev) {
        stopEvent(false);
        active = ev;
        int mins = getConfig().getInt("event-minutes", 15);
        endsAt = System.currentTimeMillis() + mins * 60000L;
        Bukkit.broadcastMessage("");
        Bukkit.broadcastMessage(pretty(ev) + ChatColor.RESET + " " + ChatColor.GRAY + String.format(describe(ev), mins));
        Bukkit.broadcastMessage("");
        for (Player p : Bukkit.getOnlinePlayers())
            p.playSound(p.getLocation(), Sound.ENTITY_ENDER_DRAGON_GROWL, 0.4f, 1.6f);

        if (ev.equals("luckyhour")) {
            Plugin lucky = Bukkit.getPluginManager().getPlugin("MAVOLuckyCoins");
            if (lucky != null) {
                savedLuckyChance = lucky.getConfig().getDouble("drop-chance", 0.01);
                lucky.getConfig().set("drop-chance", Math.min(0.25, savedLuckyChance * 5));
            }
        }
        if (ev.equals("coinrain")) {
            rainTaskId = Bukkit.getScheduler().runTaskTimer(this, () -> {
                var online = Bukkit.getOnlinePlayers().stream()
                        .filter(pl -> pl.getGameMode() == org.bukkit.GameMode.SURVIVAL).toList();
                if (online.isEmpty()) return;
                Player p = online.get(rng.nextInt(online.size()));
                int amt = 5 + rng.nextInt(16);
                pay(p, amt);
                p.sendMessage(ChatColor.YELLOW + "\u26C3 +" + amt + ChatColor.GRAY + " coin rain!");
                p.playSound(p.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 0.6f, 2f);
            }, 100L, 600L).getTaskId(); // every 30s
        }
        taskId = Bukkit.getScheduler().runTaskLater(this, () -> stopEvent(true), mins * 60L * 20L).getTaskId();
    }

    private void stopEvent(boolean announce) {
        if (active == null) return;
        String was = active;
        active = null;
        if (taskId != -1) { Bukkit.getScheduler().cancelTask(taskId); taskId = -1; }
        if (rainTaskId != -1) { Bukkit.getScheduler().cancelTask(rainTaskId); rainTaskId = -1; }
        if (was.equals("luckyhour") && savedLuckyChance >= 0) {
            Plugin lucky = Bukkit.getPluginManager().getPlugin("MAVOLuckyCoins");
            if (lucky != null) lucky.getConfig().set("drop-chance", savedLuckyChance);
            savedLuckyChance = -1;
        }
        if (announce) Bukkit.broadcastMessage(pretty(was) + ChatColor.RESET + " " + ChatColor.GRAY + "has ended. Back to the grind!");
    }

    // ---------------- event effects ----------------
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onKill(EntityDeathEvent e) {
        if (!"mobhunt".equals(active)) return;
        Player k = e.getEntity().getKiller();
        if (k == null || !(e.getEntity() instanceof Monster)) return;
        if (k.getGameMode() != org.bukkit.GameMode.SURVIVAL) return;
        int amt = 2 + rng.nextInt(3);
        pay(k, amt);
        k.sendMessage(ChatColor.RED + "\u2694 +" + amt + ChatColor.GRAY + " mob hunt bonus");
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onFish(PlayerFishEvent e) {
        if (!"fishingfrenzy".equals(active) || e.getState() != PlayerFishEvent.State.CAUGHT_FISH) return;
        if (e.getPlayer().getGameMode() != org.bukkit.GameMode.SURVIVAL) return;
        int amt = 3 + rng.nextInt(4);
        pay(e.getPlayer(), amt);
        e.getPlayer().sendMessage(ChatColor.BLUE + "\uD83C\uDFA3 +" + amt + ChatColor.GRAY + " frenzy bonus");
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onMine(BlockBreakEvent e) {
        if (!"minersrush".equals(active)) return;
        if (e.getPlayer().getGameMode() != org.bukkit.GameMode.SURVIVAL) return;
        Material m = e.getBlock().getType();
        if (!m.name().endsWith("_ORE") && m != Material.ANCIENT_DEBRIS) return;
        if (playerPlaced(e.getBlock())) return;
        int amt = 1 + rng.nextInt(3);
        pay(e.getPlayer(), amt);
    }

    // ---------------- command ----------------
    @Override
    public boolean onCommand(CommandSender s, Command c, String l, String[] a) {
        if (a.length == 0) {
            if (active == null) s.sendMessage(ChatColor.GRAY + "No event running right now. They start randomly - stay online!");
            else {
                long left = Math.max(0, (endsAt - System.currentTimeMillis()) / 60000L);
                s.sendMessage(pretty(active) + ChatColor.RESET + ChatColor.GRAY + " is LIVE - about " + left + " min left.");
            }
            return true;
        }
        switch (a[0].toLowerCase(Locale.ROOT)) {
            case "list" -> {
                s.sendMessage(ChatColor.RED + "" + ChatColor.BOLD + "Server Events:");
                for (String ev : EVENTS) s.sendMessage(ChatColor.GRAY + "- " + pretty(ev));
            }
            case "start" -> {
                if (!s.hasPermission("mavoevents.admin")) { s.sendMessage(ChatColor.RED + "No permission."); return true; }
                if (a.length < 2 || !Arrays.asList(EVENTS).contains(a[1].toLowerCase(Locale.ROOT))) {
                    s.sendMessage(ChatColor.RED + "Events: " + String.join(", ", EVENTS)); return true;
                }
                startEvent(a[1].toLowerCase(Locale.ROOT));
            }
            case "stop" -> {
                if (!s.hasPermission("mavoevents.admin")) { s.sendMessage(ChatColor.RED + "No permission."); return true; }
                if (active == null) s.sendMessage(ChatColor.GRAY + "Nothing to stop.");
                else stopEvent(true);
            }
            default -> s.sendMessage(ChatColor.RED + "/event [start <name>|stop|list]");
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String l, String[] a) {
        if (a.length == 1) return s.hasPermission("mavoevents.admin") ? Arrays.asList("list", "start", "stop") : List.of("list");
        if (a.length == 2 && a[0].equalsIgnoreCase("start")) return Arrays.asList(EVENTS);
        return List.of();
    }
}
