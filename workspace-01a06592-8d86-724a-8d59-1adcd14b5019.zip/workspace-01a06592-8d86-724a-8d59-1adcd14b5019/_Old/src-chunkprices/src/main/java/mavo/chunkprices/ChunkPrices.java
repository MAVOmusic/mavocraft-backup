/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.cjburkey.claimchunk.ClaimChunk
 *  com.cjburkey.claimchunk.chunk.ChunkHandler
 *  net.milkbowl.vault.economy.Economy
 *  net.milkbowl.vault.economy.EconomyResponse
 *  org.bukkit.Bukkit
 *  org.bukkit.ChatColor
 *  org.bukkit.OfflinePlayer
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandExecutor
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.Listener
 *  org.bukkit.event.player.PlayerCommandPreprocessEvent
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.plugin.RegisteredServiceProvider
 *  org.bukkit.plugin.java.JavaPlugin
 */
package mavo.chunkprices;

import com.cjburkey.claimchunk.ClaimChunk;
import com.cjburkey.claimchunk.chunk.ChunkHandler;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import net.milkbowl.vault.economy.Economy;
import net.milkbowl.vault.economy.EconomyResponse;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;

public final class ChunkPrices
extends JavaPlugin
implements Listener {
    private Economy econ;
    private final List<int[]> tiers = new ArrayList<int[]>();
    private boolean blockAutoClaim;
    private boolean blockBeyondLastTier;
    private String msgCannotAfford;
    private String msgClaimed;
    private String msgClaimedFree;
    private String msgRefunded;
    private String msgAutoBlocked;
    private String msgMaxReached;
    private String msgNextPrice;

    public void onEnable() {
        this.saveDefaultConfig();
        this.loadCfg();
        RegisteredServiceProvider rsp = this.getServer().getServicesManager().getRegistration(Economy.class);
        if (rsp == null) {
            this.getLogger().severe("No Vault economy found! Disabling.");
            this.getServer().getPluginManager().disablePlugin((Plugin)this);
            return;
        }
        this.econ = (Economy)rsp.getProvider();
        this.getServer().getPluginManager().registerEvents((Listener)this, (Plugin)this);
        if (this.getCommand("chunkprice") != null) {
            this.getCommand("chunkprice").setExecutor((CommandExecutor)this);
        }
        this.getLogger().info("MAVOChunkPrices enabled. Tier table: " + this.tierSummary() + " (max " + this.maxChunks() + " chunks)");
    }

    private void loadCfg() {
        this.reloadConfig();
        this.tiers.clear();
        List raw = this.getConfig().getMapList("tiers");
        for (Map m : raw) {
            int count = ((Number)m.get("amount")).intValue();
            int price = ((Number)m.get("price")).intValue();
            if (count <= 0 || price < 0) continue;
            this.tiers.add(new int[]{count, price});
        }
        if (this.tiers.isEmpty()) {
            this.tiers.add(new int[]{1, 0});
        }
        this.blockAutoClaim = this.getConfig().getBoolean("block-auto-claim", true);
        this.blockBeyondLastTier = this.getConfig().getBoolean("block-beyond-last-tier", true);
        this.msgCannotAfford = ChunkPrices.color(this.getConfig().getString("messages.cannot-afford", "&cChunk #%num% costs &e%price%&c but you only have &e%balance%&c."));
        this.msgClaimed = ChunkPrices.color(this.getConfig().getString("messages.claimed", "&aClaimed chunk #%num% for &e%price%&a."));
        this.msgClaimedFree = ChunkPrices.color(this.getConfig().getString("messages.claimed-free", "&aClaimed chunk #%num% - &e&lFREE&a!"));
        this.msgRefunded = ChunkPrices.color(this.getConfig().getString("messages.refunded", "&7Claim didn't go through - &e%price%&7 refunded."));
        this.msgAutoBlocked = ChunkPrices.color(this.getConfig().getString("messages.auto-blocked", "&cAuto-claim is disabled here - each chunk has its own price. Use &e/chunk claim&c."));
        this.msgMaxReached = ChunkPrices.color(this.getConfig().getString("messages.max-reached", "&cYou already own the maximum of &e%max%&c chunks!"));
        this.msgNextPrice = ChunkPrices.color(this.getConfig().getString("messages.next-price", "&7Next chunk (#%num%) will cost &e%price%&7."));
    }

    private static String color(String s) {
        return ChatColor.translateAlternateColorCodes((char)'&', (String)(s == null ? "" : s));
    }

    private int maxChunks() {
        int t = 0;
        for (int[] x : this.tiers) {
            t += x[0];
        }
        return t;
    }

    private int priceFor(int n) {
        int upto = 0;
        for (int[] t : this.tiers) {
            if (n > (upto += t[0])) continue;
            return t[1];
        }
        return this.blockBeyondLastTier ? -1 : this.tiers.get(this.tiers.size() - 1)[1];
    }

    private String tierSummary() {
        StringBuilder sb = new StringBuilder();
        for (int[] t : this.tiers) {
            if (sb.length() > 0) {
                sb.append(", ");
            }
            sb.append(t[0]).append("x ").append(t[1]);
        }
        return sb.toString();
    }

    @EventHandler(priority=EventPriority.HIGH, ignoreCancelled=true)
    public void onCommand(PlayerCommandPreprocessEvent e) {
        String msg = e.getMessage();
        if (msg.length() < 2) {
            return;
        }
        String[] parts = msg.substring(1).trim().split("\\s+");
        if (parts.length < 2) {
            return;
        }
        String cmd = parts[0].toLowerCase(Locale.ROOT);
        int ci = cmd.indexOf(58);
        if (ci >= 0) {
            cmd = cmd.substring(ci + 1);
        }
        if (!cmd.equals("chunk") && !cmd.equals("claimchunk")) {
            return;
        }
        String sub = parts[1].toLowerCase(Locale.ROOT);
        Player p = e.getPlayer();
        if (sub.equals("auto") && this.blockAutoClaim && !p.hasPermission("mavochunkprices.bypass")) {
            e.setCancelled(true);
            p.sendMessage(this.msgAutoBlocked);
            return;
        }
        if (!sub.equals("claim")) {
            return;
        }
        if (p.hasPermission("mavochunkprices.bypass")) {
            return;
        }
        ChunkHandler ch = ClaimChunk.getInstance().getChunkHandler();
        int before = ch.getClaimed(p.getUniqueId());
        int num = before + 1;
        int price = this.priceFor(num);
        if (price < 0) {
            e.setCancelled(true);
            p.sendMessage(this.msgMaxReached.replace("%max%", String.valueOf(this.maxChunks())));
            return;
        }
        if (price > 0) {
            double bal = this.econ.getBalance((OfflinePlayer)p);
            if (bal < (double)price) {
                e.setCancelled(true);
                p.sendMessage(this.msgCannotAfford.replace("%num%", String.valueOf(num)).replace("%price%", this.econ.format((double)price)).replace("%balance%", this.econ.format(bal)));
                return;
            }
            EconomyResponse r = this.econ.withdrawPlayer((OfflinePlayer)p, (double)price);
            if (!r.transactionSuccess()) {
                e.setCancelled(true);
                p.sendMessage(String.valueOf(ChatColor.RED) + "Payment failed: " + r.errorMessage);
                return;
            }
        }
        Bukkit.getScheduler().runTask((Plugin)this, () -> {
            int now = ch.getClaimed(p.getUniqueId());
            if (now > before) {
                if (price > 0) {
                    p.sendMessage(this.msgClaimed.replace("%num%", String.valueOf(now)).replace("%price%", this.econ.format((double)price)));
                } else {
                    p.sendMessage(this.msgClaimedFree.replace("%num%", String.valueOf(now)));
                }
                int np = this.priceFor(now + 1);
                if (np >= 0) {
                    p.sendMessage(this.msgNextPrice.replace("%num%", String.valueOf(now + 1)).replace("%price%", np == 0 ? "FREE" : this.econ.format((double)np)));
                }
            } else if (price > 0) {
                this.econ.depositPlayer((OfflinePlayer)p, (double)price);
                p.sendMessage(this.msgRefunded.replace("%price%", this.econ.format((double)price)));
            }
        });
    }

    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length > 0 && args[0].equalsIgnoreCase("reload")) {
            if (!sender.hasPermission("mavochunkprices.admin")) {
                sender.sendMessage(String.valueOf(ChatColor.RED) + "No permission.");
                return true;
            }
            this.loadCfg();
            sender.sendMessage(String.valueOf(ChatColor.GREEN) + "MAVOChunkPrices reloaded. Tiers: " + this.tierSummary());
            return true;
        }
        if (!(sender instanceof Player)) {
            sender.sendMessage("Tiers: " + this.tierSummary() + " (max " + this.maxChunks() + ")");
            return true;
        }
        Player p = (Player)sender;
        int owned = ClaimChunk.getInstance().getChunkHandler().getClaimed(p.getUniqueId());
        int max = this.maxChunks();
        p.sendMessage(String.valueOf(ChatColor.DARK_RED) + String.valueOf(ChatColor.BOLD) + "MAVOcraft " + String.valueOf(ChatColor.AQUA) + "Chunk Prices");
        p.sendMessage(String.valueOf(ChatColor.GRAY) + "You own " + String.valueOf(ChatColor.YELLOW) + owned + String.valueOf(ChatColor.GRAY) + " / " + String.valueOf(ChatColor.YELLOW) + max + String.valueOf(ChatColor.GRAY) + " chunks.");
        int np = this.priceFor(owned + 1);
        if (np < 0) {
            p.sendMessage(String.valueOf(ChatColor.RED) + "You've reached the maximum!");
        } else {
            p.sendMessage(String.valueOf(ChatColor.GRAY) + "Next chunk (#" + (owned + 1) + "): " + String.valueOf(ChatColor.YELLOW) + (np == 0 ? "FREE" : this.econ.format((double)np)));
        }
        int upto = 0;
        Iterator<int[]> iterator = this.tiers.iterator();
        while (iterator.hasNext()) {
            String priceStr;
            int start = upto + 1;
            int[] t = iterator.next();
            String range = start == (upto += t[0]) ? "#" + start : "#" + start + "-" + upto;
            String string = priceStr = t[1] == 0 ? "FREE" : this.econ.format((double)t[1]);
            ChatColor c = owned >= upto ? ChatColor.DARK_GRAY : (owned >= start - 1 ? ChatColor.GREEN : ChatColor.GRAY);
            p.sendMessage(String.valueOf(c) + "  " + range + ": " + priceStr + (owned >= upto ? " (done)" : ""));
        }
        return true;
    }
}
