package mavo.tavern;

import java.io.File;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.data.type.Bed;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Display;
import org.bukkit.entity.Player;
import org.bukkit.entity.TextDisplay;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.entity.Villager;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.attribute.Attribute;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

/**
 * Spawn tavern: right-click the marked bed, pay coins, skip the night.
 * Paid rest per player until noon; 4 beds; multiplayer vanilla sleep; lock resets at noon (time 6000).
 */
public final class Tavern extends JavaPlugin implements Listener, TabCompleter {

    private Economy econ;
    private NamespacedKey holoKey;
    private File dataFile;
    private YamlConfiguration data;
    private boolean dirty;

    private boolean bedEnabled;
    private String bedWorld;
    private int bedX, bedY, bedZ;
    private final java.util.List<int[]> extraBeds = new java.util.ArrayList<>();
    private final Map<UUID, Map<String, Long>> barDay = new HashMap<>();
    private NamespacedKey boundKey;
    private double price;
    private long wakeTime;
    private boolean nightOnly;
    private String currency;
    private String prefix;

    // uuid -> world fullTime when their lock expires (next noon after a rest)
    private final Map<UUID, Long> unlockAtFull = new HashMap<>();
    // players currently in the short sleep FX
    private final Set<UUID> sleeping = new HashSet<>();
    private BukkitTask noonTask;
    private UUID holoUuid;
    private final java.util.List<UUID> bedHoloUuids = new java.util.ArrayList<>();

    @Override
    public void onEnable() {
        holoKey = new NamespacedKey(this, "tavernholo");
        boundKey = new NamespacedKey(this, "tavernbound");
        saveDefaultConfig();
        reloadLocal();
        dataFile = new File(getDataFolder(), "data.yml");
        data = YamlConfiguration.loadConfiguration(dataFile);
        loadUsage();
        barDay.clear();
        if (data.getConfigurationSection("bar") != null) {
            for (String us : data.getConfigurationSection("bar").getKeys(false)) {
                try {
                    UUID u = UUID.fromString(us);
                    Map<String, Long> mm = new HashMap<>();
                    if (data.getConfigurationSection("bar." + us) != null) {
                        for (String k : data.getConfigurationSection("bar." + us).getKeys(false)) {
                            mm.put(k, data.getLong("bar." + us + "." + k));
                        }
                    }
                    barDay.put(u, mm);
                } catch (Exception ignored) {}
            }
        }

        RegisteredServiceProvider<Economy> rsp =
                getServer().getServicesManager().getRegistration(Economy.class);
        if (rsp != null) econ = rsp.getProvider();
        else getLogger().warning("Vault economy missing - tavern sleeps will be free until Vault hooks.");

        getServer().getPluginManager().registerEvents(this, this);
        if (getCommand("tavern") != null) getCommand("tavern").setTabCompleter(this);

        // autosave + noon unlock broadcast check every 5s
        Bukkit.getScheduler().runTaskTimer(this, () -> {
            if (dirty) { try { data.save(dataFile); } catch (Exception ignored) {} dirty = false; }
        }, 200L, 200L);

        noonTask = Bukkit.getScheduler().runTaskTimer(this, this::tickNoon, 40L, 40L);

        Bukkit.getScheduler().runTaskLater(this, () -> {
            if (bedEnabled && getConfig().getBoolean("holo.enabled", true)) spawnHolo();
        }, 40L);

        getLogger().info("MAVOTavern 1.4 enabled - price " + (long) price + " " + strip(currency)
                + ", lock-until-next-noon, bed "
                + (bedEnabled ? (bedWorld + " " + bedX + "," + bedY + "," + bedZ) : "NOT SET (/tavern setbed)"));
    }

    @Override
    public void onDisable() {
        if (noonTask != null) noonTask.cancel();
        try { data.save(dataFile); } catch (Exception ignored) {}
        removeHolo();
    }

    private void reloadLocal() {
        reloadConfig();
        price = getConfig().getDouble("price", 100);
        wakeTime = getConfig().getLong("wake-time", 1000);
        nightOnly = getConfig().getBoolean("night-only", true);
        currency = color(getConfig().getString("currency-symbol", "\u26C3"));
        prefix = color(getConfig().getString("messages.prefix", "&c&lTAVERN &r&8» &r"));
        bedEnabled = getConfig().getBoolean("bed.enabled", false);
        bedWorld = getConfig().getString("bed.world", "world");
        bedX = getConfig().getInt("bed.x", 0);
        bedY = getConfig().getInt("bed.y", 64);
        bedZ = getConfig().getInt("bed.z", 0);
        // Absolute bed heads (preferred) + legacy extra-beds offsets
        extraBeds.clear();
        if (getConfig().isList("beds")) {
            // beds: list of {x,y,z} absolute head positions — store as offsets from primary for matches
            // Actually store absolute in a parallel list via negative sentinel? Simpler: put all as absolute
            // by using bedX=0 and storing absolute in extras with a flag.
            // Clean approach: keep primary as beds[0], extras as absolute deltas from primary.
            java.util.List<java.util.Map<?,?>> list = getConfig().getMapList("beds");
            if (!list.isEmpty()) {
                java.util.Map<?,?> first = list.get(0);
                bedX = Integer.parseInt(String.valueOf(first.get("x")));
                bedY = Integer.parseInt(String.valueOf(first.get("y")));
                bedZ = Integer.parseInt(String.valueOf(first.get("z")));
                for (int i = 1; i < list.size(); i++) {
                    java.util.Map<?,?> m = list.get(i);
                    int ax = Integer.parseInt(String.valueOf(m.get("x")));
                    int ay = Integer.parseInt(String.valueOf(m.get("y")));
                    int az = Integer.parseInt(String.valueOf(m.get("z")));
                    extraBeds.add(new int[]{ax - bedX, ay - bedY, az - bedZ});
                }
            }
        } else if (getConfig().isList("extra-beds")) {
            for (java.util.Map<?,?> m : getConfig().getMapList("extra-beds")) {
                try {
                    extraBeds.add(new int[]{
                        Integer.parseInt(String.valueOf(m.get("x"))),
                        Integer.parseInt(String.valueOf(m.get("y"))),
                        Integer.parseInt(String.valueOf(m.get("z")))
                    });
                } catch (Exception ignored) {}
            }
        }
        getLogger().info("Tavern beds loaded: primary " + bedX + "," + bedY + "," + bedZ
                + " + " + extraBeds.size() + " extra(s)");
    }

    private void loadUsage() {
        unlockAtFull.clear();
        // new format
        if (data.isConfigurationSection("unlock-at")) {
            for (String k : data.getConfigurationSection("unlock-at").getKeys(false)) {
                try {
                    unlockAtFull.put(UUID.fromString(k), data.getLong("unlock-at." + k));
                } catch (Exception ignored) {}
            }
        }
        // migrate legacy day-index locks (used.<uuid> = small day number)
        if (data.isConfigurationSection("used")) {
            for (String k : data.getConfigurationSection("used").getKeys(false)) {
                try {
                    UUID id = UUID.fromString(k);
                    if (unlockAtFull.containsKey(id)) continue;
                    long v = data.getLong("used." + k);
                    // old: day index. Convert to noon of the following day (best-effort).
                    // If value looks like fullTime already (> 100000), keep as unlock time.
                    long unlock = v > 100_000L ? v : (v + 1L) * 24000L + 6000L;
                    unlockAtFull.put(id, unlock);
                    data.set("unlock-at." + k, unlock);
                } catch (Exception ignored) {}
            }
            data.set("used", null);
            dirty = true;
        }
    }

    /** After a rest: lock until the next noon on the world clock. */
    private void saveLockUntilNextNoon(UUID id, World w) {
        long unlock = nextNoonFullTime(w);
        unlockAtFull.put(id, unlock);
        data.set("unlock-at." + id, unlock);
        dirty = true;
    }

    private void clearLock(UUID id) {
        unlockAtFull.remove(id);
        data.set("unlock-at." + id, null);
        data.set("used." + id, null);
        dirty = true;
    }

    /* ================= time helpers ================= */

    /** Absolute fullTime of the next noon (time-of-day 6000). If already past noon, tomorrow noon. */
    private long nextNoonFullTime(World w) {
        long full = w.getFullTime();
        long tod = w.getTime(); // 0..23999
        long dayBase = full - tod;
        if (tod < 6000L) return dayBase + 6000L;          // later today
        return dayBase + 24000L + 6000L;                  // tomorrow noon
    }

    /** true if player may rent the tavern bed right now. */
    private boolean isUnlocked(Player pl, World w) {
        Long until = unlockAtFull.get(pl.getUniqueId());
        if (until == null) return true;
        if (w.getFullTime() >= until) {
            // expired — drop stale entry
            clearLock(pl.getUniqueId());
            return true;
        }
        return false;
    }

    private long secondsUntilUnlock(Player pl, World w) {
        Long until = unlockAtFull.get(pl.getUniqueId());
        if (until == null) return 0;
        long left = until - w.getFullTime();
        return Math.max(0L, left / 20L);
    }

    private boolean isNightish(World w) {
        if (w.hasStorm() && w.isThundering()) return true;
        long t = w.getTime();
        // vanilla beds work ~12542..23460; keep a similar window
        return t >= 12542L && t <= 23460L;
    }

    private void tickNoon() {
        // no-op heavy work; lock state is computed live. Holo text refresh occasionally.
        if (!bedEnabled) return;
        World w = Bukkit.getWorld(bedWorld);
        if (w == null) return;
        long t = w.getTime();
        // refresh holo near noon / dusk so status stays accurate
        if (t >= 5980 && t <= 6060 || t >= 12500 && t <= 12600) {
            if (getConfig().getBoolean("holo.enabled", true)) spawnHolo();
        }
    }

    /* ================= bed match ================= */

    private boolean isTavernBed(Block b) {
        if (!bedEnabled || b == null) return false;
        if (!b.getWorld().getName().equals(bedWorld)) return false;
        Material mat = b.getType();
        if (!mat.name().endsWith("_BED")) return false;
        int x = b.getX(), y = b.getY(), z = b.getZ();
        if (matchesBedPair(b, bedX, bedY, bedZ)) return true;
        for (int[] off : extraBeds) {
            if (matchesBedPair(b, bedX + off[0], bedY + off[1], bedZ + off[2])) return true;
        }
        return false;
    }

    private boolean matchesBedPair(Block b, int bx, int by, int bz) {
        int x = b.getX(), y = b.getY(), z = b.getZ();
        if (x == bx && y == by && z == bz) return true;
        if (b.getBlockData() instanceof Bed bed) {
            if (bed.getPart() == Bed.Part.FOOT) {
                Block head = b.getRelative(bed.getFacing());
                return head.getX() == bx && head.getY() == by && head.getZ() == bz;
            } else {
                Block foot = b.getRelative(bed.getFacing().getOppositeFace());
                return (x == bx && y == by && z == bz)
                        || (foot.getX() == bx && foot.getY() == by && foot.getZ() == bz);
            }
        }
        return false;
    }

    /* ================= interact ================= */

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = false)
    public void onBedClick(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        if (e.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        Block b = e.getClickedBlock();
        if (!isTavernBed(b)) return;

        Player pl = e.getPlayer();
        // cancel vanilla sleep / MAVOHomes bind attempts on THIS bed
        e.setCancelled(true);

        if (!pl.hasPermission("mavotavern.use") && !pl.hasPermission("mavotavern.admin")) {
            msg(pl, ChatColor.RED + "You can't use the tavern bed.");
            return;
        }
        if (pl.getGameMode() == GameMode.SPECTATOR) return;
        if (sleeping.contains(pl.getUniqueId())) return;

        World w = pl.getWorld();
        if (!w.getName().equals(bedWorld)) {
            msg(pl, ChatColor.RED + "The tavern bed only works in the overworld plaza.");
            return;
        }

        if (!isUnlocked(pl, w)) {
            long sec = secondsUntilUnlock(pl, w);
            long mins = sec / 60L;
            String eta = mins >= 1
                    ? (mins + " min")
                    : (sec + "s");
            msg(pl, ChatColor.RED + "You've already rested. "
                    + ChatColor.GRAY + "Tavern bed unlocks at "
                    + ChatColor.YELLOW + "noon"
                    + ChatColor.GRAY + " (~" + eta + " of world-time left).");
            pl.playSound(pl.getLocation(), Sound.BLOCK_WOODEN_DOOR_CLOSE, 0.7f, 0.8f);
            return;
        }

        if (nightOnly && !isNightish(w)) {
            msg(pl, ChatColor.GRAY + "The tavern bed is for "
                    + ChatColor.BLUE + "night" + ChatColor.GRAY + " (and thunderstorms). "
                    + ChatColor.YELLOW + "Come back after dusk.");
            pl.playSound(pl.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASS, 0.6f, 0.7f);
            return;
        }

        // Creative only is free (owner tag has no elevated perms in survival).
        boolean free = pl.getGameMode() == GameMode.CREATIVE;

        if (!free) {
            if (econ == null) {
                msg(pl, ChatColor.RED + "Economy is offline - try again in a moment.");
                return;
            }
            if (econ.getBalance(pl) < price) {
                msg(pl, ChatColor.RED + "You need " + ChatColor.GOLD + (long) price + " " + currency
                        + ChatColor.RED + " to rent a night. "
                        + ChatColor.GRAY + "(balance: " + (long) econ.getBalance(pl) + ")");
                pl.playSound(pl.getLocation(), Sound.ENTITY_VILLAGER_NO, 0.8f, 1f);
                return;
            }
        }

        // charge up-front
        if (!free) {
            econ.withdrawPlayer(pl, price);
            msg(pl, ChatColor.GRAY + "Paid " + ChatColor.GOLD + (long) price + " " + currency
                    + ChatColor.GRAY + " for a safe night.");
        } else {
            msg(pl, ChatColor.DARK_GRAY + "Creative free rest.");
        }

        startSleep(pl, w, free, b);
    }

    private void startSleep(Player pl, World w, boolean free, Block bedBlock) {
        sleeping.add(pl.getUniqueId());
        pl.setVelocity(pl.getVelocity().zero());
        Location bed = bedBlock.getLocation().add(0.5, 0.5625, 0.5);
        pl.playSound(bed, Sound.BLOCK_NOTE_BLOCK_CHIME, 1f, 0.6f);
        msg(pl, ChatColor.GRAY + "Climbing into the tavern bed… "
                + ChatColor.DARK_GRAY + "(everyone online must sleep for sunrise — 4 beds)");

        Bukkit.getScheduler().runTask(this, () -> {
            if (!pl.isOnline()) { sleeping.remove(pl.getUniqueId()); return; }
            boolean ok = false;
            try {
                ok = pl.sleep(bed, true);
            } catch (Throwable t) {
                getLogger().warning("sleep failed: " + t.getMessage());
            }
            if (!ok) {
                int others = 0;
                for (Player o : w.getPlayers()) {
                    if (!o.getUniqueId().equals(pl.getUniqueId()) && o.getGameMode() != GameMode.SPECTATOR) others++;
                }
                if (others == 0) {
                    w.setTime(wakeTime);
                    if (w.hasStorm()) w.setStorm(false);
                    if (w.isThundering()) w.setThundering(false);
                    saveLockUntilNextNoon(pl.getUniqueId(), w);
                    finishRest(pl, free);
                } else {
                    sleeping.remove(pl.getUniqueId());
                    if (!free && econ != null) {
                        econ.depositPlayer(pl, price);
                        msg(pl, ChatColor.RED + "Could not enter bed — refunded. Try another bed.");
                    } else {
                        msg(pl, ChatColor.RED + "Could not enter bed — try another tavern bed.");
                    }
                }
                return;
            }
            saveLockUntilNextNoon(pl.getUniqueId(), w);
            if (!free) {
                Bukkit.broadcastMessage(ChatColor.DARK_GRAY + pl.getName()
                        + ChatColor.GRAY + " rented a tavern bed ("
                        + ChatColor.GOLD + (long) price + " " + strip(currency)
                        + ChatColor.GRAY + ").");
            }
            if (getConfig().getBoolean("holo.enabled", true)) spawnHolo();
        });
    }

    private void finishRest(Player pl, boolean free) {
        sleeping.remove(pl.getUniqueId());
        if (!pl.isOnline()) return;
        pl.sendTitle(ChatColor.GOLD + "" + ChatColor.BOLD + "Good morning!",
                ChatColor.GRAY + "You rested at the tavern.", 5, 40, 10);
        pl.playSound(pl.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.5f, 1.4f);
        msg(pl, ChatColor.GREEN + "You wake refreshed. "
                + ChatColor.GRAY + "Your rest locks until "
                + ChatColor.YELLOW + "noon"
                + ChatColor.GRAY + " — other players can still use free beds tonight.");
        if (getConfig().getBoolean("holo.enabled", true)) spawnHolo();
    }

    /** Block free vanilla sleep if bed is a tavern bed (safety net). */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = false)
    public void onBedEnter(org.bukkit.event.player.PlayerBedEnterEvent e) {
        Block b = e.getBed();
        if (!isTavernBed(b)) return;
        // Our flow uses Player#sleep after payment; allow only if already in sleeping set (paid)
        if (!sleeping.contains(e.getPlayer().getUniqueId())) {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void onBedLeave(org.bukkit.event.player.PlayerBedLeaveEvent e) {
        Player pl = e.getPlayer();
        if (!sleeping.contains(pl.getUniqueId())) return;
        Bukkit.getScheduler().runTask(this, () -> finishRest(pl, false));
    }

    /* ================= protect bed ================= */

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        if (!isTavernBed(e.getBlock())) return;
        if (e.getPlayer().hasPermission("mavotavern.admin")
                && e.getPlayer().getGameMode() == GameMode.CREATIVE) return;
        e.setCancelled(true);
        msg(e.getPlayer(), ChatColor.RED + "That's the tavern bed - hands off.");
    }

    /* ================= holo ================= */

    private void removeHolo() {
        if (holoUuid != null) {
            try {
                var e = Bukkit.getEntity(holoUuid);
                if (e != null) e.remove();
            } catch (Exception ignored) {}
            holoUuid = null;
        }
        for (UUID id : bedHoloUuids) {
            try {
                var e = Bukkit.getEntity(id);
                if (e != null) e.remove();
            } catch (Exception ignored) {}
        }
        bedHoloUuids.clear();
        // sweep by PDC near bed
        World w = Bukkit.getWorld(bedWorld);
        if (w == null) return;
        Location c = new Location(w, bedX + 0.5, bedY + 5.0, bedZ + 0.5);
        if (getConfig().contains("holo.door-x")) {
            c = new Location(w,
                    getConfig().getDouble("holo.door-x") + 0.5,
                    getConfig().getDouble("holo.door-y") + 5.0,
                    getConfig().getDouble("holo.door-z") + 0.5);
        }
        if (!c.getChunk().isLoaded()) c.getChunk().load();
        for (var e : w.getNearbyEntities(c, 16, 20, 16)) {
            if (e instanceof TextDisplay td
                    && td.getPersistentDataContainer().has(holoKey, PersistentDataType.BYTE)) {
                td.remove();
            }
        }
        String old = getConfig().getString("holo.uuid");
        if (old != null) {
            try {
                var e = Bukkit.getEntity(UUID.fromString(old));
                if (e != null) e.remove();
            } catch (Exception ignored) {}
        }
    }

    private void spawnHolo() {
        if (!bedEnabled) return;
        World w = Bukkit.getWorld(bedWorld);
        if (w == null) return;
        removeHolo();
        double hx, hy, hz;
        if (getConfig().contains("holo.door-x")) {
            hx = getConfig().getDouble("holo.door-x") + 0.5;
            hy = getConfig().getDouble("holo.door-y") + getConfig().getDouble("holo.y-offset", 7.5);
            hz = getConfig().getDouble("holo.door-z") + 0.5;
        } else {
            hx = bedX + 0.5;
            hy = bedY + getConfig().getDouble("holo.y-offset", 7.5);
            hz = bedZ + 0.5;
        }
        Location loc = new Location(w, hx, hy, hz);
        loc.getChunk().load();
        boolean night = isNightish(w);
        String status = night
                ? ChatColor.GREEN + "OPEN" + ChatColor.GRAY + " · right-click any bed"
                : ChatColor.YELLOW + "Opens at dusk";
        String line = ChatColor.RED + "" + ChatColor.BOLD + "\u2616 TAVERN \u2616"
                + "\n" + ChatColor.WHITE + "Safe rest " + ChatColor.GOLD + (long) price + " " + currency
                + ChatColor.GRAY + " / player"
                + "\n" + status
                + "\n" + ChatColor.AQUA + "4 beds" + ChatColor.DARK_GRAY + " · all must sleep for sunrise"
                + "\n" + ChatColor.DARK_GRAY + "1 rest each until noon · bar inside";
        float scale = (float) getConfig().getDouble("holo.scale", 1.6);
        TextDisplay td = w.spawn(loc, TextDisplay.class, d -> {
            d.setText(line);
            d.setBillboard(Display.Billboard.CENTER);
            d.setShadowed(true);
            d.setSeeThrough(true);
            try {
                d.setDefaultBackground(false);
                d.setBackgroundColor(org.bukkit.Color.fromARGB(180, 40, 10, 10));
            } catch (Throwable ignored) {}
            d.setAlignment(TextDisplay.TextAlignment.CENTER);
            d.setLineWidth(240);
            var tr = d.getTransformation();
            tr.getScale().set(scale);
            d.setTransformation(tr);
            d.setViewRange(1.2f);
            try { d.setBrightness(new Display.Brightness(15, 15)); } catch (Throwable ignored) {}
            d.setPersistent(true);
            d.getPersistentDataContainer().set(holoKey, PersistentDataType.BYTE, (byte) 1);
        });
        holoUuid = td.getUniqueId();
        getConfig().set("holo.uuid", holoUuid.toString());
        saveConfig();
        spawnBedHolos(w);
    }

    /** Small price tag above every registered tavern bed. */
    private void spawnBedHolos(World w) {
        if (w == null || !bedEnabled) return;
        java.util.List<int[]> heads = allBedHeads();
        String tag = ChatColor.RED + "" + ChatColor.BOLD + "TAVERN BED"
                + "\n" + ChatColor.GOLD + (long) price + " " + strip(currency)
                + "\n" + ChatColor.GRAY + "right-click · until noon";
        float scale = (float) getConfig().getDouble("bed-holo.scale", 0.85);
        double yo = getConfig().getDouble("bed-holo.y-offset", 1.35);
        for (int[] h : heads) {
            Location loc = new Location(w, h[0] + 0.5, h[1] + yo, h[2] + 0.5);
            if (!loc.getChunk().isLoaded()) loc.getChunk().load();
            // clear old near this bed
            for (var e : w.getNearbyEntities(loc, 1.5, 2.5, 1.5)) {
                if (e instanceof TextDisplay td
                        && td.getPersistentDataContainer().has(holoKey, PersistentDataType.BYTE)) {
                    // don't remove main door holo (higher up) — only low ones
                    if (td.getLocation().getY() < h[1] + 3.5) td.remove();
                }
            }
            TextDisplay td = w.spawn(loc, TextDisplay.class, d -> {
                d.setText(tag);
                d.setBillboard(Display.Billboard.CENTER);
                d.setShadowed(true);
                d.setSeeThrough(true);
                try {
                    d.setDefaultBackground(false);
                    d.setBackgroundColor(org.bukkit.Color.fromARGB(160, 40, 10, 10));
                } catch (Throwable ignored) {}
                d.setAlignment(TextDisplay.TextAlignment.CENTER);
                d.setLineWidth(120);
                var tr = d.getTransformation();
                tr.getScale().set(scale);
                d.setTransformation(tr);
                d.setViewRange(0.8f);
                try { d.setBrightness(new Display.Brightness(15, 15)); } catch (Throwable ignored) {}
                d.setPersistent(true);
                d.getPersistentDataContainer().set(holoKey, PersistentDataType.BYTE, (byte) 1);
            });
            bedHoloUuids.add(td.getUniqueId());
        }
        getLogger().info("Spawned " + bedHoloUuids.size() + " bed holos.");
    }

    /** All tavern bed HEAD block coords. */
    private java.util.List<int[]> allBedHeads() {
        java.util.List<int[]> list = new java.util.ArrayList<>();
        list.add(new int[]{bedX, bedY, bedZ});
        for (int[] off : extraBeds) {
            list.add(new int[]{bedX + off[0], bedY + off[1], bedZ + off[2]});
        }
        return list;
    }

    /* ================= build hut ================= */

    /** Small spruce hut with a red bed, door, lantern. Built relative to player facing. */
    private void buildHut(Player pl) {
        Location base = pl.getLocation().getBlock().getLocation();
        World w = base.getWorld();
        BlockFace face = yawToFace(pl.getLocation().getYaw());
        BlockFace left = rotateLeft(face);
        BlockFace right = rotateRight(face);

        int ox = base.getBlockX();
        int oy = base.getBlockY();
        int oz = base.getBlockZ();

        // clear 5x5x4 and floor
        for (int dx = -2; dx <= 2; dx++) {
            for (int dz = -2; dz <= 2; dz++) {
                for (int dy = 0; dy <= 4; dy++) {
                    Block bl = w.getBlockAt(ox + dx, oy + dy, oz + dz);
                    if (dy == 0) bl.setType(Material.SPRUCE_PLANKS, false);
                    else bl.setType(Material.AIR, false);
                }
            }
        }
        // walls
        for (int dx = -2; dx <= 2; dx++) {
            for (int dz = -2; dz <= 2; dz++) {
                boolean edge = Math.abs(dx) == 2 || Math.abs(dz) == 2;
                if (!edge) continue;
                for (int dy = 1; dy <= 2; dy++) {
                    w.getBlockAt(ox + dx, oy + dy, oz + dz).setType(Material.SPRUCE_LOG, false);
                }
                w.getBlockAt(ox + dx, oy + 3, oz + dz).setType(Material.SPRUCE_STAIRS, false);
            }
        }
        // roof fill
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                w.getBlockAt(ox + dx, oy + 3, oz + dz).setType(Material.SPRUCE_PLANKS, false);
            }
        }
        w.getBlockAt(ox, oy + 4, oz).setType(Material.SPRUCE_SLAB, false);

        // doorway on facing side
        int doorX = ox + face.getModX() * 2;
        int doorZ = oz + face.getModZ() * 2;
        w.getBlockAt(doorX, oy + 1, doorZ).setType(Material.AIR, false);
        w.getBlockAt(doorX, oy + 2, doorZ).setType(Material.AIR, false);
        // spruce door
        Block doorBottom = w.getBlockAt(doorX, oy + 1, doorZ);
        doorBottom.setType(Material.SPRUCE_DOOR, false);
        try {
            org.bukkit.block.data.type.Door door = (org.bukkit.block.data.type.Door) doorBottom.getBlockData();
            door.setFacing(face);
            door.setHalf(org.bukkit.block.data.Bisected.Half.BOTTOM);
            doorBottom.setBlockData(door, false);
            Block doorTop = doorBottom.getRelative(BlockFace.UP);
            doorTop.setType(Material.SPRUCE_DOOR, false);
            org.bukkit.block.data.type.Door door2 = (org.bukkit.block.data.type.Door) doorTop.getBlockData();
            door2.setFacing(face);
            door2.setHalf(org.bukkit.block.data.Bisected.Half.TOP);
            doorTop.setBlockData(door2, false);
        } catch (Throwable ignored) {}

        // bed opposite door (toward -face), head toward door so foot is back wall
        int bedX = ox - face.getModX();
        int bedZ = oz - face.getModZ();
        placeBed(w, bedX, oy + 1, bedZ, face); // head faces door (=face)

        // lantern + carpet + barrel flavour
        w.getBlockAt(ox + left.getModX(), oy + 2, oz + left.getModZ()).setType(Material.LANTERN, false);
        w.getBlockAt(ox + right.getModX(), oy + 1, oz + right.getModZ()).setType(Material.BARREL, false);
        w.getBlockAt(ox, oy + 1, oz).setType(Material.RED_CARPET, false);

        // register bed foot/head: store HEAD position as configured bed
        // placeBed puts head at (bedX,bedY,bedZ)
        getConfig().set("bed.enabled", true);
        getConfig().set("bed.world", w.getName());
        getConfig().set("bed.x", bedX);
        getConfig().set("bed.y", oy + 1);
        getConfig().set("bed.z", bedZ);
        saveConfig();
        reloadLocal();
        spawnHolo();

        pl.sendMessage(prefix + ChatColor.GREEN + "Tavern hut built. "
                + ChatColor.GRAY + "Bed at " + bedX + "," + (oy + 1) + "," + bedZ
                + ChatColor.DARK_GRAY + " \u00B7 right-click at night to test.");
        pl.playSound(pl.getLocation(), Sound.BLOCK_ANVIL_USE, 0.5f, 1.2f);
    }

    private void placeBed(World w, int x, int y, int z, BlockFace headFacing) {
        // head at (x,y,z), foot toward opposite of facing
        BlockFace facing = headFacing;
        Block head = w.getBlockAt(x, y, z);
        Block foot = head.getRelative(facing.getOppositeFace());
        // if foot is a wall (not air/replaceable), try opposite
        if (foot.getType().isSolid() && !foot.getType().name().contains("BED")) {
            facing = facing.getOppositeFace();
            foot = head.getRelative(facing.getOppositeFace());
        }
        // clear both
        head.setType(Material.AIR, false);
        foot.setType(Material.AIR, false);
        head.setType(Material.RED_BED, false);
        foot.setType(Material.RED_BED, false);
        try {
            Bed headData = (Bed) head.getBlockData();
            headData.setPart(Bed.Part.HEAD);
            headData.setFacing(facing);
            head.setBlockData(headData, false);
            Bed footData = (Bed) foot.getBlockData();
            footData.setPart(Bed.Part.FOOT);
            footData.setFacing(facing);
            foot.setBlockData(footData, false);
        } catch (Throwable ex) {
            getLogger().warning("Bed blockdata failed at " + x + "," + y + "," + z + ": " + ex.getMessage());
        }
    }

    private static BlockFace yawToFace(float yaw) {
        yaw = (yaw % 360 + 360) % 360;
        if (yaw >= 315 || yaw < 45) return BlockFace.SOUTH;
        if (yaw < 135) return BlockFace.WEST;
        if (yaw < 225) return BlockFace.NORTH;
        return BlockFace.EAST;
    }
    private static BlockFace rotateLeft(BlockFace f) {
        return switch (f) {
            case NORTH -> BlockFace.WEST;
            case WEST -> BlockFace.SOUTH;
            case SOUTH -> BlockFace.EAST;
            default -> BlockFace.NORTH;
        };
    }
    private static BlockFace rotateRight(BlockFace f) {
        return switch (f) {
            case NORTH -> BlockFace.EAST;
            case EAST -> BlockFace.SOUTH;
            case SOUTH -> BlockFace.WEST;
            default -> BlockFace.NORTH;
        };
    }

    /* ================= commands ================= */

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player pl)) {
            sender.sendMessage("In-game only.");
            return true;
        }
        if (args.length == 0 || args[0].equalsIgnoreCase("info")) {
            msg(pl, ChatColor.GRAY + "Price: " + ChatColor.GOLD + (long) price + " " + currency
                    + ChatColor.GRAY + " \u00B7 Night only: " + nightOnly
                    + ChatColor.GRAY + " \u00B7 Bed: " + (bedEnabled
                    ? (bedWorld + " " + bedX + "," + bedY + "," + bedZ) : ChatColor.RED + "not set"));
            boolean unlocked = bedEnabled && isUnlocked(pl, pl.getWorld());
            if (unlocked) {
                msg(pl, ChatColor.GREEN + "Your tavern rest is available.");
            } else {
                long sec = secondsUntilUnlock(pl, pl.getWorld());
                msg(pl, ChatColor.RED + "Locked until noon "
                        + ChatColor.GRAY + "(~" + (sec / 60L) + " min world-time).");
            }
            return true;
        }
        String sub = args[0].toLowerCase(Locale.ROOT);
        if (!pl.hasPermission("mavotavern.admin") && !sub.equals("info")) {
            msg(pl, ChatColor.RED + "No permission.");
            return true;
        }
        switch (sub) {
            case "setbed" -> {
                Block b = pl.getLocation().getBlock().getRelative(BlockFace.DOWN);
                // prefer target bed
                Block target = pl.getTargetBlockExact(6);
                if (target != null && target.getType().name().endsWith("_BED")) b = target;
                else if (!pl.getLocation().getBlock().getType().name().endsWith("_BED")
                        && !b.getType().name().endsWith("_BED")) {
                    // use block under feet if standing on bed, else require looking at bed
                    Block at = pl.getLocation().getBlock();
                    if (at.getType().name().endsWith("_BED")) b = at;
                    else {
                        msg(pl, ChatColor.RED + "Look at a bed (or stand on one) and run /tavern setbed.");
                        return true;
                    }
                }
                if (b.getBlockData() instanceof Bed bed && bed.getPart() == Bed.Part.FOOT) {
                    b = b.getRelative(bed.getFacing()); // store HEAD
                }
                getConfig().set("bed.enabled", true);
                getConfig().set("bed.world", b.getWorld().getName());
                getConfig().set("bed.x", b.getX());
                getConfig().set("bed.y", b.getY());
                getConfig().set("bed.z", b.getZ());
                saveConfig();
                reloadLocal();
                spawnHolo();
                msg(pl, ChatColor.GREEN + "Tavern bed set at "
                        + b.getX() + "," + b.getY() + "," + b.getZ()
                        + ChatColor.GRAY + " in " + b.getWorld().getName() + ".");
            }
            case "build20" -> {
                if (!pl.isOp() && !pl.hasPermission("mavotavern.admin")) {
                    msg(pl, ChatColor.RED + "No permission.");
                    return true;
                }
                buildInn(pl);
            }
            case "undo" -> {
                if (!pl.isOp() && !pl.hasPermission("mavotavern.admin")) {
                    msg(pl, ChatColor.RED + "No permission.");
                    return true;
                }
                if (args.length >= 2 && args[1].equalsIgnoreCase("here")) undoInnHere(pl);
                else undoLastInn(pl);
            }
            case "beds" -> {
                if (!pl.isOp() && !pl.hasPermission("mavotavern.admin")) {
                    msg(pl, ChatColor.RED + "No permission.");
                    return true;
                }
                // Scan 20x20 around player for red beds and register all heads
                World ww = pl.getWorld();
                int cx = pl.getLocation().getBlockX();
                int cy = pl.getLocation().getBlockY();
                int cz = pl.getLocation().getBlockZ();
                java.util.List<java.util.Map<String, Object>> found = new java.util.ArrayList<>();
                java.util.Set<String> seen = new java.util.HashSet<>();
                for (int x = cx - 12; x <= cx + 12; x++) {
                    for (int z = cz - 12; z <= cz + 12; z++) {
                        for (int y = cy - 1; y <= cy + 2; y++) {
                            Block bb = ww.getBlockAt(x, y, z);
                            if (!bb.getType().name().endsWith("_BED")) continue;
                            if (!(bb.getBlockData() instanceof Bed bed)) continue;
                            Block head = bed.getPart() == Bed.Part.HEAD ? bb
                                    : bb.getRelative(bed.getFacing());
                            String key = head.getX() + "," + head.getY() + "," + head.getZ();
                            if (!seen.add(key)) continue;
                            found.add(java.util.Map.of("x", head.getX(), "y", head.getY(), "z", head.getZ()));
                        }
                    }
                }
                if (found.isEmpty()) {
                    msg(pl, ChatColor.RED + "No beds found nearby.");
                    return true;
                }
                getConfig().set("bed.enabled", true);
                getConfig().set("bed.world", ww.getName());
                getConfig().set("beds", found);
                java.util.Map<String, Object> f0 = found.get(0);
                getConfig().set("bed.x", f0.get("x"));
                getConfig().set("bed.y", f0.get("y"));
                getConfig().set("bed.z", f0.get("z"));
                java.util.List<java.util.Map<String, Object>> ex = new java.util.ArrayList<>();
                int px = (Integer) f0.get("x"), py = (Integer) f0.get("y"), pz = (Integer) f0.get("z");
                for (int i = 1; i < found.size(); i++) {
                    java.util.Map<String, Object> f = found.get(i);
                    ex.add(java.util.Map.of(
                            "x", (Integer) f.get("x") - px,
                            "y", (Integer) f.get("y") - py,
                            "z", (Integer) f.get("z") - pz));
                }
                getConfig().set("extra-beds", ex);
                saveConfig();
                reloadLocal();
                spawnHolo();
                msg(pl, ChatColor.GREEN + "Registered " + found.size() + " tavern beds + holos. All locked behind "
                        + (long) price + " coins.");
            }
            case "setholo" -> {
                if (!pl.isOp() && !pl.hasPermission("mavotavern.admin")) {
                    msg(pl, ChatColor.RED + "No permission.");
                    return true;
                }
                Location l = pl.getLocation();
                getConfig().set("holo.door-x", (double) l.getBlockX());
                getConfig().set("holo.door-y", (double) l.getBlockY());
                getConfig().set("holo.door-z", (double) l.getBlockZ());
                if (!getConfig().isSet("holo.y-offset")) getConfig().set("holo.y-offset", 7.5);
                getConfig().set("holo.enabled", true);
                saveConfig();
                spawnHolo();
                msg(pl, ChatColor.GREEN + "Tavern holo above doorstep "
                        + l.getBlockX() + "," + l.getBlockY() + "," + l.getBlockZ()
                        + ChatColor.GRAY + " (+y " + getConfig().getDouble("holo.y-offset", 7.5) + ").");
            }
            case "bar" -> openBar(pl);
            case "build" -> {
                if (pl.getGameMode() != GameMode.CREATIVE && !pl.isOp()) {
                    msg(pl, ChatColor.RED + "Build the hut in creative (or from console-op).");
                    return true;
                }
                buildHut(pl);
            }
            case "clear" -> {
                getConfig().set("bed.enabled", false);
                saveConfig();
                reloadLocal();
                removeHolo();
                msg(pl, ChatColor.GRAY + "Tavern bed cleared.");
            }
            case "reload" -> {
                reloadLocal();
                loadUsage();
        barDay.clear();
        if (data.getConfigurationSection("bar") != null) {
            for (String us : data.getConfigurationSection("bar").getKeys(false)) {
                try {
                    UUID u = UUID.fromString(us);
                    Map<String, Long> mm = new HashMap<>();
                    if (data.getConfigurationSection("bar." + us) != null) {
                        for (String k : data.getConfigurationSection("bar." + us).getKeys(false)) {
                            mm.put(k, data.getLong("bar." + us + "." + k));
                        }
                    }
                    barDay.put(u, mm);
                } catch (Exception ignored) {}
            }
        }
                if (bedEnabled) spawnHolo();
                msg(pl, ChatColor.GREEN + "Tavern reloaded. Price=" + (long) price);
            }
            case "unlock" -> {
                if (args.length < 2) {
                    clearLock(pl.getUniqueId());
                    msg(pl, ChatColor.GREEN + "Your tavern lock cleared — bed free now.");
                } else {
                    // online or offline by name
                    Player t = Bukkit.getPlayerExact(args[1]);
                    UUID id = t != null ? t.getUniqueId() : Bukkit.getOfflinePlayer(args[1]).getUniqueId();
                    clearLock(id);
                    msg(pl, ChatColor.GREEN + "Cleared tavern lock for " + args[1] + ".");
                }
            }
            default -> msg(pl, ChatColor.GRAY + "/tavern info | setbed | build | build20 | undo [here] | bar | clear | reload | unlock [player]");
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String a, String[] args) {
        if (args.length == 1) {
            String p = args[0].toLowerCase(Locale.ROOT);
            return List.of("info", "setbed", "build", "build20", "undo", "beds", "setholo", "bar", "clear", "reload", "unlock").stream()
                    .filter(x -> x.startsWith(p)).toList();
        }
        return List.of();
    }

    private void msg(Player pl, String m) {
        pl.sendMessage(prefix + m);
    }
    private static String color(String s) {
        return ChatColor.translateAlternateColorCodes('&', s == null ? "" : s);
    }
    private static String strip(String s) {
        return ChatColor.stripColor(s);
    }

    /* ================= 20x20 rebuild + bar ================= */

    /** Half-size of build20 footprint (20x20 → center ±10). */
    private static final int INN_HALF = 10;
    private static final int INN_SIZE = 20; // full width
    private static final int INN_HEIGHT = 6; // clear y-1 .. y+4

    private void rememberInn(World w, int minX, int oy, int minZ) {
        getConfig().set("last-inn.world", w.getName());
        getConfig().set("last-inn.min-x", minX);
        getConfig().set("last-inn.y", oy);
        getConfig().set("last-inn.min-z", minZ);
        getConfig().set("last-inn.size", INN_SIZE);
        getConfig().set("last-inn.height", INN_HEIGHT);
        saveConfig();
    }

    /**
     * 20×20 inn CENTERED on the player (you stand in the middle).
     * Door faces the way you look. Saves bounds for /tavern undo.
     */
    private void buildInn(Player p) {
        World w = p.getWorld();
        Location loc = p.getLocation();
        // Center footprint on player
        int cx = loc.getBlockX();
        int cy = loc.getBlockY();
        int cz = loc.getBlockZ();
        int minX = cx - INN_HALF;
        int minZ = cz - INN_HALF;
        int maxX = minX + INN_SIZE - 1; // 19 offset
        int maxZ = minZ + INN_SIZE - 1;
        int oy = cy;

        // Door on the face you're looking toward
        BlockFace face = yawToFace(loc.getYaw());
        // clear + build
        for (int x = minX; x <= maxX; x++) {
            for (int z = minZ; z <= maxZ; z++) {
                int lx = x - minX;
                int lz = z - minZ;
                // floor
                w.getBlockAt(x, oy - 1, z).setType(Material.SPRUCE_PLANKS, false);
                boolean edge = lx == 0 || lz == 0 || lx == INN_SIZE - 1 || lz == INN_SIZE - 1;
                // clear interior column first
                for (int y = 0; y <= 4; y++) {
                    w.getBlockAt(x, oy + y, z).setType(Material.AIR, false);
                }
                if (edge) {
                    for (int y = 0; y <= 3; y++) {
                        w.getBlockAt(x, oy + y, z).setType(y == 0 ? Material.SPRUCE_LOG : Material.SPRUCE_PLANKS, false);
                    }
                    w.getBlockAt(x, oy + 4, z).setType(Material.DARK_OAK_SLAB, false);
                } else {
                    w.getBlockAt(x, oy + 4, z).setType(Material.SPRUCE_SLAB, false);
                    if ((lx + lz) % 6 == 0) {
                        w.getBlockAt(x, oy + 3, z).setType(Material.LANTERN, false);
                    }
                }
            }
        }

        // Door opening on facing wall (center of that wall)
        int doorX1, doorZ1, doorX2, doorZ2;
        if (face == BlockFace.SOUTH) {
            doorX1 = cx; doorX2 = cx + 1; doorZ1 = doorZ2 = maxZ;
        } else if (face == BlockFace.NORTH) {
            doorX1 = cx; doorX2 = cx + 1; doorZ1 = doorZ2 = minZ;
        } else if (face == BlockFace.EAST) {
            doorZ1 = cz; doorZ2 = cz + 1; doorX1 = doorX2 = maxX;
        } else { // WEST
            doorZ1 = cz; doorZ2 = cz + 1; doorX1 = doorX2 = minX;
        }
        for (int y = 0; y <= 2; y++) {
            w.getBlockAt(doorX1, oy + y, doorZ1).setType(Material.AIR, false);
            w.getBlockAt(doorX2, oy + y, doorZ2).setType(Material.AIR, false);
        }

        // Layout: door on `face`. Bar against BACK wall. Beds on side walls (not behind bar).
        // Innkeeper on door-side of bar, facing the entrance.
        BlockFace left = rotateLeft(face);
        BlockFace right = rotateRight(face);

        // Bar near back wall (opposite door), inset
        int barCX = cx - face.getModX() * (INN_HALF - 4);
        int barCZ = cz - face.getModZ() * (INN_HALF - 4);
        for (int i = -4; i <= 4; i++) {
            int bx = barCX + left.getModX() * i;
            int bz = barCZ + left.getModZ() * i;
            w.getBlockAt(bx, oy, bz).setType(Material.SPRUCE_STAIRS, false);
        }

        // Innkeeper stands toward the door from the bar, looking at the door (yaw = face)
        double vx = barCX + 0.5 + face.getModX() * 1.5;
        double vz = barCZ + 0.5 + face.getModZ() * 1.5;
        float yaw = switch (face) {
            case SOUTH -> 0f;
            case NORTH -> 180f;
            case WEST -> 90f;
            case EAST -> -90f;
            default -> 0f;
        };
        Location vl = new Location(w, vx, oy, vz, yaw, 0f);
        for (Villager oldV : w.getEntitiesByClass(Villager.class)) {
            if (oldV.getPersistentDataContainer().has(boundKey, PersistentDataType.BYTE)
                    && oldV.getLocation().distanceSquared(loc) < (INN_SIZE * INN_SIZE)) {
                oldV.remove();
            }
        }
        w.spawn(vl, Villager.class, vill -> {
            vill.setCustomName(ChatColor.GOLD + "Innkeeper");
            vill.setCustomNameVisible(true);
            vill.setAI(false);
            vill.setInvulnerable(true);
            vill.setProfession(Villager.Profession.NITWIT);
            vill.setRemoveWhenFarAway(false);
            vill.setRotation(yaw, 0f);
            vill.getPersistentDataContainer().set(boundKey, PersistentDataType.BYTE, (byte) 1);
        });

        // 4 beds on left & right walls (clear of bar). Head toward center aisle.
        java.util.List<int[]> bedWorld = new java.util.ArrayList<>();
        for (int side : new int[]{-1, 1}) {
            BlockFace towardCenter = side < 0 ? right : left;
            for (int d : new int[]{-1, 3}) {
                int bx = cx + left.getModX() * side * (INN_HALF - 3) + face.getModX() * d;
                int bz = cz + left.getModZ() * side * (INN_HALF - 3) + face.getModZ() * d;
                placeBed(w, bx, oy, bz, towardCenter);
                bedWorld.add(new int[]{bx, oy, bz});
            }
        }

        // Register ALL 4 beds as absolute heads in config beds: list
        getConfig().set("bed.enabled", true);
        getConfig().set("bed.world", w.getName());
        java.util.List<java.util.Map<String, Object>> bedList = new java.util.ArrayList<>();
        for (int[] b : bedWorld) {
            bedList.add(java.util.Map.of("x", b[0], "y", b[1], "z", b[2]));
        }
        getConfig().set("beds", bedList);
        // primary + legacy extras for older readers
        int[] p0 = bedWorld.get(0);
        getConfig().set("bed.x", p0[0]);
        getConfig().set("bed.y", p0[1]);
        getConfig().set("bed.z", p0[2]);
        java.util.List<java.util.Map<String, Object>> extras = new java.util.ArrayList<>();
        for (int i = 1; i < bedWorld.size(); i++) {
            int[] b = bedWorld.get(i);
            extras.add(java.util.Map.of(
                    "x", b[0] - p0[0],
                    "y", b[1] - p0[1],
                    "z", b[2] - p0[2]));
        }
        getConfig().set("extra-beds", extras);

        // Doorstep holo: just outside door, high above roof
        int doorX = cx + face.getModX() * INN_HALF;
        int doorZ = cz + face.getModZ() * INN_HALF;
        getConfig().set("holo.door-x", (double) doorX);
        getConfig().set("holo.door-y", (double) oy);
        getConfig().set("holo.door-z", (double) doorZ);
        getConfig().set("holo.y-offset", 7.5);
        getConfig().set("holo.enabled", true);
        getConfig().set("holo.scale", 1.6);

        rememberInn(w, minX, oy, minZ);
        saveConfig();
        reloadLocal();
        spawnHolo();
        p.sendMessage(prefix + ChatColor.GREEN + "20×20 tavern centered on you (door "
                + face.name().toLowerCase(Locale.ROOT) + ", 4 side beds, bar at back).");
        p.sendMessage(ChatColor.GRAY + "Holo above door. Fine-tune: stand on doorstep → "
                + ChatColor.YELLOW + "/tavern setholo");
        p.sendMessage(ChatColor.GRAY + "Undo: " + ChatColor.YELLOW + "/tavern undo"
                + ChatColor.GRAY + " · Bar: right-click Innkeeper");
        // Stand just inside doorway looking in
        p.teleport(new Location(w,
                cx + face.getModX() * (INN_HALF - 2) + 0.5,
                oy,
                cz + face.getModZ() * (INN_HALF - 2) + 0.5,
                loc.getYaw(), loc.getPitch()));
    }

    /**
     * Remove last /tavern build20 footprint (air the box + remove tagged innkeepers).
     * Does NOT restore the original plaza wall — only deletes what the inn placed.
     * If the inn overwrote plaza stone, you still need to repair those blocks
     * (CoreProtect /co undo if you have it, or rebuild wall).
     */
    private void undoLastInn(Player p) {
        // 1.1.0 builds did not save last-inn — recover from bed corner (old build = min corner + beds at +3)
        if (!getConfig().contains("last-inn.world") && getConfig().getBoolean("bed.enabled", false)) {
            String wn = getConfig().getString("bed.world", p.getWorld().getName());
            int bx = getConfig().getInt("bed.x");
            int by = getConfig().getInt("bed.y");
            int bz = getConfig().getInt("bed.z");
            // old buildInn: primary bed at ox+3,oz+3 and footprint from ox,oz
            getConfig().set("last-inn.world", wn);
            getConfig().set("last-inn.min-x", bx - 3);
            getConfig().set("last-inn.y", by);
            getConfig().set("last-inn.min-z", bz - 3);
            getConfig().set("last-inn.size", 20);
            saveConfig();
            msg(p, ChatColor.GRAY + "Recovered footprint from bed config (" + (bx-3) + "," + by + "," + (bz-3) + ").");
        }
        if (!getConfig().contains("last-inn.world")) {
            msg(p, ChatColor.YELLOW + "No saved build20 bounds. Stand in the middle of the bad inn and run "
                    + ChatColor.WHITE + "/tavern undo here");
            return;
        }
        String wn = getConfig().getString("last-inn.world");
        World w = Bukkit.getWorld(wn);
        if (w == null) {
            msg(p, ChatColor.RED + "World not loaded: " + wn);
            return;
        }
        int minX = getConfig().getInt("last-inn.min-x");
        int oy = getConfig().getInt("last-inn.y");
        int minZ = getConfig().getInt("last-inn.min-z");
        int size = getConfig().getInt("last-inn.size", INN_SIZE);
        clearInnBox(w, minX, oy, minZ, size);
        getConfig().set("last-inn", null);
        getConfig().set("bed.enabled", false);
        getConfig().set("extra-beds", null);
        saveConfig();
        reloadLocal();
        removeHolo();
        msg(p, ChatColor.GREEN + "Removed last 20×20 tavern footprint ("
                + minX + "," + oy + "," + minZ + " size " + size + ").");
        msg(p, ChatColor.GRAY + "If plaza wall blocks were overwritten, restore with "
                + ChatColor.YELLOW + "/co undo" + ChatColor.GRAY + " (CoreProtect) or rebuild that strip.");
        msg(p, ChatColor.GRAY + "Then stand where the inn should sit and run "
                + ChatColor.YELLOW + "/tavern build20" + ChatColor.GRAY + " (centers on you).");
    }

    /** Clear inn centered on player (emergency). */
    private void undoInnHere(Player p) {
        Location loc = p.getLocation();
        int minX = loc.getBlockX() - INN_HALF;
        int minZ = loc.getBlockZ() - INN_HALF;
        clearInnBox(p.getWorld(), minX, loc.getBlockY(), minZ, INN_SIZE);
        // also try slightly different Y if floor was oy-1
        removeHolo();
        msg(p, ChatColor.GREEN + "Cleared 20×20 box centered on you.");
    }

    private void clearInnBox(World w, int minX, int oy, int minZ, int size) {
        int maxX = minX + size - 1;
        int maxZ = minZ + size - 1;
        // remove innkeepers in/near box
        Location mid = new Location(w, (minX + maxX) / 2.0 + 0.5, oy, (minZ + maxZ) / 2.0 + 0.5);
        for (Villager v : w.getEntitiesByClass(Villager.class)) {
            if (!v.getPersistentDataContainer().has(boundKey, PersistentDataType.BYTE)) continue;
            if (v.getLocation().distanceSquared(mid) < (size * size * 2)) v.remove();
        }
        for (int x = minX; x <= maxX; x++) {
            for (int z = minZ; z <= maxZ; z++) {
                for (int y = oy - 1; y <= oy + 5; y++) {
                    w.getBlockAt(x, y, z).setType(Material.AIR, false);
                }
            }
        }
    }

    private long mcDay(World w) { return w.getFullTime() / 24000L; }

    private boolean barUsed(UUID u, String kind, long day) {
        return barDay.computeIfAbsent(u, k -> new HashMap<>()).getOrDefault(kind, -1L) == day;
    }
    private void markBar(UUID u, String kind, long day) {
        barDay.computeIfAbsent(u, k -> new HashMap<>()).put(kind, day);
        data.set("bar." + u + "." + kind, day);
        dirty = true;
    }

    private void openBar(Player p) {
        if (!getConfig().getBoolean("bar.enabled", true)) {
            msg(p, ChatColor.GRAY + "Bar closed.");
            return;
        }
        long day = mcDay(p.getWorld());
        org.bukkit.inventory.Inventory inv = Bukkit.createInventory(null, 9, ChatColor.GOLD + "Tavern Bar");
        boolean foodUsed = barUsed(p.getUniqueId(), "food", day);
        boolean drinkUsed = barUsed(p.getUniqueId(), "drink", day);
        int fp = getConfig().getInt("bar.food-price", 50);
        int dp = getConfig().getInt("bar.drink-price", 75);
        inv.setItem(3, boundIcon(Material.COOKED_BEEF, ChatColor.RED + "Hearty Stew",
                List.of(ChatColor.GRAY + "Heal + food, soulbound",
                        ChatColor.YELLOW + "Price: " + fp + " " + strip(currency),
                        foodUsed ? ChatColor.RED + "Already eaten today" : ChatColor.GREEN + "Click to buy"), "food"));
        inv.setItem(5, boundIcon(Material.HONEY_BOTTLE, ChatColor.AQUA + "House Ale",
                List.of(ChatColor.GRAY + "Refresh + short regen, soulbound",
                        ChatColor.YELLOW + "Price: " + dp + " " + strip(currency),
                        drinkUsed ? ChatColor.RED + "Already drunk today" : ChatColor.GREEN + "Click to buy"), "drink"));
        p.openInventory(inv);
    }

    private ItemStack boundIcon(Material mat, String name, List<String> lore, String tag) {
        ItemStack it = new ItemStack(mat);
        ItemMeta m = it.getItemMeta();
        m.setDisplayName(name);
        m.setLore(lore);
        m.getPersistentDataContainer().set(boundKey, PersistentDataType.STRING, tag);
        it.setItemMeta(m);
        return it;
    }

    private ItemStack makeSoulbound(Material mat, String name, String kind) {
        ItemStack it = new ItemStack(mat);
        ItemMeta m = it.getItemMeta();
        m.setDisplayName(name);
        m.setLore(List.of(ChatColor.DARK_PURPLE + "Soulbound", ChatColor.GRAY + "Tavern only — cannot be sold"));
        m.getPersistentDataContainer().set(boundKey, PersistentDataType.STRING, kind);
        it.setItemMeta(m);
        return it;
    }

    @EventHandler
    public void onBarClick(org.bukkit.event.inventory.InventoryClickEvent e) {
        if (e.getView().getTitle() == null) return;
        if (!ChatColor.stripColor(e.getView().getTitle()).equals("Tavern Bar")) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        ItemStack cur = e.getCurrentItem();
        if (cur == null || !cur.hasItemMeta()) return;
        String tag = cur.getItemMeta().getPersistentDataContainer().get(boundKey, PersistentDataType.STRING);
        if (tag == null) return;
        long day = mcDay(p.getWorld());
        if (barUsed(p.getUniqueId(), tag, day)) {
            msg(p, ChatColor.RED + "Already had your " + tag + " today. Come back next MC day.");
            return;
        }
        int price = tag.equals("food") ? getConfig().getInt("bar.food-price", 50) : getConfig().getInt("bar.drink-price", 75);
        if (econ == null || !econ.has(p, price)) {
            msg(p, ChatColor.RED + "Need " + price + " coins.");
            return;
        }
        econ.withdrawPlayer(p, price);
        markBar(p.getUniqueId(), tag, day);
        if (tag.equals("food")) {
            ItemStack food = makeSoulbound(Material.COOKED_BEEF, ChatColor.RED + "Hearty Stew", "food");
            food.setAmount(1);
            p.getInventory().addItem(food);
            // instant heal sip
            try {
                var attr = p.getAttribute(Attribute.MAX_HEALTH);
                double max = attr != null ? attr.getValue() : 20;
                p.setHealth(Math.min(max, p.getHealth() + getConfig().getInt("bar.food-heal", 8)));
            } catch (Throwable t) {
                p.setFoodLevel(Math.min(20, p.getFoodLevel() + 8));
            }
            p.setFoodLevel(Math.min(20, p.getFoodLevel() + 8));
            msg(p, ChatColor.GREEN + "Hearty stew served (soulbound). Feel better!");
        } else {
            ItemStack drink = makeSoulbound(Material.HONEY_BOTTLE, ChatColor.AQUA + "House Ale", "drink");
            p.getInventory().addItem(drink);
            int sec = getConfig().getInt("bar.drink-effects-seconds", 120);
            p.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, sec * 20, 0));
            p.addPotionEffect(new PotionEffect(PotionEffectType.SATURATION, 20 * 5, 0));
            msg(p, ChatColor.GREEN + "House ale served (soulbound). Cheers!");
        }
        p.closeInventory();
    }

    @EventHandler
    public void onInnkeeper(org.bukkit.event.player.PlayerInteractEntityEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        if (!(e.getRightClicked() instanceof Villager v)) return;
        if (!v.getPersistentDataContainer().has(boundKey, PersistentDataType.BYTE)) return;
        e.setCancelled(true);
        openBar(e.getPlayer());
    }

    /** Prevent selling soulbound tavern items via any inventory named Shop if present - mark lore only; ESGUI sell filter may need material blacklist. */
    @EventHandler
    public void onDropBound(org.bukkit.event.player.PlayerDropItemEvent e) {
        ItemStack it = e.getItemDrop().getItemStack();
        if (it.hasItemMeta() && it.getItemMeta().getPersistentDataContainer().has(boundKey, PersistentDataType.STRING)) {
            // allow drop but item stays soulbound; shops should refuse via lore/name - optional cancel:
            // e.setCancelled(true);
        }
    }

}
