package mavo.borders;

import com.cjburkey.claimchunk.ClaimChunk;
import com.cjburkey.claimchunk.chunk.ChunkHandler;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.HeightMap;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.data.BlockData;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.player.PlayerBucketEmptyEvent;
import org.bukkit.event.player.PlayerBucketFillEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

public final class ChunkBorders extends JavaPlugin implements Listener {

    private final Map<UUID, BukkitTask> active = new HashMap<>();
    private final Map<UUID, List<Location>> shown = new HashMap<>();
    private final Map<UUID, Long> lastWarn = new HashMap<>();

    private Material borderMat;
    private Material cornerMat;
    private Material bufferMat;
    private int refreshTicks;
    private boolean cornersOnly;
    private boolean bufferEnabled;
    private int bufferRadius;
    private boolean bufferShow;
    private String bufferMsg;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        loadCfg();
        getServer().getPluginManager().registerEvents(this, this);
        getLogger().info("MAVO ChunkBorders v1.2 enabled (buffer protection: "
                + (bufferEnabled ? bufferRadius + " chunk(s))" : "off)"));
    }

    private void loadCfg() {
        borderMat = mat("border-block", "RED_STAINED_GLASS");
        cornerMat = mat("corner-block", "BLUE_STAINED_GLASS");
        bufferMat = mat("buffer-block", "ORANGE_STAINED_GLASS");
        refreshTicks = Math.max(20, getConfig().getInt("refresh-ticks", 40));
        cornersOnly = getConfig().getBoolean("corners-only", false);
        bufferEnabled = getConfig().getBoolean("buffer.enabled", true);
        bufferRadius = Math.max(1, getConfig().getInt("buffer.radius", 1));
        bufferShow = getConfig().getBoolean("buffer.show-in-borders", true);
        bufferMsg = ChatColor.translateAlternateColorCodes('&', getConfig().getString("buffer.message",
                "&c\u26d4 You are too close to &6%owner%&c's land! Keep &e%radius% chunk(s)&c distance."));
    }

    private Material mat(String key, String def) {
        Material m = Material.matchMaterial(getConfig().getString(key, def));
        return m != null ? m : Material.matchMaterial(def);
    }

    @Override
    public void onDisable() {
        for (UUID id : new ArrayList<>(active.keySet())) stop(Bukkit.getPlayer(id), id);
    }

    // ---------------- buffer protection (unchanged) ----------------

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) { if (denyBuild(e.getPlayer(), e.getBlock())) e.setCancelled(true); }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) { if (denyBuild(e.getPlayer(), e.getBlock())) e.setCancelled(true); }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBucketEmpty(PlayerBucketEmptyEvent e) { if (denyBuild(e.getPlayer(), e.getBlock())) e.setCancelled(true); }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBucketFill(PlayerBucketFillEvent e) { if (denyBuild(e.getPlayer(), e.getBlock())) e.setCancelled(true); }

    private boolean denyBuild(Player p, Block b) {
        if (!bufferEnabled) return false;
        if (p.hasPermission("mavoborders.bypass")) return false;
        ClaimChunk cc = ClaimChunk.getInstance();
        if (cc == null) return false;
        ChunkHandler ch = cc.getChunkHandler();
        World w = b.getWorld();
        int cx = b.getX() >> 4, cz = b.getZ() >> 4;
        if (ch.isClaimed(w, cx, cz)) return false; // inside claims ClaimChunk itself rules
        UUID me = p.getUniqueId();
        for (int dx = -bufferRadius; dx <= bufferRadius; dx++) {
            for (int dz = -bufferRadius; dz <= bufferRadius; dz++) {
                if (dx == 0 && dz == 0) continue;
                if (!ch.isClaimed(w, cx + dx, cz + dz)) continue;
                UUID owner = ch.getOwner(w, cx + dx, cz + dz);
                if (owner == null || owner.equals(me)) continue;
                long now = System.currentTimeMillis();
                if (now - lastWarn.getOrDefault(me, 0L) > 2000L) {
                    String name = Bukkit.getOfflinePlayer(owner).getName();
                    p.sendMessage(bufferMsg.replace("%owner%", name != null ? name : "someone")
                            .replace("%radius%", String.valueOf(bufferRadius)));
                    lastWarn.put(me, now);
                }
                return true;
            }
        }
        return false;
    }

    // ---------------- command ----------------

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player p)) { sender.sendMessage("Players only."); return true; }
        if (args.length > 0 && args[0].equalsIgnoreCase("reload") && p.hasPermission("mavoborders.admin")) {
            reloadConfig();
            loadCfg();
            p.sendMessage(ChatColor.GREEN + "ChunkBorders config reloaded.");
            return true;
        }
        UUID id = p.getUniqueId();
        if (active.containsKey(id)) {
            stop(p, id);
            p.sendMessage(ChatColor.YELLOW + "Chunk borders " + ChatColor.RED + "OFF");
        } else {
            BukkitTask t = Bukkit.getScheduler().runTaskTimer(this, () -> render(p), 1L, refreshTicks);
            active.put(id, t);
            p.sendMessage(ChatColor.YELLOW + "Chunk borders " + ChatColor.GREEN + "ON" + ChatColor.GRAY
                    + " (" + colorWord(borderMat) + " = claims"
                    + (bufferEnabled && bufferShow ? ", " + colorWord(bufferMat) + " = no-build buffer" : "") + ")");
        }
        return true;
    }

    private String colorWord(Material m) {
        String n = m.name().toLowerCase(Locale.ROOT);
        int i = n.indexOf("_stained_glass");
        if (i > 0) n = n.substring(0, i);
        return n.replace('_', ' ');
    }

    private void stop(Player p, UUID id) {
        BukkitTask t = active.remove(id);
        if (t != null) t.cancel();
        List<Location> old = shown.remove(id);
        if (old != null && p != null && p.isOnline())
            for (Location loc : old) p.sendBlockChange(loc, loc.getBlock().getBlockData());
    }

    // ---------------- rendering ----------------

    private void render(Player p) {
        if (!p.isOnline()) { stop(p, p.getUniqueId()); return; }
        ClaimChunk cc = ClaimChunk.getInstance();
        if (cc == null) return;
        ChunkHandler ch = cc.getChunkHandler();
        World w = p.getWorld();
        int pcx = p.getLocation().getChunk().getX();
        int pcz = p.getLocation().getChunk().getZ();
        int py = p.getLocation().getBlockY();

        List<Location> old = shown.remove(p.getUniqueId());
        if (old != null) for (Location loc : old) p.sendBlockChange(loc, loc.getBlock().getBlockData());

        List<Location> now = new ArrayList<>();
        BlockData borderData = borderMat.createBlockData();
        BlockData cornerData = cornerMat.createBlockData();
        BlockData bufferData = bufferMat.createBlockData();

        int radius = 3;
        for (int cx = pcx - radius; cx <= pcx + radius; cx++) {
            for (int cz = pcz - radius; cz <= pcz + radius; cz++) {
                if (ch.isClaimed(w, cx, cz)) {
                    UUID owner = ch.getOwner(w, cx, cz);
                    boolean mine = p.getUniqueId().equals(owner);
                    if (!mine && !getConfig().getBoolean("show-others", true)) continue;
                    boolean n = sameOwner(ch, w, cx, cz - 1, owner);
                    boolean s = sameOwner(ch, w, cx, cz + 1, owner);
                    boolean e = sameOwner(ch, w, cx + 1, cz, owner);
                    boolean wst = sameOwner(ch, w, cx - 1, cz, owner);
                    int bx = cx << 4, bz = cz << 4;
                    for (int i = 0; i < 16; i++) {
                        boolean corner = (i == 0 || i == 15);
                        if (!n) mark(p, w, bx + i, bz, py, corner, borderData, cornerData, now);
                        if (!s) mark(p, w, bx + i, bz + 15, py, corner, borderData, cornerData, now);
                        if (!wst) mark(p, w, bx, bz + i, py, corner, borderData, cornerData, now);
                        if (!e) mark(p, w, bx + 15, bz + i, py, corner, borderData, cornerData, now);
                    }
                } else if (bufferEnabled && bufferShow && inStrangersBuffer(ch, w, cx, cz, p.getUniqueId())) {
                    int bx = cx << 4, bz = cz << 4;
                    for (int i = 0; i < 16; i += 4) {
                        markSimple(p, w, bx + i, bz, py, bufferData, now);
                        markSimple(p, w, bx + i, bz + 15, py, bufferData, now);
                        markSimple(p, w, bx, bz + i, py, bufferData, now);
                        markSimple(p, w, bx + 15, bz + i, py, bufferData, now);
                    }
                }
            }
        }
        shown.put(p.getUniqueId(), now);
    }

    private boolean inStrangersBuffer(ChunkHandler ch, World w, int cx, int cz, UUID me) {
        for (int dx = -bufferRadius; dx <= bufferRadius; dx++) {
            for (int dz = -bufferRadius; dz <= bufferRadius; dz++) {
                if (dx == 0 && dz == 0) continue;
                if (!ch.isClaimed(w, cx + dx, cz + dz)) continue;
                UUID owner = ch.getOwner(w, cx + dx, cz + dz);
                if (owner == null || owner.equals(me)) continue;
                return true;
            }
        }
        return false;
    }

    private boolean sameOwner(ChunkHandler ch, World w, int cx, int cz, UUID owner) {
        return ch.isClaimed(w, cx, cz) && owner != null && owner.equals(ch.getOwner(w, cx, cz));
    }

    private void mark(Player p, World w, int x, int z, int py, boolean corner,
                      BlockData border, BlockData cornerD, List<Location> out) {
        if (cornersOnly && !corner) return;
        Location loc = surface(w, x, z, py);
        p.sendBlockChange(loc, corner ? cornerD : border);
        out.add(loc);
    }

    private void markSimple(Player p, World w, int x, int z, int py, BlockData data, List<Location> out) {
        Location loc = surface(w, x, z, py);
        p.sendBlockChange(loc, data);
        out.add(loc);
    }

    /**
     * Ground finder that keeps border lines CONTINUOUS:
     * 1. Heightmap that IGNORES leaves + plants (no more lines on treetops).
     * 2. If the result is still above the player's head (roof, dense canopy,
     *    overhang), scan down from just above the player's level for the first
     *    solid block, so the line stays on the ground the player is walking on.
     */
    private Location surface(World w, int x, int z, int py) {
        int min = w.getMinHeight();
        int y = w.getHighestBlockYAt(x, z, HeightMap.MOTION_BLOCKING_NO_LEAVES);
        if (y > py + 3) {
            int start = Math.min(py + 3, w.getMaxHeight() - 1);
            int floor = Math.max(min, py - 24);
            for (int i = start; i >= floor; i--) {
                if (!w.getBlockAt(x, i, z).isPassable()) { y = i; break; }
            }
        }
        return new Location(w, x, Math.max(min, y), z);
    }
}
