/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.milkbowl.vault.economy.Economy
 *  org.bukkit.Bukkit
 *  org.bukkit.ChatColor
 *  org.bukkit.Material
 *  org.bukkit.OfflinePlayer
 *  org.bukkit.World
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandSender
 *  org.bukkit.command.TabCompleter
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.configuration.file.YamlConfiguration
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.Listener
 *  org.bukkit.event.inventory.InventoryClickEvent
 *  org.bukkit.inventory.Inventory
 *  org.bukkit.inventory.InventoryHolder
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.ItemMeta
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.plugin.RegisteredServiceProvider
 *  org.bukkit.plugin.java.JavaPlugin
 *  org.bukkit.scheduler.BukkitRunnable
 *  org.bukkit.util.Vector
 */
package mavo.quests;

import java.io.File;
import java.lang.invoke.CallSite;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.UUID;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

public final class Quests
extends JavaPlugin
implements Listener,
TabCompleter {
    private Economy econ;
    private final Map<String, Quest> pool = new HashMap<String, Quest>();
    private final List<Quest> active = new ArrayList<Quest>();
    private final List<Material> mysteryPool = new ArrayList<Material>();
    private int refreshDays;
    private int boardSize;
    private int wCoins;
    private int wItem;
    private int wBoth;
    private long cycleStartDay = -1L;
    private File dataFile;
    private YamlConfiguration data;
    private final Random rng = new Random();
    private static final int[] QUEST_SLOTS = new int[]{10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25};

    public void onEnable() {
        this.saveDefaultConfig();
        this.dataFile = new File(this.getDataFolder(), "data.yml");
        this.data = YamlConfiguration.loadConfiguration((File)this.dataFile);
        RegisteredServiceProvider rsp = this.getServer().getServicesManager().getRegistration(Economy.class);
        if (rsp != null) {
            this.econ = (Economy)rsp.getProvider();
        }
        this.loadConfigValues();
        this.cycleStartDay = this.data.getLong("cycle-start-day", -1L);
        List<String> savedActive = this.data.getStringList("active");
        if (this.cycleStartDay < 0L || savedActive.isEmpty()) {
            this.rollBoard(false);
        } else {
            for (String id : savedActive) {
                Quest q = this.pool.get(id);
                if (q == null) continue;
                q.used = this.data.getInt("used." + id, 0);
                this.active.add(q);
            }
            if (this.active.isEmpty()) {
                this.rollBoard(false);
            }
        }
        this.getServer().getPluginManager().registerEvents((Listener)this, (Plugin)this);
        if (this.getCommand("quest") != null) {
            this.getCommand("quest").setTabCompleter((TabCompleter)this);
        }
        new BukkitRunnable(){

            public void run() {
                Quests.this.checkRefresh();
            }
        }.runTaskTimer((Plugin)this, 200L, 400L);
        this.getLogger().info("MAVOQuests v1.4 enabled: pool " + this.pool.size() + ", board " + this.active.size() + "/" + this.boardSize + ", refresh " + this.refreshDays + " MC days.");
    }

    public void onDisable() {
        this.saveData();
    }

    private long currentDay() {
        return ((World)Bukkit.getWorlds().get(0)).getFullTime() / 24000L;
    }

    private void loadConfigValues() {
        ConfigurationSection sec;
        this.pool.clear();
        this.mysteryPool.clear();
        this.refreshDays = Math.max(1, this.getConfig().getInt("refresh-days", 3));
        this.boardSize = Math.max(1, this.getConfig().getInt("board-size", 10));
        this.wCoins = Math.max(0, this.getConfig().getInt("reward-weights.coins-only", 40));
        this.wItem = Math.max(0, this.getConfig().getInt("reward-weights.item-only", 30));
        this.wBoth = Math.max(0, this.getConfig().getInt("reward-weights.both", 30));
        if (this.wCoins + this.wItem + this.wBoth <= 0) {
            this.wCoins = 100;
        }
        for (String s : this.getConfig().getStringList("mystery-items")) {
            Material m = Material.matchMaterial((String)s);
            if (m != null && m.isItem()) {
                this.mysteryPool.add(m);
                continue;
            }
            this.getLogger().warning("mystery-items: unknown material " + s);
        }
        if (this.mysteryPool.isEmpty()) {
            this.mysteryPool.add(Material.BREAD);
        }
        if ((sec = this.getConfig().getConfigurationSection("quests")) == null) {
            return;
        }
        for (String id : sec.getKeys(false)) {
            ConfigurationSection q = sec.getConfigurationSection(id);
            if (q == null) continue;
            Quest quest = new Quest();
            quest.id = id.toLowerCase(Locale.ROOT);
            quest.display = ChatColor.translateAlternateColorCodes((char)'&', (String)q.getString("display", id));
            quest.wanted = Material.matchMaterial((String)q.getString("item", "WHEAT"));
            if (quest.wanted == null) {
                this.getLogger().warning("Quest " + id + ": bad item, skipped");
                continue;
            }
            quest.amount = Math.max(1, q.getInt("amount", 16));
            quest.rewardCoins = q.getInt("reward-coins", 0);
            quest.rewardCommands = q.getStringList("reward-commands");
            quest.stock = Math.max(0, q.getInt("stock", 0));
            this.pool.put(quest.id, quest);
        }
    }

    private void saveData() {
        this.data.set("cycle-start-day", (Object)this.cycleStartDay);
        ArrayList<String> ids = new ArrayList<String>();
        for (Quest q : this.active) {
            ids.add(q.id);
            this.data.set("used." + q.id, (Object)q.used);
        }
        this.data.set("active", ids);
        try {
            this.data.save(this.dataFile);
        }
        catch (Exception e) {
            this.getLogger().warning("save failed: " + e.getMessage());
        }
    }

    private void rollBoard(boolean announce) {
        this.active.clear();
        this.data.set("done", null);
        this.data.set("used", null);
        ArrayList<Quest> all = new ArrayList<Quest>(this.pool.values());
        Collections.shuffle(all, this.rng);
        for (int i = 0; i < all.size() && this.active.size() < this.boardSize; ++i) {
            Quest q = (Quest)all.get(i);
            q.used = 0;
            this.active.add(q);
        }
        this.cycleStartDay = this.currentDay();
        this.saveData();
        if (announce) {
            Bukkit.broadcastMessage((String)(String.valueOf(ChatColor.GOLD) + "\ud83d\udcdc " + String.valueOf(ChatColor.YELLOW) + "The quest board rolled " + String.valueOf(ChatColor.AQUA) + this.active.size() + " new quests" + String.valueOf(ChatColor.YELLOW) + "! " + String.valueOf(ChatColor.GOLD) + "/quest"));
        }
    }

    private void checkRefresh() {
        if (this.currentDay() - this.cycleStartDay >= (long)this.refreshDays) {
            this.rollBoard(true);
        }
    }

    private boolean doneThisCycle(UUID u, Quest q) {
        return this.data.getBoolean("done." + String.valueOf(u) + "." + q.id, false);
    }

    private void markDone(UUID u, Quest q) {
        this.data.set("done." + String.valueOf(u) + "." + q.id, (Object)true);
    }

    private int completions(UUID u) {
        return this.data.getInt("stats." + String.valueOf(u) + ".completed", 0);
    }

    private void addCompletion(UUID u) {
        this.data.set("stats." + String.valueOf(u) + ".completed", (Object)(this.completions(u) + 1));
        this.data.set("stats.total", (Object)(this.totalCompletions() + 1));
    }

    private int totalCompletions() {
        return this.data.getInt("stats.total", 0);
    }

    private Quest findActive(String id) {
        for (Quest q : this.active) {
            if (!q.id.equalsIgnoreCase(id)) continue;
            return q;
        }
        return null;
    }

    private String fmt(long n) {
        return String.format(Locale.UK, "%,d", n);
    }

    private String matName(Material m) {
        return m.name().toLowerCase(Locale.ROOT).replace('_', ' ');
    }

    private long countInv(Player p, Material m) {
        long have = 0L;
        for (ItemStack it : p.getInventory().getContents()) {
            if (it == null || it.getType() != m) continue;
            have += (long)it.getAmount();
        }
        return have;
    }

    private void openGui(Player p) {
        Inventory inv;
        BoardHolder holder = new BoardHolder(this);
        holder.inv = inv = Bukkit.createInventory((InventoryHolder)holder, (int)36, (String)(String.valueOf(ChatColor.DARK_RED) + String.valueOf(ChatColor.BOLD) + "Quest Board"));
        ItemStack fill = this.named(new ItemStack(Material.GRAY_STAINED_GLASS_PANE), " ", null);
        for (int i = 0; i < inv.getSize(); ++i) {
            inv.setItem(i, fill);
        }
        long daysLeft = (long)this.refreshDays - (this.currentDay() - this.cycleStartDay);
        inv.setItem(4, this.named(new ItemStack(Material.CLOCK), String.valueOf(ChatColor.YELLOW) + "New random quests in " + Math.max(0L, daysLeft) + " MC day" + (daysLeft == 1L ? "" : "s"), Arrays.asList(String.valueOf(ChatColor.GRAY) + this.active.size() + " random quests from a pool of " + this.pool.size() + ".", String.valueOf(ChatColor.GRAY) + "Rewards can include a " + String.valueOf(ChatColor.AQUA) + "mystery item stack" + String.valueOf(ChatColor.GRAY) + "!")));
        inv.setItem(31, this.named(new ItemStack(Material.PLAYER_HEAD), String.valueOf(ChatColor.AQUA) + "Your quest stats", Arrays.asList(String.valueOf(ChatColor.GRAY) + "Completed (lifetime): " + String.valueOf(ChatColor.YELLOW) + this.fmt(this.completions(p.getUniqueId())), String.valueOf(ChatColor.GRAY) + "Server total: " + String.valueOf(ChatColor.YELLOW) + this.fmt(this.totalCompletions()))));
        for (int i = 0; i < this.active.size() && i < QUEST_SLOTS.length; ++i) {
            Quest q = this.active.get(i);
            boolean out = q.stock > 0 && q.used >= q.stock;
            boolean mine = this.doneThisCycle(p.getUniqueId(), q);
            long have = this.countInv(p, q.wanted);
            ItemStack it = new ItemStack(out || mine ? Material.BARRIER : q.wanted);
            ArrayList<String> lore = new ArrayList<String>();
            lore.add(String.valueOf(ChatColor.GRAY) + "Bring: " + String.valueOf(ChatColor.YELLOW) + q.amount + " " + this.matName(q.wanted));
            lore.add(String.valueOf(ChatColor.GRAY) + "Reward: " + String.valueOf(ChatColor.YELLOW) + (String)(q.rewardCoins > 0 ? "up to " + this.fmt(q.rewardCoins) + " coins" : "?") + String.valueOf(ChatColor.AQUA) + " + mystery?");
            if (q.stock > 0) {
                lore.add(String.valueOf(ChatColor.GRAY) + "Stock: " + String.valueOf(ChatColor.YELLOW) + (q.stock - q.used) + "/" + q.stock);
            }
            lore.add("");
            if (mine) {
                lore.add(String.valueOf(ChatColor.GREEN) + "\u2714 Completed this cycle");
            } else if (out) {
                lore.add(String.valueOf(ChatColor.RED) + "OUT OF STOCK until refresh");
            } else {
                lore.add(String.valueOf(ChatColor.GRAY) + "You carry: " + String.valueOf(have >= (long)q.amount ? ChatColor.GREEN : ChatColor.RED) + have + "/" + q.amount);
                lore.add(have >= (long)q.amount ? String.valueOf(ChatColor.YELLOW) + "Click to TURN IN!" : String.valueOf(ChatColor.DARK_GRAY) + "Gather more, then click");
            }
            ItemMeta meta = it.getItemMeta();
            meta.setDisplayName(q.display);
            meta.setLore(lore);
            it.setItemMeta(meta);
            inv.setItem(QUEST_SLOTS[i], it);
            holder.slots.put(QUEST_SLOTS[i], q);
        }
        p.openInventory(inv);
    }

    private ItemStack named(ItemStack it, String name, List<String> lore) {
        ItemMeta m = it.getItemMeta();
        m.setDisplayName(name);
        if (lore != null) {
            m.setLore(lore);
        }
        it.setItemMeta(m);
        return it;
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getInventory().getHolder() instanceof BoardHolder)) {
            return;
        }
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player)) {
            return;
        }
        BoardHolder holder = (BoardHolder)e.getInventory().getHolder();
        Quest q = holder.slots.get(e.getRawSlot());
        if (q == null) {
            return;
        }
        Player p = (Player)e.getWhoClicked();
        this.complete(p, q);
        this.openGui(p);
    }

    private void complete(Player p, Quest q) {
        if (p.getGameMode() != org.bukkit.GameMode.SURVIVAL) {
            p.sendMessage(String.valueOf(ChatColor.RED) + "Quests can only be turned in while in survival mode!");
            return;
        }
        if (this.findActive(q.id) == null) {
            p.sendMessage(String.valueOf(ChatColor.RED) + "That quest isn't on the board right now.");
            return;
        }
        if (q.stock > 0 && q.used >= q.stock) {
            p.sendMessage(String.valueOf(ChatColor.RED) + "Out of stock until the board refreshes!");
            return;
        }
        if (this.doneThisCycle(p.getUniqueId(), q)) {
            p.sendMessage(String.valueOf(ChatColor.RED) + "Already completed this cycle!");
            return;
        }
        long have = this.countInv(p, q.wanted);
        if (have < (long)q.amount) {
            p.sendMessage(String.valueOf(ChatColor.RED) + "Need " + String.valueOf(ChatColor.YELLOW) + q.amount + " " + this.matName(q.wanted) + String.valueOf(ChatColor.RED) + " (you have " + have + ")");
            return;
        }
        long toRemove = q.amount;
        ItemStack[] contents = p.getInventory().getContents();
        for (int i = 0; i < contents.length && toRemove > 0L; ++i) {
            ItemStack it = contents[i];
            if (it == null || it.getType() != q.wanted) continue;
            int take = (int)Math.min((long)it.getAmount(), toRemove);
            toRemove -= (long)take;
            if (take >= it.getAmount()) {
                p.getInventory().setItem(i, null);
                continue;
            }
            it.setAmount(it.getAmount() - take);
        }
        ++q.used;
        this.markDone(p.getUniqueId(), q);
        this.addCompletion(p.getUniqueId());
        int roll = this.rng.nextInt(this.wCoins + this.wItem + this.wBoth);
        String mode = roll < this.wCoins ? "coins" : (roll < this.wCoins + this.wItem ? "item" : "both");
        ArrayList<String> rewardMsg = new ArrayList<String>();
        if ((mode.equals("coins") || mode.equals("both")) && q.rewardCoins > 0 && this.econ != null) {
            this.econ.depositPlayer((OfflinePlayer)p, (double)q.rewardCoins);
            rewardMsg.add(((String.valueOf(ChatColor.YELLOW) + this.fmt(q.rewardCoins) + " coins")));
        }
        if (mode.equals("item") || mode.equals("both")) {
            Material m = this.mysteryPool.get(this.rng.nextInt(this.mysteryPool.size()));
            int max = Math.min(64, m.getMaxStackSize());
            int amt = 1 + this.rng.nextInt(max);
            ItemStack stack = new ItemStack(m, amt);
            HashMap<Integer, ItemStack> overflow = p.getInventory().addItem(new ItemStack[]{stack});
            for (ItemStack left : overflow.values()) {
                p.getWorld().dropItem(p.getLocation(), left).setVelocity(new Vector(0.0, 0.2, 0.0));
            }
            rewardMsg.add(((String.valueOf(ChatColor.AQUA) + amt + "x " + this.matName(m) + String.valueOf(ChatColor.GOLD) + " \ud83c\udf81")));
        }
        if (rewardMsg.isEmpty() && q.rewardCoins > 0 && this.econ != null) {
            this.econ.depositPlayer((OfflinePlayer)p, (double)q.rewardCoins);
            rewardMsg.add(((String.valueOf(ChatColor.YELLOW) + this.fmt(q.rewardCoins) + " coins")));
        }
        for (String c : q.rewardCommands) {
            Bukkit.dispatchCommand((CommandSender)Bukkit.getConsoleSender(), (String)c.replace("%player%", p.getName()));
        }
        int lifetime = this.completions(p.getUniqueId());
        p.sendMessage(String.valueOf(ChatColor.GREEN) + "\u2714 " + q.display + String.valueOf(ChatColor.GREEN) + " \u2192 " + String.join((CharSequence)(String.valueOf(ChatColor.GREEN) + " + "), rewardMsg) + String.valueOf(ChatColor.GRAY) + " (lifetime: " + this.fmt(lifetime) + ")");
        Bukkit.broadcastMessage((String)(String.valueOf(ChatColor.AQUA) + p.getName() + String.valueOf(ChatColor.GRAY) + " completed " + q.display + (String)(q.stock > 0 ? String.valueOf(ChatColor.GRAY) + " (" + (q.stock - q.used) + " left)" : "")));
        this.saveData();
    }

    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length > 0 && args[0].equalsIgnoreCase("reload")) {
            if (!sender.hasPermission("mavoquests.admin")) {
                sender.sendMessage(String.valueOf(ChatColor.RED) + "No permission.");
                return true;
            }
            this.saveData();
            this.reloadConfig();
            this.loadConfigValues();
            ArrayList<String> ids = new ArrayList<String>();
            for (Quest q : this.active) {
                ids.add(q.id);
            }
            this.active.clear();
            for (String id : ids) {
                Quest q = this.pool.get(id);
                if (q == null) continue;
                q.used = this.data.getInt("used." + id, 0);
                this.active.add(q);
            }
            if (this.active.isEmpty()) {
                this.rollBoard(false);
            }
            sender.sendMessage(String.valueOf(ChatColor.GREEN) + "MAVOQuests reloaded (pool " + this.pool.size() + ", board " + this.active.size() + ").");
            return true;
        }
        if (args.length > 0 && args[0].equalsIgnoreCase("reroll")) {
            if (!sender.hasPermission("mavoquests.admin")) {
                sender.sendMessage(String.valueOf(ChatColor.RED) + "No permission.");
                return true;
            }
            this.rollBoard(true);
            return true;
        }
        if (args.length >= 2 && (args[0].equalsIgnoreCase("complete") || args[0].equalsIgnoreCase("turnin"))) {
            if (!(sender instanceof Player)) {
                sender.sendMessage("Players only.");
                return true;
            }
            Quest q = this.findActive(args[1]);
            if (q == null) {
                sender.sendMessage(String.valueOf(ChatColor.RED) + "Not on the current board.");
                return true;
            }
            this.complete((Player)sender, q);
            return true;
        }
        if (args.length > 0 && args[0].equalsIgnoreCase("list")) {
            long daysLeft = (long)this.refreshDays - (this.currentDay() - this.cycleStartDay);
            sender.sendMessage(String.valueOf(ChatColor.DARK_RED) + String.valueOf(ChatColor.BOLD) + "Quests " + String.valueOf(ChatColor.GRAY) + "(reroll in " + Math.max(0L, daysLeft) + "d)");
            for (Quest q : this.active) {
                boolean out = q.stock > 0 && q.used >= q.stock;
                String stock = q.stock > 0 ? " [" + (q.stock - q.used) + "/" + q.stock + "]" : "";
                sender.sendMessage(q.display + String.valueOf(ChatColor.GRAY) + " " + q.amount + " " + this.matName(q.wanted) + "\u2192" + String.valueOf(ChatColor.YELLOW) + this.fmt(q.rewardCoins) + "?" + String.valueOf(ChatColor.GRAY) + stock + (String)(out ? String.valueOf(ChatColor.RED) + " OUT" : ""));
            }
            return true;
        }
        if (sender instanceof Player) {
            this.openGui((Player)sender);
            return true;
        }
        return this.onCommand(sender, command, label, new String[]{"list"});
    }

    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            ArrayList<String> out = new ArrayList<String>();
            for (String s : Arrays.asList("complete", "list", "reroll", "reload")) {
                if (!s.startsWith(args[0].toLowerCase(Locale.ROOT))) continue;
                out.add(s);
            }
            return out;
        }
        if (args.length == 2 && (args[0].equalsIgnoreCase("complete") || args[0].equalsIgnoreCase("turnin"))) {
            ArrayList<String> out = new ArrayList<String>();
            for (Quest q : this.active) {
                if (!q.id.startsWith(args[1].toLowerCase(Locale.ROOT))) continue;
                out.add(q.id);
            }
            return out;
        }
        return new ArrayList<String>();
    }

    static final class Quest {
        String id;
        String display;
        Material wanted;
        int amount;
        int rewardCoins;
        List<String> rewardCommands = new ArrayList<String>();
        int stock;
        int used;

        Quest() {
        }
    }

    final class BoardHolder
    implements InventoryHolder {
        final Map<Integer, Quest> slots = new HashMap<Integer, Quest>();
        Inventory inv;

        BoardHolder(Quests this$0) {
        }

        public Inventory getInventory() {
            return this.inv;
        }
    }
}

