package mavo.homes;

import com.cjburkey.claimchunk.ClaimChunk;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.Tag;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public final class Homes extends org.bukkit.plugin.java.JavaPlugin implements Listener {

    private static final String PREFIX = "\u00A74[\u00A7cMAVO\u00A79Homes\u00A74]\u00A7r ";

    private static final class Home {
        String name;          // display name (case preserved)
        String world;
        double x, y, z;
        float yaw, pitch;
        int cx, cz;           // chunk coords the home is bound to

        String chunkKey() { return world + ";" + cx + ";" + cz; }

        Location loc() {
            World w = Bukkit.getWorld(world);
            if (w == null) return null;
            return new Location(w, x, y, z, yaw, pitch);
        }
    }

    // player -> (lowercase home name -> Home)
    private final Map<UUID, LinkedHashMap<String, Home>> homes = new HashMap<>();
    private final Map<UUID, BukkitTask> pendingTp = new HashMap<>();
    private final Set<UUID> hintedUnclaimed = new HashSet<>();

    private int maxHomes;
    private int warmupSeconds;
    private File dataFile;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        maxHomes = Math.max(1, getConfig().getInt("max-homes", 5));
        warmupSeconds = Math.max(0, getConfig().getInt("warmup-seconds", 3));
        dataFile = new File(getDataFolder(), "homes.yml");
        loadData();
        Bukkit.getPluginManager().registerEvents(this, this);
        getLogger().info("MAVOHomes enabled - beds mean something again.");
    }

    @Override
    public void onDisable() {
        saveData();
    }

    /* ------------------------------------------------- data */

    private void loadData() {
        homes.clear();
        if (!dataFile.exists()) return;
        YamlConfiguration yml = YamlConfiguration.loadConfiguration(dataFile);
        ConfigurationSection players = yml.getConfigurationSection("players");
        if (players == null) return;
        for (String uuidStr : players.getKeys(false)) {
            UUID id;
            try { id = UUID.fromString(uuidStr); } catch (IllegalArgumentException ex) { continue; }
            ConfigurationSection ps = players.getConfigurationSection(uuidStr);
            if (ps == null) continue;
            LinkedHashMap<String, Home> map = new LinkedHashMap<>();
            for (String key : ps.getKeys(false)) {
                ConfigurationSection hs = ps.getConfigurationSection(key);
                if (hs == null) continue;
                Home h = new Home();
                h.name = hs.getString("name", key);
                h.world = hs.getString("world", "world");
                h.x = hs.getDouble("x");
                h.y = hs.getDouble("y");
                h.z = hs.getDouble("z");
                h.yaw = (float) hs.getDouble("yaw");
                h.pitch = (float) hs.getDouble("pitch");
                h.cx = hs.getInt("cx");
                h.cz = hs.getInt("cz");
                map.put(h.name.toLowerCase(Locale.ROOT), h);
            }
            if (!map.isEmpty()) homes.put(id, map);
        }
    }

    private void saveData() {
        YamlConfiguration yml = new YamlConfiguration();
        for (Map.Entry<UUID, LinkedHashMap<String, Home>> e : homes.entrySet()) {
            int i = 0;
            for (Home h : e.getValue().values()) {
                String base = "players." + e.getKey() + ".h" + (i++);
                yml.set(base + ".name", h.name);
                yml.set(base + ".world", h.world);
                yml.set(base + ".x", h.x);
                yml.set(base + ".y", h.y);
                yml.set(base + ".z", h.z);
                yml.set(base + ".yaw", h.yaw);
                yml.set(base + ".pitch", h.pitch);
                yml.set(base + ".cx", h.cx);
                yml.set(base + ".cz", h.cz);
            }
        }
        try { yml.save(dataFile); } catch (Exception ex) {
            getLogger().warning("Could not save homes.yml: " + ex.getMessage());
        }
    }

    /* ------------------------------------------------- helpers */

    private LinkedHashMap<String, Home> mapOf(UUID id) {
        return homes.computeIfAbsent(id, k -> new LinkedHashMap<>());
    }

    private boolean ownsChunk(Player p, World w, int cx, int cz) {
        try {
            return ClaimChunk.getInstance().getChunkHandler().isOwner(w, cx, cz, p.getUniqueId());
        } catch (Throwable t) {
            return false;
        }
    }

    private Home homeForChunk(UUID id, String chunkKey) {
        LinkedHashMap<String, Home> map = homes.get(id);
        if (map == null) return null;
        for (Home h : map.values()) if (h.chunkKey().equals(chunkKey)) return h;
        return null;
    }

    private String freeName(LinkedHashMap<String, Home> map) {
        if (!map.containsKey("home")) return "home";
        for (int i = 2; ; i++) {
            String n = "home" + i;
            if (!map.containsKey(n)) return n;
        }
    }

    /* ------------------------------------------------- bed listener */

    @EventHandler(ignoreCancelled = true)
    public void onBedClick(PlayerInteractEvent e) {
        if (e.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        if (e.getHand() != EquipmentSlot.HAND) return;
        Block b = e.getClickedBlock();
        if (b == null || !Tag.BEDS.isTagged(b.getType())) return;

        Player p = e.getPlayer();
        World w = b.getWorld();
        int cx = b.getX() >> 4;
        int cz = b.getZ() >> 4;

        boolean owner = ownsChunk(p, w, cx, cz);
        if (!owner && !p.hasPermission("mavohomes.anywhere")) {
            // Unclaimed chunk: gentle hint, once per session. Claimed-by-other: ClaimChunk protection already blocks interaction.
            if (ClaimChunkFreeCheck(w, cx, cz) && hintedUnclaimed.add(p.getUniqueId())) {
                p.sendMessage(PREFIX + "\u00A77This bed sets your respawn, but to bind a \u00A7c/home\u00A77 here you must \u00A79/chunk claim\u00A77 this chunk first.");
            }
            return;
        }

        UUID id = p.getUniqueId();
        LinkedHashMap<String, Home> map = mapOf(id);
        String chunkKey = w.getName() + ";" + cx + ";" + cz;
        Home existing = homeForChunk(id, chunkKey);

        Location standing = p.getLocation();
        if (existing != null) {
            // only treat as a "move" if the player relocated meaningfully (>2 blocks) -
            // repeated clicks on the same bed while waiting to sleep must not spam chat
            double dx = existing.x - standing.getX(), dy = existing.y - standing.getY(), dz = existing.z - standing.getZ();
            boolean moved = (dx * dx + dy * dy + dz * dz) > 4.0;
            if (moved) {
                existing.x = standing.getX(); existing.y = standing.getY(); existing.z = standing.getZ();
                existing.yaw = standing.getYaw(); existing.pitch = standing.getPitch();
                existing.world = w.getName();
                saveData();
                p.sendMessage(PREFIX + "\u00A77Home \u00A7c" + existing.name + "\u00A77 moved to this bed. \u00A79/home " + existing.name);
            }
            return;
        }

        if (map.size() >= maxHomes) {
            p.sendMessage(PREFIX + "\u00A7cYou already have " + map.size() + "/" + maxHomes + " homes. \u00A77Delete one with \u00A79/delhome <name>\u00A77 first.");
            return;
        }

        Home h = new Home();
        h.name = freeName(map);
        h.world = w.getName();
        h.x = standing.getX(); h.y = standing.getY(); h.z = standing.getZ();
        h.yaw = standing.getYaw(); h.pitch = standing.getPitch();
        h.cx = cx; h.cz = cz;
        map.put(h.name.toLowerCase(Locale.ROOT), h);
        saveData();
        p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_CHIME, 1f, 1.4f);
        p.sendMessage(PREFIX + "\u00A79Home bound to this chunk! \u00A77Teleport back with \u00A7c/home " + h.name);
        p.sendMessage(PREFIX + "\u00A77Rename it: \u00A79/home rename " + h.name + " <newname> \u00A77(" + map.size() + "/" + maxHomes + " homes)");
    }

    private boolean ClaimChunkFreeCheck(World w, int cx, int cz) {
        try {
            return !ClaimChunk.getInstance().getChunkHandler().isClaimed(w, cx, cz);
        } catch (Throwable t) {
            return false;
        }
    }

    /* ------------------------------------------------- commands */

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage("Players only.");
            return true;
        }
        String name = cmd.getName().toLowerCase(Locale.ROOT);
        switch (name) {
            case "sethome" -> {
                if (p.hasPermission("mavohomes.anywhere") && args.length > 0) {
                    return adminSetHome(p, args[0]);
                }
                p.sendMessage(PREFIX + "\u00A7cHomes aren't set with a command here.");
                p.sendMessage(PREFIX + "\u00A77Place a \u00A79bed\u00A77 in a chunk \u00A7cyou own\u00A77 and \u00A79right-click it\u00A77 - that binds your home.");
                return true;
            }
            case "delhome" -> {
                if (args.length != 1) {
                    p.sendMessage(PREFIX + "\u00A77Usage: \u00A79/delhome <name>");
                    return true;
                }
                return delHome(p, args[0]);
            }
            case "home" -> {
                if (args.length == 0) return homeDefault(p);
                switch (args[0].toLowerCase(Locale.ROOT)) {
                    case "list" -> { return listHomes(p); }
                    case "rename" -> {
                        if (args.length != 3) {
                            p.sendMessage(PREFIX + "\u00A77Usage: \u00A79/home rename <old> <new>");
                            return true;
                        }
                        return renameHome(p, args[1], args[2]);
                    }
                    case "del" -> {
                        if (args.length != 2) {
                            p.sendMessage(PREFIX + "\u00A77Usage: \u00A79/home del <name>");
                            return true;
                        }
                        return delHome(p, args[1]);
                    }
                    default -> { return teleportHome(p, args[0]); }
                }
            }
        }
        return true;
    }

    private boolean adminSetHome(Player p, String rawName) {
        String cleaned = cleanName(rawName);
        if (cleaned == null) {
            p.sendMessage(PREFIX + "\u00A7cName must be 1-24 letters/numbers/_/-.");
            return true;
        }
        LinkedHashMap<String, Home> map = mapOf(p.getUniqueId());
        Home h = map.get(cleaned.toLowerCase(Locale.ROOT));
        if (h == null) {
            h = new Home();
            h.name = cleaned;
            map.put(cleaned.toLowerCase(Locale.ROOT), h);
        }
        Location l = p.getLocation();
        h.world = l.getWorld().getName();
        h.x = l.getX(); h.y = l.getY(); h.z = l.getZ();
        h.yaw = l.getYaw(); h.pitch = l.getPitch();
        h.cx = l.getBlockX() >> 4; h.cz = l.getBlockZ() >> 4;
        saveData();
        p.sendMessage(PREFIX + "\u00A79(admin) Home \u00A7c" + h.name + "\u00A79 set here.");
        return true;
    }

    private boolean homeDefault(Player p) {
        LinkedHashMap<String, Home> map = homes.get(p.getUniqueId());
        if (map == null || map.isEmpty()) {
            p.sendMessage(PREFIX + "\u00A77No homes yet. \u00A79Right-click a bed\u00A77 in a chunk \u00A7cyou own\u00A77 to bind one.");
            return true;
        }
        if (map.size() == 1) {
            return teleportHome(p, map.values().iterator().next().name);
        }
        return listHomes(p);
    }

    private boolean listHomes(Player p) {
        LinkedHashMap<String, Home> map = homes.get(p.getUniqueId());
        if (map == null || map.isEmpty()) {
            p.sendMessage(PREFIX + "\u00A77No homes yet. \u00A79Right-click a bed\u00A77 in a chunk \u00A7cyou own\u00A77 to bind one.");
            return true;
        }
        p.sendMessage(PREFIX + "\u00A79Your homes \u00A77(" + map.size() + "/" + maxHomes + "):");
        for (Home h : map.values()) {
            boolean owned = false;
            World w = Bukkit.getWorld(h.world);
            if (w != null) owned = ownsChunk(p, w, h.cx, h.cz);
            String status = owned ? "\u00A79\u2714" : "\u00A7c\u2718 (chunk no longer yours)";
            p.sendMessage("  \u00A7c" + h.name + " \u00A77- " + (int) h.x + ", " + (int) h.y + ", " + (int) h.z + " " + status);
        }
        p.sendMessage(PREFIX + "\u00A77Teleport: \u00A79/home <name>");
        return true;
    }

    private boolean renameHome(Player p, String oldName, String newName) {
        LinkedHashMap<String, Home> map = homes.get(p.getUniqueId());
        Home h = map == null ? null : map.get(oldName.toLowerCase(Locale.ROOT));
        if (h == null) {
            p.sendMessage(PREFIX + "\u00A7cNo home called '" + oldName + "'. \u00A77See \u00A79/home list");
            return true;
        }
        String cleaned = cleanName(newName);
        if (cleaned == null) {
            p.sendMessage(PREFIX + "\u00A7cName must be 1-24 letters/numbers/_/-.");
            return true;
        }
        if (map.containsKey(cleaned.toLowerCase(Locale.ROOT))) {
            p.sendMessage(PREFIX + "\u00A7cYou already have a home called '" + cleaned + "'.");
            return true;
        }
        map.remove(h.name.toLowerCase(Locale.ROOT));
        h.name = cleaned;
        map.put(cleaned.toLowerCase(Locale.ROOT), h);
        saveData();
        p.sendMessage(PREFIX + "\u00A79Renamed! \u00A77Teleport with \u00A7c/home " + cleaned);
        return true;
    }

    private boolean delHome(Player p, String name) {
        LinkedHashMap<String, Home> map = homes.get(p.getUniqueId());
        Home h = map == null ? null : map.remove(name.toLowerCase(Locale.ROOT));
        if (h == null) {
            p.sendMessage(PREFIX + "\u00A7cNo home called '" + name + "'. \u00A77See \u00A79/home list");
            return true;
        }
        saveData();
        p.sendMessage(PREFIX + "\u00A77Home \u00A7c" + h.name + "\u00A77 deleted.");
        return true;
    }

    private boolean monstersNear(Player p) {
        if (p.getGameMode() != org.bukkit.GameMode.SURVIVAL) return false;
        int r = Math.max(1, getConfig().getInt("monster-radius", 12));
        for (org.bukkit.entity.Entity en : p.getNearbyEntities(r, Math.max(6, r / 2.0), r))
            if (en instanceof org.bukkit.entity.Enemy && !en.isDead()) return true;
        return false;
    }

    private boolean teleportHome(Player p, String name) {
        LinkedHashMap<String, Home> map = homes.get(p.getUniqueId());
        Home h = map == null ? null : map.get(name.toLowerCase(Locale.ROOT));
        if (h == null) {
            p.sendMessage(PREFIX + "\u00A7cNo home called '" + name + "'. \u00A77See \u00A79/home list");
            return true;
        }
        Location loc = h.loc();
        if (loc == null) {
            p.sendMessage(PREFIX + "\u00A7cThat world isn't loaded.");
            return true;
        }
        if (!p.hasPermission("mavohomes.anywhere") && !ownsChunk(p, loc.getWorld(), h.cx, h.cz)) {
            p.sendMessage(PREFIX + "\u00A7cYou no longer own the chunk of home '" + h.name + "'.");
            p.sendMessage(PREFIX + "\u00A77Re-claim it to use the home again, or \u00A79/delhome " + h.name);
            return true;
        }

        BukkitTask old = pendingTp.remove(p.getUniqueId());
        if (old != null) old.cancel();

        if (monstersNear(p)) {
            p.sendMessage(PREFIX + "\u00A7c\u2694 Monsters nearby - can't teleport home! No escaping a fight.");
            return true;
        }

        if (warmupSeconds <= 0) {
            doTeleport(p, h, loc);
            return true;
        }

        p.sendMessage(PREFIX + "\u00A77Teleporting to \u00A7c" + h.name + "\u00A77 in \u00A79" + warmupSeconds + "s\u00A77... don't move!");
        Location start = p.getLocation().clone();
        BukkitTask task = Bukkit.getScheduler().runTaskLater(this, () -> {
            pendingTp.remove(p.getUniqueId());
            if (!p.isOnline()) return;
            if (p.getLocation().distanceSquared(start) > 0.6) {
                p.sendMessage(PREFIX + "\u00A7cTeleport cancelled - you moved.");
                return;
            }
            if (monstersNear(p)) {
                p.sendMessage(PREFIX + "\u00A7c\u2694 Monsters nearby - teleport cancelled! No escaping a fight.");
                return;
            }
            doTeleport(p, h, loc);
        }, warmupSeconds * 20L);
        pendingTp.put(p.getUniqueId(), task);
        return true;
    }

    private void doTeleport(Player p, Home h, Location loc) {
        p.teleportAsync(loc).thenAccept(ok -> {
            if (ok) {
                p.playSound(loc, Sound.ENTITY_ENDERMAN_TELEPORT, 1f, 1.2f);
                p.sendMessage(PREFIX + "\u00A79Welcome home! \u00A77(\u00A7c" + h.name + "\u00A77)");
            }
        });
    }

    private String cleanName(String raw) {
        if (raw == null) return null;
        String s = raw.trim();
        if (s.isEmpty() || s.length() > 24) return null;
        if (!s.matches("[A-Za-z0-9_-]+")) return null;
        return s;
    }

    /* ------------------------------------------------- tab complete */

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        if (!(sender instanceof Player p)) return List.of();
        LinkedHashMap<String, Home> map = homes.get(p.getUniqueId());
        List<String> names = new ArrayList<>();
        if (map != null) for (Home h : map.values()) names.add(h.name);

        String cName = cmd.getName().toLowerCase(Locale.ROOT);
        if (cName.equals("delhome")) {
            return args.length == 1 ? filter(names, args[0]) : List.of();
        }
        if (cName.equals("home")) {
            if (args.length == 1) {
                List<String> opts = new ArrayList<>(names);
                opts.add("list");
                opts.add("rename");
                opts.add("del");
                return filter(opts, args[0]);
            }
            if (args.length == 2 && (args[0].equalsIgnoreCase("rename") || args[0].equalsIgnoreCase("del"))) {
                return filter(names, args[1]);
            }
        }
        return List.of();
    }

    private List<String> filter(List<String> opts, String prefix) {
        String low = prefix.toLowerCase(Locale.ROOT);
        List<String> out = new ArrayList<>();
        for (String o : opts) if (o.toLowerCase(Locale.ROOT).startsWith(low)) out.add(o);
        return out;
    }
}
