package mavo.pets;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Ageable;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Mob;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;

public final class Pets extends JavaPlugin implements Listener {

    private record PetDef(String id, String name, EntityType type, Material icon, int price) {}

    private final List<PetDef> defs = List.of(
            new PetDef("cat", "Cat", EntityType.CAT, Material.COD, 500),
            new PetDef("wolf", "Wolf Pup", EntityType.WOLF, Material.BONE, 500),
            new PetDef("chicken", "Chicken", EntityType.CHICKEN, Material.EGG, 400),
            new PetDef("fox", "Fox", EntityType.FOX, Material.SWEET_BERRIES, 800),
            new PetDef("parrot", "Parrot", EntityType.PARROT, Material.FEATHER, 1000),
            new PetDef("axolotl", "Axolotl", EntityType.AXOLOTL, Material.TROPICAL_FISH_BUCKET, 1200),
            new PetDef("bee", "Bee", EntityType.BEE, Material.HONEYCOMB, 1500),
            new PetDef("frog", "Frog", EntityType.FROG, Material.LILY_PAD, 1500),
            new PetDef("panda", "Panda", EntityType.PANDA, Material.BAMBOO, 2500),
            new PetDef("allay", "Allay", EntityType.ALLAY, Material.AMETHYST_SHARD, 4000));

    private Economy econ;
    private NamespacedKey petKey;
    private File dataFile;
    private YamlConfiguration data;
    private boolean dirty = false;
    private final Map<UUID, Entity> activePets = new HashMap<>();

    private static final class Holder implements InventoryHolder {
        @Override public Inventory getInventory() { return null; }
    }

    @Override
    public void onEnable() {
        petKey = new NamespacedKey(this, "mavopet");
        dataFile = new File(getDataFolder(), "data.yml");
        if (!dataFile.getParentFile().exists()) dataFile.getParentFile().mkdirs();
        data = YamlConfiguration.loadConfiguration(dataFile);
        RegisteredServiceProvider<Economy> rsp = getServer().getServicesManager().getRegistration(Economy.class);
        if (rsp != null) econ = rsp.getProvider();
        getServer().getPluginManager().registerEvents(this, this);
        Bukkit.getScheduler().runTaskTimer(this, () -> {
            if (dirty) { try { data.save(dataFile); } catch (Exception ignored) {} dirty = false; }
        }, 200L, 200L);
        // follow task: keep pets near owners
        Bukkit.getScheduler().runTaskTimer(this, () -> {
            for (Map.Entry<UUID, Entity> en : new ArrayList<>(activePets.entrySet())) {
                Player owner = Bukkit.getPlayer(en.getKey());
                Entity pet = en.getValue();
                if (owner == null || !owner.isOnline() || pet.isDead()) { pet.remove(); activePets.remove(en.getKey()); continue; }
                if (!pet.getWorld().equals(owner.getWorld()) || pet.getLocation().distanceSquared(owner.getLocation()) > 144) {
                    pet.teleport(owner.getLocation());
                } else if (pet instanceof Mob mob && pet.getLocation().distanceSquared(owner.getLocation()) > 9) {
                    mob.getPathfinder().moveTo(owner.getLocation(), 1.2);
                }
            }
        }, 20L, 20L);
        getLogger().info("MAVOPets enabled - who's a good boy?");
    }

    @Override
    public void onDisable() {
        for (Entity e : activePets.values()) e.remove();
        activePets.clear();
        try { data.save(dataFile); } catch (Exception ignored) {}
    }

    private boolean owns(Player p, String id) { return data.getStringList("owned." + p.getUniqueId()).contains(id); }

    private void openMenu(Player p) {
        Inventory inv = Bukkit.createInventory(new Holder(), 27, ChatColor.RED + "" + ChatColor.BOLD + "MAVO" + ChatColor.BLUE + "" + ChatColor.BOLD + "Pets");
        int slot = 0;
        String active = activePets.containsKey(p.getUniqueId())
                ? activePets.get(p.getUniqueId()).getPersistentDataContainer().get(petKey, PersistentDataType.STRING) : null;
        for (PetDef d : defs) {
            ItemStack it = new ItemStack(d.icon());
            ItemMeta m = it.getItemMeta();
            boolean owned = owns(p, d.id());
            boolean isActive = d.id().equals(active);
            m.setDisplayName((owned ? ChatColor.GREEN : ChatColor.RED) + "" + ChatColor.BOLD + d.name());
            List<String> lore = new ArrayList<>();
            if (isActive) { lore.add(ChatColor.AQUA + "Following you now"); lore.add(ChatColor.GRAY + "Click to dismiss"); }
            else if (owned) lore.add(ChatColor.GRAY + "Click to summon");
            else { lore.add(ChatColor.GOLD + "Price: " + ChatColor.YELLOW + "\u26C3" + d.price()); lore.add(ChatColor.GRAY + "Click to buy"); }
            m.setLore(lore);
            if (isActive) { m.addEnchant(org.bukkit.enchantments.Enchantment.UNBREAKING, 1, true); m.addItemFlags(org.bukkit.inventory.ItemFlag.HIDE_ENCHANTS); }
            m.getPersistentDataContainer().set(petKey, PersistentDataType.STRING, d.id());
            it.setItemMeta(m);
            inv.setItem(slot++, it);
        }
        ItemStack info = new ItemStack(Material.BOOK);
        ItemMeta im = info.getItemMeta();
        im.setDisplayName(ChatColor.GOLD + "Cosmetic pets");
        im.setLore(List.of(ChatColor.GRAY + "Pets follow you around. They can't", ChatColor.GRAY + "be hurt, and they never despawn on you.", ChatColor.GRAY + "One active pet at a time."));
        info.setItemMeta(im);
        inv.setItem(26, info);
        p.openInventory(inv);
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getInventory().getHolder() instanceof Holder)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        ItemStack it = e.getCurrentItem();
        if (it == null || !it.hasItemMeta()) return;
        String id = it.getItemMeta().getPersistentDataContainer().get(petKey, PersistentDataType.STRING);
        if (id == null) return;
        PetDef d = defs.stream().filter(x -> x.id().equals(id)).findFirst().orElse(null);
        if (d == null) return;

        Entity current = activePets.get(p.getUniqueId());
        String activeId = current != null ? current.getPersistentDataContainer().get(petKey, PersistentDataType.STRING) : null;

        if (d.id().equals(activeId)) { // dismiss
            current.remove();
            activePets.remove(p.getUniqueId());
            p.sendMessage(ChatColor.GRAY + "Your " + d.name() + " went home.");
            openMenu(p);
            return;
        }
        if (!owns(p, d.id())) { // buy
            if (econ == null || econ.getBalance(p) < d.price()) {
                p.sendMessage(ChatColor.RED + "You need \u26C3" + d.price() + " for a " + d.name() + ".");
                p.playSound(p.getLocation(), Sound.ENTITY_VILLAGER_NO, 1f, 1f);
                return;
            }
            econ.withdrawPlayer(p, d.price());
            List<String> owned = new ArrayList<>(data.getStringList("owned." + p.getUniqueId()));
            owned.add(d.id());
            data.set("owned." + p.getUniqueId(), owned);
            dirty = true;
            p.sendMessage(ChatColor.GREEN + "You bought a " + ChatColor.BOLD + d.name() + ChatColor.GREEN + "! Click it again to summon.");
            p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.8f, 1.4f);
            openMenu(p);
            return;
        }
        // summon (replace current)
        if (current != null) { current.remove(); activePets.remove(p.getUniqueId()); }
        summon(p, d);
        openMenu(p);
    }

    private void summon(Player p, PetDef d) {
        Location loc = p.getLocation();
        Entity ent = p.getWorld().spawnEntity(loc, d.type());
        if (ent instanceof Ageable a) { a.setBaby(); a.setAgeLock(true); }
        if (ent instanceof LivingEntity le) {
            le.setInvulnerable(true);
            le.setPersistent(true);
            le.setRemoveWhenFarAway(false);
            le.setCustomName(ChatColor.RED + p.getName() + "'s " + ChatColor.BLUE + d.name());
            le.setCustomNameVisible(true);
        }
        ent.getPersistentDataContainer().set(petKey, PersistentDataType.STRING, d.id());
        activePets.put(p.getUniqueId(), ent);
        p.sendMessage(ChatColor.GREEN + "Your " + d.name() + " is following you!");
        p.playSound(loc, Sound.ENTITY_CAT_PURREOW, 1f, 1.2f);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        Entity pet = activePets.remove(e.getPlayer().getUniqueId());
        if (pet != null) pet.remove();
    }

    @EventHandler
    public void onDamage(EntityDamageEvent e) {
        if (e.getEntity().getPersistentDataContainer().has(petKey, PersistentDataType.STRING)) e.setCancelled(true);
    }

    @EventHandler
    public void onInteract(PlayerInteractEntityEvent e) {
        if (e.getRightClicked().getPersistentDataContainer().has(petKey, PersistentDataType.STRING)) e.setCancelled(true);
    }

    @Override
    public boolean onCommand(CommandSender s, Command c, String l, String[] a) {
        if (!(s instanceof Player p)) { s.sendMessage("Players only."); return true; }
        openMenu(p);
        return true;
    }
}
