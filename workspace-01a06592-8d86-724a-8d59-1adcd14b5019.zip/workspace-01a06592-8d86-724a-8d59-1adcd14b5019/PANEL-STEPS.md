# Your panel paths (server OFFLINE — good)

World root shown:
```
/home/container/world/
  data/
  datapacks/
  dimensions/
  players/
  level.dat_backup   ← 491 B  (this IS your level data style)
  level.dat_old      ← 489 B
  session.lock
```

There is **no `level.dat` right now** — only `_backup` and `_old`.  
On start, Paper expects **`/home/container/world/level.dat`**.

Those 491-byte files match what we already patched (Time was 2614913).  
**Safe to use the patched file as your real `level.dat`.**

---

## STEP 1 — Install Day 1 level.dat (do this now)

1. Download from this workspace: **`level-dat-DAY1/level.dat`** (505 bytes, Time=0, DayTime=1000).
2. In the panel, open folder: **`/home/container/world/`**
3. **Upload** that file and name it exactly:
   ```
   level.dat
   ```
4. Optional but tidy — also replace the backups so nothing reverts:
   - Upload the same file again as `level.dat_backup` (overwrite), **or**
   - Delete `level.dat_backup` / `level.dat_old` after `level.dat` is in place  
   (keep one copy of the *old* file on your PC first if you want a rollback).

5. Leave `session.lock` alone (or delete it if the panel allows — fine while stopped).

**Do not** put level.dat inside `world/data/minecraft/` — wrong folder.

---

## STEP 2 — Progress wipe (still offline)

### 2a — Your player files
Open **`/home/container/world/players/`** (your panel uses `players`, not always `playerdata`).

Delete anything named with your UUID:
```
53322438-a7a2-4eb2-bb2b-1c648a43dccf
```
(files like `….dat`, `….dat_old`, and under advancements/stats if those folders exist here or under `world/data/`).

Also check classic paths if they exist:
```
/home/container/world/playerdata/53322438-…
/home/container/world/stats/53322438-…
/home/container/world/advancements/53322438-…
```

### 2b — Essentials
```
/home/container/plugins/Essentials/userdata/53322438-a7a2-4eb2-bb2b-1c648a43dccf.yml
```
Delete that one file.

### 2c — MAVO data.yml (progress)
Delete each if present under `/home/container/plugins/`:
```
MAVOProfessions/data.yml
MAVOAchievements/data.yml
MAVOQuests/data.yml
MAVOCurator/data.yml
MAVOStreaks/data.yml
MAVOPets/data.yml
MAVOLuckyCoins/data.yml
MAVOCasino/data.yml
MAVOHomes/data.yml
MAVODeathChest/data.yml
MAVOVault/data.yml
MAVOPortalRoom/data.yml
MAVOChunkPrices/data.yml
MAVOMobFarm/data.yml
MAVOTavern/data.yml
MAVOCommunityGoals/data.yml
MAVOGuide/data.yml
MAVOHud/data.yml
```

### 2d — Extra configs (fresh defaults)
You already wiped professions/achievements/goals/casino/tavern configs.  
Also delete if they exist:
```
plugins/MAVOMobFarm/config.yml
plugins/MAVOHud/config.yml
plugins/MAVOGuide/config.yml
```

### 2e — Claims (optional full fresh)
```
plugins/ClaimChunk/data/…   (claimed chunks file/folder)
```

### 2f — Jars check
Still only one of each new jar; no old version left beside it.

---

## STEP 3 — START server (green Start)

Watch console for MAVO* plugins enabling without errors.

---

## STEP 4 — Console (immediately)

```
lp user MAVOmusicYT clear
lp user MAVOmusicYT parent set default
vaultroom wipeplayer MAVOmusicYT
```

---

## STEP 5 — In-game

1. TAB: add `%mavohud_day%` etc. → should show **Day 1**
2. `/tavern build20`
3. `/mobfarm setcenter` then `/mobfarm build`
4. `/guide`
5. `/prof` — grind should feel slow
6. `deop MAVOmusicYT` when setup done

---

## If Day is still not 1 after start

Re-download `level.dat` from the live server after one boot (Paper may rewrite it larger).  
Then either:
- re-upload our patched file again while stopped, or
- edit the new larger file: set `Data.Time` = 0 only.
