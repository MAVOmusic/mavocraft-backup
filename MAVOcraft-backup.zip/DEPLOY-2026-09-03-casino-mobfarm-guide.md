# DEPLOY 2026-09-03 — Casino 1.2.3 + MobFarm 2.5.0 + Guide v13

## Files
- plugins/MAVOCasino-1.2.3.jar (replaces 1.2.x)
- plugins/MAVOMobFarm-2.5.0.jar (replaces 2.4.0)
- plugins/MAVOGuide-2.6.0.jar (same file name, content v13)
- Configs are bundled inside the jars; new key `result-seconds: 5` (casino).
- MobFarm config.yml changed heavily (per-mob styles): DELETE old
  plugins/MAVOMobFarm/config.yml so new defaults generate, or run
  `/mobfarm reload` then `/mobfarm rebuild` to lay the new bays at -15000.

## Casino 1.2.3
Dice / Blackjack / Hi-Lo / RPS now show a result screen with the payout
(GOLD_BLOCK win / COAL_BLOCK loss) and a CLOSE pane (slot 26). Auto-closes
to the main menu after `result-seconds` (default 5, min 1). Payout happens
exactly once (h.paid guard). Other games unchanged.

## MobFarm 2.5.0
Full build-system rewrite: every mob gets its own bay (spawn room -> kill
cell -> hopper->chest collection) with per-mob theme and a marked safe
stand / kill pad / loot point. Replaces 2.4.0's copy-paste bays where
hoppers never met the chests. Style aliases keep old configs readable
(pad->crypt, feet->gallery, spider->web, enderman->totem, blaze->forge,
slime->cells, water->aqua, pen->barn, default->crypt).

## Guide v13
Changelog + casino page (all 10 games, 5s result screen) + mob farm page
(unique bays, hopper->chest collection, /mobfarm info). Auto-opens once
per player on next join.
