#!/usr/bin/env python3
"""Patch Minecraft/Paper level.dat so the day counter shows Day 1.

Usage (server STOPPED):
  python3 patch-level-dat-day1.py /path/to/world/level.dat

Creates level.dat.bak next to the file, sets:
  Data.Time    = 0      (full world age → Day 1 in MAVOHud)
  Data.DayTime = 1000   (morning), if present or creatable

Requires: pip install nbtlib
"""
from __future__ import annotations
import sys
import shutil
from pathlib import Path

def main() -> int:
    if len(sys.argv) != 2:
        print(__doc__)
        return 2
    path = Path(sys.argv[1])
    if not path.is_file():
        print(f"Not found: {path}")
        return 1
    try:
        import nbtlib
        from nbtlib import File, Compound, Long, Byte, Int, Float, String, List
    except ImportError:
        print("Install nbtlib first:  pip install nbtlib")
        return 1

    bak = path.with_suffix(path.suffix + ".bak")
    if not bak.exists():
        shutil.copy2(path, bak)
        print(f"Backup: {bak}")
    else:
        print(f"Backup already exists: {bak}")

    nbt = nbtlib.load(path)
    # root may be File with '' or 'Data'
    root = nbt
    if "Data" in root:
        data = root["Data"]
    elif "" in root and "Data" in root[""]:
        data = root[""]["Data"]
    else:
        # gzip compound sometimes
        print("Keys:", list(root.keys()))
        raise SystemExit("Could not find Data compound")

    old = int(data.get("Time", -1))
    data["Time"] = Long(0)
    # Daytime morning if field exists or always set
    data["DayTime"] = Long(1000)
    nbt.save(path)
    print(f"OK: Time {old} → 0, DayTime → 1000")
    print("Start server; %mavohud_day% / Day HUD should show 1.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
