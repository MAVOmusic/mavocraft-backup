# MAVOcraft — full personal progress reset (play fresh)

Goal: wipe ALL progress for **MAVOmusicYT** (and optionally everyone) while keeping SERVER build.

**Order: file deletions WHILE THE SERVER IS STOPPED.**

UUID: `53322438-a7a2-4eb2-bb2b-1c648a43dccf`

## 0. Stop the server

## 1. Day counter → Day 1
Edit `world/level.dat`: set `Data.Time` to `0` (or `1000`). Backup first.
After boot, `%mavohud_day%` should be 1.

## 2. Essentials
```
plugins/Essentials/userdata/53322438-a7a2-4eb2-bb2b-1c648a43dccf.yml
```

## 3. Vanilla player data
```
world/playerdata/53322438-a7a2-4eb2-bb2b-1c648a43dccf.dat
world/playerdata/53322438-a7a2-4eb2-bb2b-1c648a43dccf.dat_old
world/advancements/53322438-a7a2-4eb2-bb2b-1c648a43dccf.json
world/stats/53322438-a7a2-4eb2-bb2b-1c648a43dccf.json
```

## 4. MAVO plugin data (delete whole data.yml when solo-test OK)
```
plugins/MAVOProfessions/data.yml
plugins/MAVOAchievements/data.yml
plugins/MAVOQuests/data.yml
plugins/MAVOCurator/data.yml
plugins/MAVOStreaks/data.yml
plugins/MAVOPets/data.yml
plugins/MAVOLuckyCoins/data.yml
plugins/MAVOCasino/data.yml
plugins/MAVOHomes/data.yml
plugins/MAVODeathChest/data.yml
plugins/MAVOVault/data.yml
plugins/MAVOPortalRoom/data.yml
plugins/MAVOChunkPrices/data.yml
plugins/MAVOMobFarm/data.yml
plugins/MAVOTavern/data.yml
plugins/MAVOCommunityGoals/data.yml
plugins/MAVOGuide/data.yml
plugins/MAVOHud/data.yml
```

## 5. Replace progression configs (required for rebalance)
Delete these so jars drop fresh defaults on start:
```
plugins/MAVOProfessions/config.yml
plugins/MAVOAchievements/config.yml
plugins/MAVOCommunityGoals/config.yml
plugins/MAVOCasino/config.yml
plugins/MAVOTavern/config.yml
plugins/MAVOMobFarm/config.yml   # if any
plugins/MAVOHud/config.yml
```

## 6. Claims / LP
```
plugins/ClaimChunk/data/claimedChunks.json
```
After start:
```
lp user MAVOmusicYT clear
lp user MAVOmusicYT parent set default
/vaultroom wipeplayer MAVOmusicYT
```

## 7. What NOT to touch
- EconomyShopGUI shop YAMLs (unless rebalancing prices separately)
- World builds / portals / vault structure
