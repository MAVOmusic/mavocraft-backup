# MAVOcraft deploy — 2026-09-02 balance + content mega-update

## New / updated jars (copy into `plugins/`, remove older same-name versions)

| Jar | Version | Notes |
|-----|---------|-------|
| MAVOProfessions | **3.14.0** | Much slower XP; iron@10 diamond@25 netherite@50; lower Eff baselines |
| MAVOAchievements | **1.6.0** | Higher thresholds; levels start at 1; mob-kill cats; 5k coins every 5 kill levels |
| MAVOHud | **2.1.0** | Player Level avg + death counter placeholders |
| MAVOCommunityGoals | **1.2.0** | Multi-tier dirt/cobble/treasury (1/5/10/50/100M then double) |
| MAVOCasino | **1.2.0** | +5 games (10 total); random GUI order; 10 coin + 10 lucky attempts |
| MAVOTavern | **1.1.0** | `/tavern build20` 20×20 + 4 beds + innkeeper bar (soulbound 1/day) |
| MAVOMobFarm | **1.0.0** | NEW — `/mobfarm enter|leave|buy|build` |

Also still pending if not live: Vault 1.7.1, PortalRoom 1.1.0.

## 1) Day counter → Day 1 (world age, not time-of-day)

Paper/Bukkit `Day N` = `fullTime/24000 + 1`. Reset on the **live server** (world must be loaded or edit level.dat while stopped).

### Option A — in-game / console (world loaded)
```
# Keep time-of-day, zero the day counter:
execute in minecraft:world run gamerule doDaylightCycle false
# Paper: set full time so day index = 0 → HUD shows Day 1
time set 0
# If your Paper build supports:
# /paper dumplightning  (ignore)
```
Bukkit `world.setFullTime(0)` → Day 1. From console with a small script plugin, or stop server and:

### Option B — stop server, edit `level.dat` (recommended clean)
1. Stop Paper.
2. Backup `world/level.dat`.
3. With NBT editor (or `nbted` / web NBT): set `Data.Time` and `Data.DayTime` appropriately.
   - Set `Time` (full time) to `0` or `1000` → HUD Day 1.
4. Start server.

### Option C — one-liner console if you have Essentials/`eval` (may not exist)
Use a temporary op command block or Skript: `world.setFullTime(0)`.

**After reset:** `/mavohud` placeholders `%mavohud_day%` should show `1`.

## 2) TAB scoreboard (TAB plugin)
See `_Old/src-hud/TAB-SCOREBOARD-SNIPPET.yml`. Example lines:
```
&6&lMAVOcraft
&8---------------
%mavohud_tab_name%
%mavohud_level_line%
&8---------------
%mavohud_coords%
&fDay &e%mavohud_day%  &c☠ %mavohud_deaths%
%mavohud_time%
```
Player Level = average of all profession + achievement levels (min 1).

## 3) MobFarm setup
```
/mobfarm setcenter     # stand ~500 from vault plaza
/mobfarm build         # builds rooms + community chest
/mobfarm enter         # 5000 coins, 10s cancel-on-move, 30 min session
/mobfarm leave         # exit zone; timer keeps running
/mobfarm buy           # extra spawner 10k,20k,40k... resets to community base on end
```
Profession hunter/archer XP inside session = **30%** (`profession-xp-scale`).
Community chest coins fund limitless stack goal (1M→stack6, 2M→7, …).

## 4) Tavern 20×20
```
/tavern build20        # 20×20 inn, 4 beds, innkeeper
# right-click innkeeper → food/drink 1 per player per MC day, soulbound
# beds still noon-lock after paid rest (1.0.1 behaviour)
```

## 5) Progress wipe (after jars + configs)
Follow `RESET-PROGRESS.md` (updated). Extra files:
```
plugins/MAVOMobFarm/data.yml
plugins/MAVOTavern/data.yml   # bar day locks
```
Also wipe configs that embed old progression numbers? **Replace** plugin configs from jar defaults on first run OR copy resource configs:
- professions `config.yml` (new xp-base/tiers)
- achievements `config.yml` (new bases + kill_*)
- goals `config.yml` (tiers lists)
- casino `config.yml` (coin/lucky attempts)

**Important:** delete old `plugins/MAVO*/config.yml` for professions/achievements/goals/casino OR merge manually — jar `saveDefaultConfig` will NOT overwrite existing configs.

## 6) Shop bonus note (goals)
Dirt → Blocks&Building %; Cobble → Resources %; Treasury → all except Blocks/Resources/Spawners.
Flags stored as tier index in goals data — wire ESGUI multipliers manually or via future shop hook (`shop-bonus` keys in goals config).

## 7) Guide / tutorial
Update MAVOGuide book pages if present for: slower grind, mobfarm, tavern bar, casino 10 games, Player Level, day reset.
