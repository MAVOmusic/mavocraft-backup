/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.milkbowl.vault.economy.Economy
 *  org.bukkit.Bukkit
 *  org.bukkit.ChatColor
 *  org.bukkit.Material
 *  org.bukkit.NamespacedKey
 *  org.bukkit.OfflinePlayer
 *  org.bukkit.Registry
 *  org.bukkit.World
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandSender
 *  org.bukkit.command.TabCompleter
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.configuration.file.YamlConfiguration
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.Listener
 *  org.bukkit.event.inventory.InventoryClickEvent
 *  org.bukkit.inventory.Inventory
 *  org.bukkit.inventory.InventoryHolder
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.ItemMeta
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.plugin.RegisteredServiceProvider
 *  org.bukkit.plugin.java.JavaPlugin
 *  org.bukkit.potion.PotionEffect
 *  org.bukkit.potion.PotionEffectType
 *  org.bukkit.scheduler.BukkitRunnable
 */
package mavo.goals;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.OfflinePlayer;
import org.bukkit.Registry;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

public final class CommunityGoals
extends JavaPlugin
implements Listener,
TabCompleter {
    private Economy econ;
    private final List<Goal> goals = new ArrayList<Goal>();
    private File dataFile;
    private YamlConfiguration data;

    public void onEnable() {
        this.saveDefaultConfig();
        this.dataFile = new File(this.getDataFolder(), "data.yml");
        this.data = YamlConfiguration.loadConfiguration((File)this.dataFile);
        RegisteredServiceProvider rsp = this.getServer().getServicesManager().getRegistration(Economy.class);
        if (rsp != null) {
            this.econ = (Economy)rsp.getProvider();
        }
        this.loadGoals();
        this.getServer().getPluginManager().registerEvents((Listener)this, (Plugin)this);
        if (this.getCommand("goal") != null) {
            this.getCommand("goal").setTabCompleter((TabCompleter)this);
        }
        new BukkitRunnable(){

            public void run() {
                CommunityGoals.this.tick();
            }
        }.runTaskTimer((Plugin)this, 100L, 200L);
        this.getLogger().info("MAVOCommunityGoals v1.1 enabled with " + this.goals.size() + " goal(s).");
    }

    public void onDisable() {
        this.saveData();
    }

    private void loadGoals() {
        this.goals.clear();
        ConfigurationSection sec = this.getConfig().getConfigurationSection("goals");
        if (sec == null) {
            return;
        }
        for (String id : sec.getKeys(false)) {
            ConfigurationSection g = sec.getConfigurationSection(id);
            if (g == null) continue;
            Goal goal = new Goal();
            goal.id = id.toLowerCase(Locale.ROOT);
            goal.display = ChatColor.translateAlternateColorCodes((char)'&', (String)g.getString("display", id));
            goal.type = g.getString("type", "ITEM").toUpperCase(Locale.ROOT);
            if (goal.type.equals("ITEM")) {
                goal.material = Material.matchMaterial((String)g.getString("material", "DIRT"));
                if (goal.material == null) {
                    this.getLogger().warning("Goal " + id + ": unknown material, skipped");
                    continue;
                }
            }
            goal.tierIndex = Math.max(0, this.data.getInt("goals." + goal.id + ".tier", 0));
            goal.amplifierPerTier = g.getInt("amplifier-per-tier", 0);
            goal.shopBonus = g.getString("shop-bonus", "");
            goal.shopBonusPctPerTier = g.getInt("shop-bonus-pct-per-tier", 0);
            if (g.isList("tiers")) {
                for (Object o : g.getList("tiers")) {
                    try { goal.tiers.add(Long.parseLong(String.valueOf(o))); } catch (Exception ignored) {}
                }
            }
            if (goal.tiers.isEmpty()) {
                long t0 = g.getLong("target", 1000L);
                goal.tiers.add(t0);
            }
            // unlimited: after last listed tier, double forever
            int ti = Math.min(goal.tierIndex, Math.max(0, goal.tiers.size() - 1));
            if (goal.tierIndex >= goal.tiers.size()) {
                long last = goal.tiers.get(goal.tiers.size() - 1);
                long t = last;
                for (int k = goal.tiers.size(); k <= goal.tierIndex; k++) t = t * 2L;
                goal.target = t;
            } else {
                goal.target = goal.tiers.get(ti);
            }
            goal.amplifier = g.getInt("amplifier", 0) + goal.tierIndex * goal.amplifierPerTier;
            goal.dailyLimit = g.getLong("daily-limit-per-player", 0L);
            String effName = g.getString("effect", "HASTE").toLowerCase(Locale.ROOT);
            goal.effect = (PotionEffectType)Registry.EFFECT.get(NamespacedKey.minecraft((String)effName));
            if (goal.effect == null) {
                this.getLogger().warning("Goal " + id + ": unknown effect '" + effName + "', skipped");
                continue;
            }
            goal.amplifier = Math.max(0, g.getInt("amplifier", 0));
            goal.permanent = g.getBoolean("permanent", false);
            goal.durationDays = g.getLong("duration-days", 500L);
            goal.progress = this.data.getLong("goals." + goal.id + ".progress", 0L);
            goal.completed = this.data.getBoolean("goals." + goal.id + ".completed", false);
            goal.expiresDay = this.data.getLong("goals." + goal.id + ".expires-day", -1L);
            this.goals.add(goal);
        }
    }

    private void saveData() {
        for (Goal g : this.goals) {
            this.data.set("goals." + g.id + ".progress", (Object)g.progress);
            this.data.set("goals." + g.id + ".completed", (Object)g.completed);
            this.data.set("goals." + g.id + ".tier", (Object)g.tierIndex);
            this.data.set("goals." + g.id + ".expires-day", (Object)g.expiresDay);
        }
        try {
            this.data.save(this.dataFile);
        }
        catch (Exception e) {
            this.getLogger().warning("Could not save data.yml: " + e.getMessage());
        }
    }

    private long currentDay() {
        return ((World)Bukkit.getWorlds().get(0)).getFullTime() / 24000L;
    }

    private void tick() {
        long day = this.currentDay();
        boolean changed = false;
        for (Goal g : this.goals) {
            if (!g.completed) continue;
            if (!g.permanent && g.expiresDay >= 0L && day >= g.expiresDay) {
                g.completed = false;
                g.progress = 0L;
                g.expiresDay = -1L;
                changed = true;
                Bukkit.broadcastMessage((String)(String.valueOf(ChatColor.GOLD) + "\u23f3 Community goal " + g.display + String.valueOf(ChatColor.GOLD) + " has expired! Donate again with " + String.valueOf(ChatColor.YELLOW) + "/goal" + String.valueOf(ChatColor.GOLD) + "!"));
                continue;
            }
            for (Player p : Bukkit.getOnlinePlayers()) {
                p.addPotionEffect(new PotionEffect(g.effect, 400, g.amplifier, true, false));
            }
        }
        if (changed) {
            this.saveData();
        }
    }

    private long donatedToday(UUID u, Goal g, long day) {
        String base = "daily." + String.valueOf(u) + "." + g.id;
        long d = this.data.getLong(base + ".day", -1L);
        return d == day ? this.data.getLong(base + ".amount", 0L) : 0L;
    }

    private void addDonatedToday(UUID u, Goal g, long day, long amount) {
        String base = "daily." + String.valueOf(u) + "." + g.id;
        long prev = this.donatedToday(u, g, day);
        this.data.set(base + ".day", (Object)day);
        this.data.set(base + ".amount", (Object)(prev + amount));
    }

    private Goal find(String id) {
        for (Goal g : this.goals) {
            if (!g.id.equalsIgnoreCase(id)) continue;
            return g;
        }
        return null;
    }

    private String bar(Goal g) {
        int i;
        int filled = g.target > 0L ? (int)Math.min(20L, g.progress * 20L / g.target) : 20;
        StringBuilder sb = new StringBuilder(String.valueOf(ChatColor.DARK_GRAY) + "[" + String.valueOf(ChatColor.GREEN));
        for (i = 0; i < filled; ++i) {
            sb.append("|");
        }
        sb.append(ChatColor.GRAY);
        for (i = filled; i < 20; ++i) {
            sb.append("|");
        }
        return sb.append(ChatColor.DARK_GRAY).append("]").toString();
    }

    private String fmt(long n) {
        return String.format(Locale.UK, "%,d", n);
    }

    private String unit(Goal g) {
        return g.type.equals("COINS") ? "coins" : g.material.name().toLowerCase(Locale.ROOT).replace('_', ' ');
    }

    private long countInv(Player p, Material m) {
        long have = 0L;
        for (ItemStack it : p.getInventory().getContents()) {
            if (it == null || it.getType() != m) continue;
            have += (long)it.getAmount();
        }
        return have;
    }

    private void openGui(Player p) {
        int[] nArray;
        Inventory inv;
        GoalsHolder holder = new GoalsHolder(this);
        int rows = 3;
        holder.inv = inv = Bukkit.createInventory((InventoryHolder)holder, (int)(rows * 9), (String)(String.valueOf(ChatColor.DARK_RED) + String.valueOf(ChatColor.BOLD) + "Community Goals"));
        ItemStack fill = this.named(new ItemStack(Material.GRAY_STAINED_GLASS_PANE), " ", null);
        for (int i = 0; i < inv.getSize(); ++i) {
            inv.setItem(i, fill);
        }
        long day = this.currentDay();
        if (this.goals.size() <= 3) {
            int[] nArray2 = new int[3];
            nArray2[0] = 11;
            nArray2[1] = 13;
            nArray = nArray2;
            nArray2[2] = 15;
        } else {
            int[] nArray3 = new int[7];
            nArray3[0] = 10;
            nArray3[1] = 11;
            nArray3[2] = 12;
            nArray3[3] = 13;
            nArray3[4] = 14;
            nArray3[5] = 15;
            nArray = nArray3;
            nArray3[6] = 16;
        }
        int[] slots = nArray;
        for (int i = 0; i < this.goals.size() && i < slots.length; ++i) {
            Goal g = this.goals.get(i);
            Material icon = g.type.equals("COINS") ? Material.GOLD_INGOT : g.material;
            ItemStack it = new ItemStack(icon);
            ArrayList<String> lore = new ArrayList<>();
            String eff = g.effect.getKey().getKey().replace('_', ' ') + " " + (g.amplifier + 1);
            lore.add(String.valueOf(ChatColor.AQUA) + "Reward: " + eff + (String)(g.permanent ? " (permanent)" : " (" + this.fmt(g.durationDays) + " MC days)"));
            lore.add("");
            if (g.completed) {
                lore.add(String.valueOf(ChatColor.GREEN) + "\u2714 COMPLETE!");
                lore.add(g.permanent ? String.valueOf(ChatColor.GREEN) + "Buff active permanently" : String.valueOf(ChatColor.GREEN) + "Active - " + this.fmt(Math.max(0L, g.expiresDay - day)) + " MC days left");
            } else {
                lore.add(this.bar(g));
                lore.add(String.valueOf(ChatColor.GRAY) + this.fmt(g.progress) + " / " + this.fmt(g.target) + " " + this.unit(g));
                if (g.dailyLimit > 0L) {
                    lore.add(String.valueOf(ChatColor.GRAY) + "Your remaining today: " + String.valueOf(ChatColor.YELLOW) + this.fmt(Math.max(0L, g.dailyLimit - this.donatedToday(p.getUniqueId(), g, day))));
                }
                lore.add("");
                if (g.type.equals("COINS")) {
                    lore.add(String.valueOf(ChatColor.YELLOW) + "Left-click: " + String.valueOf(ChatColor.WHITE) + "donate 100 coins");
                    lore.add(String.valueOf(ChatColor.YELLOW) + "Right-click: " + String.valueOf(ChatColor.WHITE) + "donate max (today's limit)");
                } else {
                    lore.add(String.valueOf(ChatColor.YELLOW) + "Left-click: " + String.valueOf(ChatColor.WHITE) + "donate 64 from inventory");
                    lore.add(String.valueOf(ChatColor.YELLOW) + "Right-click: " + String.valueOf(ChatColor.WHITE) + "donate ALL you carry");
                }
            }
            ItemMeta meta = it.getItemMeta();
            meta.setDisplayName(g.display);
            meta.setLore(lore);
            it.setItemMeta(meta);
            inv.setItem(slots[i], it);
            while (holder.slots.size() <= slots[i]) {
                holder.slots.add(null);
            }
            holder.slots.set(slots[i], g);
        }
        p.openInventory(inv);
    }

    private ItemStack named(ItemStack it, String name, List<String> lore) {
        ItemMeta m = it.getItemMeta();
        m.setDisplayName(name);
        if (lore != null) {
            m.setLore(lore);
        }
        it.setItemMeta(m);
        return it;
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        long amount;
        if (!(e.getInventory().getHolder() instanceof GoalsHolder)) {
            return;
        }
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player)) {
            return;
        }
        GoalsHolder holder = (GoalsHolder)e.getInventory().getHolder();
        int slot = e.getRawSlot();
        if (slot < 0 || slot >= holder.slots.size()) {
            return;
        }
        Goal g = holder.slots.get(slot);
        if (g == null || g.completed) {
            return;
        }
        Player p = (Player)e.getWhoClicked();
        if (g.type.equals("COINS")) {
            amount = e.isRightClick() ? (g.dailyLimit > 0L ? g.dailyLimit : 1000L) : 100L;
        } else {
            long l = amount = e.isRightClick() ? this.countInv(p, g.material) : 64L;
        }
        if (amount <= 0L) {
            p.sendMessage(String.valueOf(ChatColor.RED) + "You don't have any " + this.unit(g) + "!");
            return;
        }
        this.donate(p, g, amount);
        this.openGui(p);
    }

    private void donate(Player p, Goal g, long amount) {
        long accepted;
        if (g.completed) {
            p.sendMessage(String.valueOf(ChatColor.YELLOW) + "That goal is already complete!");
            return;
        }
        long day = this.currentDay();
        amount = Math.min(amount, g.target - g.progress);
        if (g.dailyLimit > 0L) {
            long left = g.dailyLimit - this.donatedToday(p.getUniqueId(), g, day);
            if (left <= 0L) {
                p.sendMessage(String.valueOf(ChatColor.RED) + "You've hit today's donation limit for this goal. Come back tomorrow!");
                return;
            }
            amount = Math.min(amount, left);
        }
        if (g.type.equals("COINS")) {
            if (this.econ == null) {
                p.sendMessage(String.valueOf(ChatColor.RED) + "Economy unavailable.");
                return;
            }
            accepted = Math.min(amount, (long)Math.floor(this.econ.getBalance((OfflinePlayer)p)));
            if (accepted <= 0L) {
                p.sendMessage(String.valueOf(ChatColor.RED) + "You don't have any coins to donate.");
                return;
            }
            this.econ.withdrawPlayer((OfflinePlayer)p, (double)accepted);
        } else {
            long have = this.countInv(p, g.material);
            accepted = Math.min(amount, have);
            if (accepted <= 0L) {
                p.sendMessage(String.valueOf(ChatColor.RED) + "You don't have any " + this.unit(g) + " in your inventory.");
                return;
            }
            long toRemove = accepted;
            ItemStack[] contents = p.getInventory().getContents();
            for (int i = 0; i < contents.length && toRemove > 0L; ++i) {
                ItemStack it = contents[i];
                if (it == null || it.getType() != g.material) continue;
                int take = (int)Math.min((long)it.getAmount(), toRemove);
                toRemove -= (long)take;
                if (take >= it.getAmount()) {
                    p.getInventory().setItem(i, null);
                    continue;
                }
                it.setAmount(it.getAmount() - take);
            }
        }
        g.progress += accepted;
        this.addDonatedToday(p.getUniqueId(), g, day, accepted);
        p.sendMessage(String.valueOf(ChatColor.GREEN) + "Donated " + String.valueOf(ChatColor.YELLOW) + this.fmt(accepted) + " " + this.unit(g) + String.valueOf(ChatColor.GREEN) + " to " + g.display + String.valueOf(ChatColor.GREEN) + "!");
        Bukkit.broadcastMessage((String)(String.valueOf(ChatColor.AQUA) + p.getName() + String.valueOf(ChatColor.GRAY) + " donated " + String.valueOf(ChatColor.YELLOW) + this.fmt(accepted) + " " + this.unit(g) + String.valueOf(ChatColor.GRAY) + " to " + g.display + String.valueOf(ChatColor.GRAY) + " (" + this.fmt(g.progress) + "/" + this.fmt(g.target) + ")"));
        if (g.progress >= g.target) {
            // multi-tier: advance
            g.tierIndex++;
            g.progress = 0L;
            this.data.set("goals." + g.id + ".tier", (Object)g.tierIndex);
            this.data.set("goals." + g.id + ".progress", (Object)0L);
            if (g.tierIndex >= g.tiers.size()) {
                long last = g.tiers.isEmpty() ? g.target : g.tiers.get(g.tiers.size() - 1);
                long t = last;
                for (int k = g.tiers.size(); k <= g.tierIndex; k++) t = t * 2L;
                g.target = t;
            } else {
                g.target = g.tiers.get(g.tierIndex);
            }
            g.amplifier = Math.max(0, g.amplifier) ; // keep; reloaded amp uses tier
            // mark completed briefly for buff tick; non-permanent goals still cycle
            g.completed = g.permanent;
            if (!g.permanent) {
                g.expiresDay = this.currentDay() + g.durationDays;
            }
            String eff = g.effect.getKey().getKey().replace('_', ' ').toUpperCase(Locale.ROOT) + " " + (g.amplifier + 1);
            Bukkit.broadcastMessage((String)"");
            Bukkit.broadcastMessage((String)(String.valueOf(ChatColor.GOLD) + String.valueOf(ChatColor.BOLD) + "\ud83c\udf89 COMMUNITY GOAL COMPLETE! " + String.valueOf(ChatColor.RESET) + g.display));
            Bukkit.broadcastMessage((String)(String.valueOf(ChatColor.GOLD) + "The whole server now has " + String.valueOf(ChatColor.AQUA) + eff + String.valueOf(ChatColor.GOLD) + (String)(g.permanent ? " - PERMANENTLY!" : " for the next " + String.valueOf(ChatColor.YELLOW) + this.fmt(g.durationDays) + " Minecraft days" + String.valueOf(ChatColor.GOLD) + "!")));
            Bukkit.broadcastMessage((String)"");
        }
        this.saveData();
    }

    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (label.equalsIgnoreCase("donate") && args.length >= 1) {
            String[] shifted = new String[args.length + 1];
            shifted[0] = "donate";
            System.arraycopy(args, 0, shifted, 1, args.length);
            args = shifted;
        }
        if (args.length > 0 && args[0].equalsIgnoreCase("reload")) {
            if (!sender.hasPermission("mavogoals.admin")) {
                sender.sendMessage(String.valueOf(ChatColor.RED) + "No permission.");
                return true;
            }
            this.saveData();
            this.reloadConfig();
            this.loadGoals();
            sender.sendMessage(String.valueOf(ChatColor.GREEN) + "MAVOCommunityGoals reloaded (" + this.goals.size() + " goals).");
            return true;
        }
        if (args.length >= 2 && args[0].equalsIgnoreCase("donate")) {
            long amount;
            if (!(sender instanceof Player)) {
                sender.sendMessage("Players only.");
                return true;
            }
            Player p = (Player)sender;
            Goal g = this.find(args[1]);
            if (g == null) {
                p.sendMessage(String.valueOf(ChatColor.RED) + "Unknown goal. Use /goal to see the list.");
                return true;
            }
            if (args.length >= 3) {
                try {
                    amount = Long.parseLong(args[2]);
                }
                catch (NumberFormatException ex) {
                    p.sendMessage(String.valueOf(ChatColor.RED) + "Amount must be a number.");
                    return true;
                }
            } else {
                long l = amount = g.type.equals("COINS") ? 100L : 64L;
            }
            if (amount <= 0L) {
                p.sendMessage(String.valueOf(ChatColor.RED) + "Amount must be positive.");
                return true;
            }
            this.donate(p, g, amount);
            return true;
        }
        if (args.length > 0 && args[0].equalsIgnoreCase("list")) {
            this.chatList(sender);
            return true;
        }
        if (sender instanceof Player) {
            this.openGui((Player)sender);
            return true;
        }
        this.chatList(sender);
        return true;
    }

    private void chatList(CommandSender sender) {
        long day = this.currentDay();
        sender.sendMessage(String.valueOf(ChatColor.DARK_RED) + String.valueOf(ChatColor.BOLD) + "MAVOcraft " + String.valueOf(ChatColor.AQUA) + "Community Goals");
        for (Goal g : this.goals) {
            String state = g.completed ? String.valueOf(ChatColor.GREEN) + " \u2714 ACTIVE" : String.valueOf(ChatColor.GRAY) + " " + this.fmt(g.progress) + "/" + this.fmt(g.target);
            sender.sendMessage(g.display + state);
        }
    }

    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (command.getName().equalsIgnoreCase("donate")) {
            if (args.length == 1) {
                return this.goalIds(args[0]);
            }
            if (args.length == 2) {
                return Arrays.asList("64", "100", "1000");
            }
            return new ArrayList<String>();
        }
        if (args.length == 1) {
            ArrayList<String> out = new ArrayList<String>();
            for (String s : Arrays.asList("donate", "list", "reload")) {
                if (!s.startsWith(args[0].toLowerCase(Locale.ROOT))) continue;
                out.add(s);
            }
            return out;
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("donate")) {
            return this.goalIds(args[1]);
        }
        if (args.length == 3 && args[0].equalsIgnoreCase("donate")) {
            return Arrays.asList("64", "100", "1000");
        }
        return new ArrayList<String>();
    }

    private List<String> goalIds(String prefix) {
        ArrayList<String> out = new ArrayList<String>();
        for (Goal g : this.goals) {
            if (!g.id.startsWith(prefix.toLowerCase(Locale.ROOT))) continue;
            out.add(g.id);
        }
        return out;
    }

    static final class Goal {
        String id;
        java.util.List<Long> tiers = new java.util.ArrayList<>();
        int tierIndex;
        int amplifierPerTier;
        String shopBonus;
        int shopBonusPctPerTier;
        String display;
        String type;
        Material material;
        long target;
        long dailyLimit;
        PotionEffectType effect;
        int amplifier;
        boolean permanent;
        long durationDays;
        long progress;
        boolean completed;
        long expiresDay;

        Goal() {
        }
    }

    final class GoalsHolder
    implements InventoryHolder {
        final List<Goal> slots = new ArrayList<Goal>();
        Inventory inv;

        GoalsHolder(CommunityGoals this$0) {
        }

        public Inventory getInventory() {
            return this.inv;
        }
    }
}
