package mavo.hud;

import java.io.File;
import java.lang.reflect.Method;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.Statistic;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.jetbrains.annotations.NotNull;
import net.md_5.bungee.api.ChatMessageType;
import net.md_5.bungee.api.chat.TextComponent;

/**
 * MAVOHud 2.1 - TAB / action-bar helpers for MAVOcraft.
 * Placeholders:
 *   %mavohud_day% %mavohud_time% %mavohud_coords%
 *   %mavohud_deaths% %mavohud_level% %mavohud_level_pct% %mavohud_level_bar%
 *   %mavohud_level_line% %mavohud_rank% %mavohud_tab_name%
 * Player Level = average of all profession levels + all achievement levels (floored, min 1).
 */
public final class Hud extends JavaPlugin {

    private final Set<UUID> shown = new HashSet<>();
    private File dataFile;
    private YamlConfiguration data;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        dataFile = new File(getDataFolder(), "data.yml");
        data = YamlConfiguration.loadConfiguration(dataFile);
        for (String s : data.getStringList("shown")) {
            try { shown.add(UUID.fromString(s)); } catch (Exception ignored) {}
        }
        int period = Math.max(10, getConfig().getInt("update-ticks", 20));
        new BukkitRunnable() {
            @Override public void run() { tick(); }
        }.runTaskTimer(this, 40L, period);
        if (getServer().getPluginManager().getPlugin("PlaceholderAPI") != null) {
            new HudExpansion(this).register();
            getLogger().info("PlaceholderAPI expansion registered (%mavohud_...).");
        } else {
            getLogger().warning("PlaceholderAPI not found - sidebar placeholders unavailable.");
        }
        getLogger().info("MAVOHud 2.1 enabled (Player Level + deaths).");
    }

    @Override
    public void onDisable() { saveShown(); }

    private void saveShown() {
        data.set("shown", shown.stream().map(UUID::toString).toList());
        try { data.save(dataFile); } catch (Exception ignored) {}
    }

    private void tick() {
        for (Player p : getServer().getOnlinePlayers()) {
            if (!shown.contains(p.getUniqueId())) continue;
            p.spigot().sendMessage(ChatMessageType.ACTION_BAR,
                    TextComponent.fromLegacy(coords(p) + ChatColor.DARK_GRAY + "  \u2503  "
                            + ChatColor.WHITE + "Day " + ChatColor.YELLOW + day(p)
                            + ChatColor.DARK_GRAY + "  \u2503  " + time(p)
                            + ChatColor.DARK_GRAY + "  \u2503  " + ChatColor.RED + "\u2620 " + deaths(p)));
        }
    }

    long day(Player p) { return p.getWorld().getFullTime() / 24000L + 1; }

    String time(Player p) {
        long t = p.getWorld().getTime();
        String icon; ChatColor pc;
        if (t >= 23460 || t < 450)      { icon = "\u2600"; pc = ChatColor.GOLD; }
        else if (t < 11616)             { icon = "\u2600"; pc = ChatColor.YELLOW; }
        else if (t < 12542)             { icon = "\u26C5"; pc = ChatColor.GOLD; }
        else                            { icon = "\u263D"; pc = ChatColor.RED; }
        long mins = (t * 60L / 1000L + 6L * 60L) % (24L * 60L);
        String clock = String.format("%02d:%02d", mins / 60, mins % 60);
        String sleep = (pc == ChatColor.RED) ? ChatColor.RED + " zZ" : "";
        return pc + icon + " " + ChatColor.WHITE + clock + sleep;
    }

    String coords(Player p) {
        Location l = p.getLocation();
        return ChatColor.AQUA + "" + l.getBlockX() + " " + l.getBlockY() + " " + l.getBlockZ();
    }

    int deaths(Player p) {
        try { return p.getStatistic(Statistic.DEATHS); }
        catch (Exception e) { return 0; }
    }

    /** Average of profession + achievement levels. Always >= 1. */
    double playerLevelRaw(Player p) {
        double sum = 0;
        int n = 0;
        // professions via reflection (soft depend)
        try {
            Plugin pl = Bukkit.getPluginManager().getPlugin("MAVOProfessions");
            if (pl != null) {
                Method m = pl.getClass().getMethod("level", UUID.class, String.class);
                // try known ids from config
                String[] ids = {"lumberjack","miner","excavator","farmer","hunter","archer","fisherman","guardian","gambler"};
                for (String id : ids) {
                    try {
                        Object v = m.invoke(pl, p.getUniqueId(), id);
                        int lv = v instanceof Integer ? (Integer) v : 1;
                        sum += Math.max(1, lv);
                        n++;
                    } catch (Exception ignored) {}
                }
            }
        } catch (Exception ignored) {}
        // achievements: read data file if plugin present
        try {
            Plugin pl = Bukkit.getPluginManager().getPlugin("MAVOAchievements");
            if (pl != null) {
                File f = new File(pl.getDataFolder(), "data.yml");
                if (f.exists()) {
                    YamlConfiguration d = YamlConfiguration.loadConfiguration(f);
                    String base = "players." + p.getUniqueId() + ".";
                    if (d.getConfigurationSection("players." + p.getUniqueId()) != null) {
                        for (String cat : d.getConfigurationSection("players." + p.getUniqueId()).getKeys(false)) {
                            int lv = d.getInt(base + cat + ".level", 1);
                            sum += Math.max(1, lv);
                            n++;
                        }
                    }
                }
                // if no data yet, still count known categories as L1
                if (n == 0 || (pl.getConfig() != null && pl.getConfig().getConfigurationSection("categories") != null
                        && dCount(pl) > 0 && sum == 0)) {
                    // already handled
                }
                // if player has no ach data, seed n with category count at L1
                if (pl.getConfig() != null && pl.getConfig().getConfigurationSection("categories") != null) {
                    Set<String> cats = pl.getConfig().getConfigurationSection("categories").getKeys(false);
                    File f2 = new File(pl.getDataFolder(), "data.yml");
                    YamlConfiguration d2 = f2.exists() ? YamlConfiguration.loadConfiguration(f2) : new YamlConfiguration();
                    boolean any = d2.getConfigurationSection("players." + p.getUniqueId()) != null;
                    if (!any) {
                        for (String ignored : cats) { sum += 1; n++; }
                    }
                }
            }
        } catch (Exception ignored) {}
        if (n == 0) return 1.0;
        return Math.max(1.0, sum / n);
    }

    private int dCount(Plugin pl) { return 0; }

    int playerLevel(Player p) {
        return Math.max(1, (int) Math.floor(playerLevelRaw(p)));
    }

    /** Fractional progress toward next whole level (0..99). */
    int levelPct(Player p) {
        double raw = playerLevelRaw(p);
        return (int) Math.floor((raw - Math.floor(raw)) * 100.0);
    }

    String levelBar(Player p) {
        int pct = levelPct(p);
        int filled = Math.max(0, Math.min(10, pct / 10));
        StringBuilder sb = new StringBuilder();
        sb.append(ChatColor.GREEN);
        for (int i = 0; i < filled; i++) sb.append('|');
        sb.append(ChatColor.DARK_GRAY);
        for (int i = filled; i < 10; i++) sb.append('|');
        return sb.toString();
    }

    String levelLine(Player p) {
        return ChatColor.YELLOW + "Lv " + playerLevel(p)
                + ChatColor.GRAY + " (" + levelPct(p) + "%) "
                + levelBar(p);
    }

    String rankPrefix(Player p) {
        // LuckPerms primary group if present
        try {
            Plugin lp = Bukkit.getPluginManager().getPlugin("LuckPerms");
            if (lp != null) {
                // use Vault-style chat if available via PAPI %luckperms_prefix% is external;
                // fall back to op / permission
            }
        } catch (Exception ignored) {}
        if (p.hasPermission("mavocraft.owner") || p.isOp()) return ChatColor.RED + "[OWNER] ";
        if (p.hasPermission("group.admin")) return ChatColor.GOLD + "[ADMIN] ";
        if (p.hasPermission("group.mod")) return ChatColor.AQUA + "[MOD] ";
        if (p.hasPermission("group.god")) return ChatColor.WHITE + "[GOD] ";
        if (p.hasPermission("group.satan")) return ChatColor.DARK_RED + "[SATAN] ";
        if (p.hasPermission("group.yeman")) return ChatColor.GREEN + "[YE MAN] ";
        if (p.hasPermission("group.flex")) return ChatColor.GOLD + "[FLEX] ";
        return ChatColor.GRAY + "";
    }

    String tabName(Player p) {
        return rankPrefix(p) + ChatColor.WHITE + p.getName();
    }

    @Override
    public boolean onCommand(CommandSender s, Command c, String label, String[] a) {
        if (!(s instanceof Player p)) { s.sendMessage("Players only."); return true; }
        UUID u = p.getUniqueId();
        if (shown.remove(u)) {
            p.spigot().sendMessage(ChatMessageType.ACTION_BAR, TextComponent.fromLegacy(""));
            p.sendMessage(ChatColor.YELLOW + "Action-bar HUD OFF. " + ChatColor.GRAY + "(sidebar still shows day/time/coords/level)");
        } else {
            shown.add(u);
            p.sendMessage(ChatColor.GREEN + "Action-bar HUD ON (extra line above the hotbar).");
        }
        saveShown();
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String l, String[] a) { return List.of(); }

    public static final class HudExpansion extends me.clip.placeholderapi.expansion.PlaceholderExpansion {
        private final Hud plugin;
        public HudExpansion(Hud plugin) { this.plugin = plugin; }
        @Override public @NotNull String getIdentifier() { return "mavohud"; }
        @Override public @NotNull String getAuthor() { return "MAVO"; }
        @Override public @NotNull String getVersion() { return "2.1.0"; }
        @Override public boolean persist() { return true; }
        @Override
        public String onPlaceholderRequest(Player p, @NotNull String params) {
            if (p == null) return "";
            switch (params.toLowerCase(Locale.ROOT)) {
                case "day": return String.valueOf(plugin.day(p));
                case "time": return plugin.time(p);
                case "coords": return plugin.coords(p);
                case "deaths": return String.valueOf(plugin.deaths(p));
                case "level": return String.valueOf(plugin.playerLevel(p));
                case "level_pct": return String.valueOf(plugin.levelPct(p));
                case "level_bar": return plugin.levelBar(p);
                case "level_line": return plugin.levelLine(p);
                case "rank": return plugin.rankPrefix(p).trim();
                case "tab_name": return plugin.tabName(p);
                case "divider": return ChatColor.DARK_GRAY + "---------------";
                default: return null;
            }
        }
        @Override
        public String onRequest(OfflinePlayer op, @NotNull String params) {
            return op instanceof Player p ? onPlaceholderRequest(p, params) : "";
        }
    }
}
